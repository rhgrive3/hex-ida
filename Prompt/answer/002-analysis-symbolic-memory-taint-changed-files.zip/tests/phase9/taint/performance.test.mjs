// Included in the existing ordinary Phase 9 discovery, not an owned-only gate.
import '../../final-closure/t034/performance.test.mjs';
