// The ordinary Phase 9 discovery route must execute these owned performance cases.
import '../../final-closure/t033/performance.test.mjs';
