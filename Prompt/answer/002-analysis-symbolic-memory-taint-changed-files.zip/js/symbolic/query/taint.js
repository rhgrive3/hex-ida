import { symbolicExecute } from '../executor.js';
import { createTaintFlow } from '../taint/flow.js';
import { QueryFailure, sameMemoryIdentity, monotonicNow } from '../memory/query-state.js';
import { projectTaint } from '../projection/taint.js';
const issued=new WeakMap();
export function isTaintQueryResult(result,identity=result?.identity,modelIdentity=result?.modelIdentity) {
  const state=issued.get(result);
  if(!state||!sameMemoryIdentity(result.identity,identity)||result.modelIdentity!==modelIdentity) return false;
  return !state.signal?.aborted && !state.isCancelled?.()
    && (!state.getCurrentModelIdentity || result.modelIdentity === state.getCurrentModelIdentity())
    && (!state.getCurrentIdentity || sameMemoryIdentity(result.identity,state.getCurrentIdentity()));
}
/** Run first-class taint through the real bounded executor and its byte memory. */
export function queryTaint(ir,options={}) {
  const start=monotonicNow();let flow,execution;
  try {
    flow=createTaintFlow(options);
    const checkModel=()=> { if(options.getCurrentModelIdentity && options.getCurrentModelIdentity()!==options.models.modelIdentity) throw new QueryFailure('stale-model'); };
    checkModel();
    execution=symbolicExecute(ir,{...options.execution,signal:options.signal,isCancelled:options.isCancelled,
      byteMemory:{...options.memory,identity:options.identity,signal:options.signal,isCancelled:options.isCancelled,
        getCurrentIdentity:options.getCurrentIdentity,labelDomain:flow.labels},_taint:flow});
    flow.check(); checkModel();
    if(execution.status!=='complete' && /budget|deadline|cancel|stale/.test(execution.reason ?? '')) throw new QueryFailure(execution.reason);
    const data=flow.solve({partial:execution.status!=='complete'});
    const result=Object.freeze({schemaVersion:'hex-taint-query/v1',identity:flow.identity,
      modelIdentity:options.models.modelIdentity,models:options.models,
      status:execution.status==='complete'?'complete':'partial',reason:execution.reason,
      ...data,execution,metrics:Object.freeze({...flow.metrics(),queryMilliseconds:monotonicNow()-start})});
    const lifecycle={getCurrentIdentity:options.getCurrentIdentity,getCurrentModelIdentity:options.getCurrentModelIdentity,signal:options.signal,isCancelled:options.isCancelled};
    issued.set(result,lifecycle);
    const projection=projectTaint(result);
    flow.check(); checkModel();
    const final=Object.freeze({...result,evidence:projection.evidence,graph:projection.graph,
      metrics:Object.freeze({...flow.metrics(),queryMilliseconds:monotonicNow()-start})});
    issued.set(final,lifecycle);return final;
  } catch(error) {
    if(!(error instanceof QueryFailure)) throw error;
    return Object.freeze({schemaVersion:'hex-taint-query/v1',identity:flow?.identity??null,
      modelIdentity:options.models?.modelIdentity??null,status:'partial',reason:error.reason,
      sinks:Object.freeze([]),values:Object.freeze([]),edges:Object.freeze([]),evidence:null,graph:null,
      metrics:Object.freeze({...flow?.metrics(),queryMilliseconds:monotonicNow()-start})});
  }
}
