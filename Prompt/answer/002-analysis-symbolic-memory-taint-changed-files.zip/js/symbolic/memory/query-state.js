/** Query-local identity and resource authority; no persistent analysis cache. */
export const IDENTITY_FIELDS = Object.freeze([
  'queryId', 'snapshotId', 'binaryId', 'functionId', 'architecture', 'addressSpace', 'semanticsVersion',
]);
export function memoryIdentity(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('memory identity required');
  const result = {};
  for (const key of IDENTITY_FIELDS) {
    if (typeof value[key] !== 'string' || !value[key].trim() || value[key].length > 1024) {
      throw new TypeError(`identity.${key} must be a bounded nonempty string`);
    }
    result[key] = value[key];
  }
  return Object.freeze(result);
}
export function sameMemoryIdentity(a, b) {
  return !!a && !!b && IDENTITY_FIELDS.every((key) => a[key] === b[key]);
}
export function boundedLimit(value, fallback, maximum, name) {
  const n = value ?? fallback;
  if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0 || n > maximum) {
    throw new TypeError(`${name} must be an integer in [0, ${maximum}]`);
  }
  return n;
}
export class QueryFailure extends Error {
  constructor(reason) { super(reason); this.name = 'QueryFailure'; this.reason = reason; }
}
export const monotonicNow = () => globalThis.performance?.now?.() ?? Date.now();
export function createQueryGuard(options, ceilings) {
  const identity = memoryIdentity(options.identity);
  const now = options.now ?? monotonicNow;
  const started = now();
  const duration = boundedLimit(options.timeoutMs, 250, 5000, 'timeoutMs');
  const limits = {}, counts = {};
  for (const [key, maximum] of Object.entries(ceilings)) {
    limits[key] = boundedLimit(options.limits?.[key], maximum, maximum, key);
    counts[key] = 0;
  }
  let reason = null;
  const fail = (code) => { reason ||= code; throw new QueryFailure(reason); };
  function check(current = identity) {
    if (reason) throw new QueryFailure(reason);
    if (!sameMemoryIdentity(identity, current) || options.getCurrentIdentity && !sameMemoryIdentity(identity, options.getCurrentIdentity())) fail('stale-identity');
    if (options.signal?.aborted || options.isCancelled?.()) fail('cancelled');
    if (now() - started >= duration) fail('deadline');
  }
  function take(key, amount = 1) {
    check();
    if (!Number.isSafeInteger(amount) || amount < 0 || !Object.hasOwn(limits, key)) throw new TypeError('invalid resource charge');
    if (amount > limits[key] - counts[key]) fail(`budget:${key}`);
    counts[key] += amount;
  }
  return Object.freeze({ identity, limits: Object.freeze(limits), check, take, fail,
    metrics: () => Object.freeze({ ...counts, wallClock: now() - started }),
    reason: () => reason,
  });
}
