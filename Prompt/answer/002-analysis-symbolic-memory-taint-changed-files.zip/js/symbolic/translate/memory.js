/** Execution-state bridge. Scalar meaning still belongs to translateSemanticIR.
 * Translate one ordinary IR instruction using placeholder SSA arguments, then
 * substitute already evaluated canonical values (never legacy SYM lookalikes).
 * Shared semantic-ir.js remains unchanged; this is the memory-enabled executor route.
 */
import { OP, MK } from '../../ir-base.js';
import { translateSemanticIR } from './semantic-ir.js';
import { createBv, createBool, createUnknownSemantic, bvSort, evaluateExpr } from '../expr/index.js';
import { collectSymbols } from '../solver/exhaustive-backend.js';
import { QueryFailure } from '../memory/query-state.js';
const undef = (bits,reason) => createUnknownSemantic(bvSort(bits),reason);
function validWidth(bits) {
  if(typeof bits!=='number'||!Number.isSafeInteger(bits)||bits<1||bits>64) throw new QueryFailure('invalid-value-width');
  return bits;
}
function substitute(node,args) {
  if(node.kind==='fresh_symbol') return args[node.meta.argIndex] ?? node;
  if(['const','unknown_semantic'].includes(node.kind)) return node;
  const copy={...node};
  for(const key of ['arg','left','right','cond','thenExpr','elseExpr']) if(node[key]) copy[key]=substitute(node[key],args);
  if(node.args) copy.args=Object.freeze(node.args.map(x=>substitute(x,args)));
  return Object.freeze(copy);
}
export function translateMemoryScalar(inst,args,bits) {
  validWidth(bits);
  if([OP.BIN,OP.UN].includes(inst.op) && (typeof (inst.subOp ?? inst.sub ?? inst.name)!=='string' || !(inst.subOp ?? inst.sub ?? inst.name).trim())) return undef(bits,'missing-or-invalid-scalar-operation');
  // Unsupported compound/flag selection requires the shared translator owner.
  if(inst.op===OP.SEL) return undef(bits,'memory-select-needs-canonical-condition');
  if(args.some(x=>!x?.sort || (x.sort.kind==='bv' && x.sort.width!==bits))) return undef(bits,'scalar-input-width-mismatch');
  const template={...inst,subOp:inst.subOp ?? inst.sub,args:args.map((_,i)=>({value:{id:`memory-slot-${i}`,kind:'arg',reg:`memory-slot-${i}`,index:i,bits}}))};
  const translated=translateSemanticIR(template,{bitWidth:bits});
  if(translated.status!=='exact') return translated.expression ?? undef(bits,'unsupported-scalar-translation');
  const expression=substitute(translated.expression,args);
  // Keep the existing concrete evaluator as the only constant-folding authority.
  const shape=collectSymbols([expression],{maxExprNodes:4096,maxExprDepth:128});
  if(shape.limitExceeded||shape.depthExceeded) throw new QueryFailure('scalar-expression-budget');
  const result=evaluateExpr(expression);
  return result.status==='value' ? (expression.sort.kind==='bv'?createBv(bits,result.value):createBool(result.value)) : expression;
}
export function translateExecutionValue(value,state,options={},active=new Set()) {
  state.byteMemory?.chargeExecution();
  if(typeof value?.id !== 'string' || !value.id || value.id.length > 1024) throw new QueryFailure('missing-semantic-value-id');
  const bits=validWidth(value.bits);
  if(state.values.has(value.id)) {
    const cached=state.values.get(value.id);
    if(cached?.sort?.kind==='bv' && cached.sort.width!==bits) throw new QueryFailure('semantic-value-width-conflict');
    return cached;
  }
  if(active.has(value.id)||active.size>=64) throw new QueryFailure('value-cycle-or-depth');
  active.add(value.id);
  let expression, inputs=[];
  if(value.const!=null || value.kind==='arg') {
    if(state.scalarCache.has(value.id)) {
      expression=state.scalarCache.get(value.id);
      if(expression.sort.width!==bits) throw new QueryFailure('semantic-value-width-conflict');
    }
    else {
      const index=value.index ?? (/^x[0-9]+$/.test(value.reg ?? '')?Number(value.reg.slice(1)):null);
      const custom=options.symbolicArgs?.[index] ?? options.symbolicArgs?.[value.reg];
      if(custom!=null && !['bigint','number','string'].includes(typeof custom)) throw new QueryFailure('unsupported-configured-argument');
      if(typeof value.const==='number'&&!Number.isSafeInteger(value.const)||typeof custom==='number'&&!Number.isSafeInteger(custom)) throw new QueryFailure('unsafe-integer');
      expression=translateSemanticIR(value,{bitWidth:bits,symbolicArgs:options.symbolicArgs}).expression;
      state.scalarCache.set(value.id,expression);
    }
  } else if(value.def?.op===OP.LOAD) expression=undef(bits,'load-not-executed');
  else if(value.def?.op===OP.PHI) {
    const matches=(value.def.incoming??[]).filter(x=>x.from===state.prevBlock);
    if(matches.length!==1) expression=undef(bits,'ambiguous-phi');
    else { inputs=[matches[0].value.id];expression=translateExecutionValue(matches[0].value,state,options,active); }
  } else if(value.def) {
    state.byteMemory?.chargeExecution((value.def.args??[]).length,(value.def.args??[]).length);
    const args=(value.def.args??[]).map(a=>a.value);
    inputs=args.map(v=>v?.id);
    expression=translateMemoryScalar(value.def,args.map(v=>translateExecutionValue(v,state,options,active)),bits);
  } else expression=undef(bits,'value-without-definition');
  active.delete(value.id);
  state.taint?.value(value.id,inputs,'data',{unknown:expression?.kind==='unknown_semantic',control:state.control});
  return expression;
}
export function translateMemoryAccess(inst,state,options={}) {
  const memory=state.byteMemory;
  const size=inst.loc?.size ?? inst.addr?.size ?? inst.extra?.size;
  if(![1,2,4,8].includes(size)) throw new QueryFailure('unsupported-access-width');
  const descriptor=inst.extra?.memoryAccess;
  for(const width of [inst.loc?.size,inst.addr?.size,inst.extra?.size]) {
    if(width!=null && width!==size) throw new QueryFailure('memory-width-mismatch');
  }
  for(const bits of [inst.addr?.widthBits,inst.extra?.widthBits,descriptor?.widthBits]) {
    if(bits!=null && bits!==size*8) throw new QueryFailure('memory-width-mismatch');
  }
  for(const space of [inst.loc?.addressSpace,inst.addr?.addressSpace,descriptor?.addressSpace]) {
    if(space!=null && space!==memory.identity.addressSpace) throw new QueryFailure('address-space-mismatch');
  }
  if(inst.addr?.precise===false || inst.extra?.addressPrecise===false) throw new QueryFailure('unresolved-memory-address');
  // Consume the actual v2→v1 descriptor. Unknown qualifiers are not authority for
  // ordinary memory, even when a legacy location key looks precise.
  if(descriptor) {
    if(descriptor.volatility===true) throw new QueryFailure('volatile-barrier');
    if(descriptor.atomic===true) throw new QueryFailure('atomic-barrier');
    if(descriptor.volatility!==false || descriptor.atomic!==false || descriptor.ordering!=null && !['unknown','none'].includes(descriptor.ordering)) throw new QueryFailure('unknown-memory-qualifiers');
    if(descriptor.endian!==memory.endian) throw new QueryFailure('memory-endian-mismatch');
  }
  let address, addressIds=[];
  // Absolute locations and the existing generic base+displacement IR contract only.
  // No name-based FIELD/STACK alias inference and no ISA index/extension decoding.
  if(inst.loc?.kind===MK.GLOBAL && inst.loc.address!=null) address=inst.loc.address;
  else if(inst.addr?.base && !inst.addr.index && inst.addr.disp!=null) {
    addressIds=[inst.addr.base.id];
    address=translateExecutionValue(inst.addr.base,state,options);
    if(address.sort?.kind!=='bv'||address.sort.width!==memory.addressBits) throw new QueryFailure('address-width-mismatch');
    const disp=inst.addr.disp;
    if(typeof disp!=='bigint' && !(typeof disp==='number'&&Number.isSafeInteger(disp))) throw new QueryFailure('unsafe-displacement');
    if(BigInt(disp)!==0n) {
      if(memory.wrapping==='reject' && (address.kind!=='const' || address.value+BigInt(disp)<0n || address.value+BigInt(disp)>=(1n<<BigInt(memory.addressBits)))) {
        throw new QueryFailure('effective-address-wrap-unproved');
      }
      address=translateMemoryScalar({op:OP.BIN,subOp:'add'},[address,createBv(memory.addressBits,disp)],memory.addressBits);
    }
  } else throw new QueryFailure('unresolved-memory-address');
  const access={identity:memory.identity,addressSpace:inst.loc?.addressSpace,
    volatile:[inst.volatile,inst.extra?.volatile,inst.loc?.volatile].some(value=>value!=null&&value!==false),
    atomic:[inst.atomic,inst.extra?.atomic,inst.loc?.atomic].some(value=>value!=null&&value!==false)};
  if(inst.op===OP.LOAD) {
    if(inst.dst?.bits!==size*8) throw new QueryFailure('load-width-mismatch');
    const result=memory.load(address,size,access);
    if(!result.expression) throw new QueryFailure(result.reason);
    state.taint?.value(inst.dst.id,[result.label,...addressIds],'memory-load',{control:state.control});
    return result.expression;
  }
  if(inst.op!==OP.STORE) throw new QueryFailure('not-memory-instruction');
  const v=inst.args?.[0]?.value;
  const expression=translateExecutionValue(v,state,options);
  const label=state.taint?.joinHandles(v.id,...addressIds,state.control);
  const result=memory.store(address,size,expression,{...access,label});
  if(result.status!=='stored') throw new QueryFailure(result.reason);
  return expression;
}
