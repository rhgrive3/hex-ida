/** Projection only: consume taint owner facts; never infer sources in UI/AI. */
import { stableDigest } from '../../core/identity/index.js';
import { createEvidenceNode, createEvidenceEdge } from '../../core/evidence/index.js';
import { createSymbolicEvidence } from '../evidence/symbolic-evidence.js';
import { isTaintQueryResult } from '../query/taint.js';
export function projectTaint(result,{identity=result?.identity,modelIdentity=result?.modelIdentity}={}) {
  if(!isTaintQueryResult(result,identity,modelIdentity)) return Object.freeze({status:'stale-or-unissued',evidence:null,graph:null});
  const queryHash=stableDigest({identity,modelIdentity,values:result.values,edges:result.edges,sinks:result.sinks,status:result.status});
  const prefix=`taint:${queryHash}:`;
  const nodes=result.values.map(value=>createEvidenceNode({id:prefix+value.id,family:'SymbolicEvidence',
    binaryId:identity.binaryId,targetEntityIds:value.valueId?[value.valueId]:[],semanticKind:'taint-flow',
    completeness:result.status==='complete'?'bounded':'partial',deterministic:true,
    payload:{identity,modelIdentity,valueId:value.valueId,taint:value.taint}}));
  const edges=result.edges.map(edge=>createEvidenceEdge({from:prefix+edge.to,to:prefix+edge.from,type:'derived-from',metadata:{flowKind:edge.kind}}));
  const evidence=createSymbolicEvidence({queryKind:'taint-flow',claimKind:'symbolic-query',
    proofStatement:'Bounded conservative taint dependencies; not a semantic-equivalence proof',
    targetEntities:result.sinks.map(s=>s.valueId),queryHash,backendId:'hex-taint-lattice',backendVersion:'1.0.0',
    solverStatus:'unsupported',verdict:'unknown',architecture:identity.architecture,
    completeness:{translation:'complete',controlFlow:result.status==='complete'?'complete':'partial',memoryEffects:result.status==='complete'?'complete':'partial',pathCoverage:result.status==='complete'?'complete':'partial',queryScope:'complete'},
    proofScope:{kind:'query-local-taint',identity,modelIdentity},
    metadata:{sources:result.models.sources,sinks:result.sinks,sanitizers:result.models.sanitizers,unknownSanitizers:result.unknownSanitizers,widened:result.widened}});
  return Object.freeze({status:result.status,evidence,graph:Object.freeze({schemaVersion:1,nodes:Object.freeze(nodes),edges:Object.freeze(edges)})});
}
