/** Pure expression adoption eligibility, NOT a decompiler transaction.
 * The existing verification judge/session/evidence remain the only proof engine.
 * Memory/effect transformations fail closed while #6602 owns that judge boundary.
 */
import { stableDigest } from '../../core/identity/index.js';
import { createQueryGuard, QueryFailure, sameMemoryIdentity } from '../memory/query-state.js';
import { assertMemoryExpr } from '../memory/byte-memory.js';
import { collectSymbols, ExhaustiveBvBackend } from '../solver/exhaustive-backend.js';
import { TieredBvBackend } from '../solver/tiered-backend.js';
import { computeStructuralHashesBounded } from '../expr/hash.js';
import { verifyBoundedEquivalence } from '../verify/equivalence.js';
import { isProvedEvidence } from '../evidence/symbolic-evidence.js';
import { isTaintQueryResult } from '../query/taint.js';
const receipts=new WeakMap();
function reject(reason,proof=null) {
  return Object.freeze({eligible:false,scope:'pure-expression-only',reason,verdict:proof?.verdict??'unknown',
    evidence:proof?.evidence??null,counterexample:proof?.evidence?.witnessModel??null});
}
function expressionNodes(roots,guard) {
  const work=roots.slice(),seen=new Set(),out=[];
  while(work.length) {
    guard.take('workItems');const n=work.pop();if(seen.has(n)) continue;seen.add(n);out.push(n);
    for(const key of ['arg','left','right','cond','thenExpr','elseExpr']) if(n[key]) work.push(n[key]);
    if(n.args) for(const child of n.args) work.push(child);
  }
  return out;
}
export async function verifyDeobfuscationCandidate(candidate={}) {
  const {before,after,identity,preconditions=[],correspondence={inputs:[]},memoryObservables,effectObservables,taintResult}=candidate;
  if(['verified','proof','solverResult','session','backend'].some(key=>Object.hasOwn(candidate,key))) return reject('external-proof-not-accepted');
  if(!before||!after) return reject('missing-target');
  if(!Array.isArray(memoryObservables)||!Array.isArray(effectObservables)) return reject('missing-memory-effect-observables');
  if(memoryObservables.length||effectObservables.length) return reject('memory-effect-judge-handoff');
  if(!['candidateId','beforeValueId','afterValueId'].every(k=>typeof candidate[k]==='string'&&candidate[k].length>0&&candidate[k].length<=1024)) return reject('missing-candidate-value-identity');
  if(!Array.isArray(preconditions)||preconditions.length>4096||!Array.isArray(correspondence.inputs)||correspondence.inputs.length>4096) return reject('invalid-precondition-correspondence');
  if(taintResult && (!isTaintQueryResult(taintResult,identity)||taintResult.status!=='complete'||taintResult.unknownSanitizers.length||taintResult.sinks.some(sink=>sink.taint.kind==='top'))) return reject('incomplete-or-stale-taint');
  const guard=createQueryGuard({...candidate,timeoutMs:candidate.timeoutMs??120},{workItems:100000});
  let session;
  try {
    guard.check();
    const roots=[before,after,...preconditions];
    for(const expr of roots) assertMemoryExpr(expr,guard);
    if(before.sort.kind!==after.sort.kind||before.sort.width!==after.sort.width) return reject('sort-width-mismatch');
    if(preconditions.some(p=>p.sort.kind!=='bool')) return reject('precondition-sort');
    const nodes=expressionNodes(roots,guard);
    if(nodes.some(n=>n.kind==='fresh_symbol'&&n.meta?.source==='initial-byte')) return reject('memory-effect-judge-handoff');
    const collected=collectSymbols(roots,{maxExprNodes:100000,maxExprDepth:128});
    if(collected.unsupportedReason||collected.limitExceeded||collected.depthExceeded) return reject('unsupported-or-budgeted-expression');
    // The shared judge has a name fallback during substitution. Distinct symbols
    // with equal names must not reach it, even when symbolIds differ.
    const names=new Map();
    for(const symbol of collected.symbols) {
      if(names.has(symbol.name)&&names.get(symbol.name)!==symbol.symbolId) return reject('ambiguous-symbol-name-handoff');
      names.set(symbol.name,symbol.symbolId);
    }
    const beforeSymbols=new Set(collectSymbols([before]).symbols.map(s=>s.symbolId));
    const afterSymbols=new Set(collectSymbols([after]).symbols.map(s=>s.symbolId));
    const mapped=new Set();const inputs=[];
    for(const pair of correspondence.inputs) {
      guard.take('workItems');
      if(!beforeSymbols.has(pair.before)||!afterSymbols.has(pair.after)||mapped.has(pair.after)) return reject('invalid-input-correspondence');
      mapped.add(pair.after);inputs.push(Object.freeze({before:pair.before,after:pair.after}));
    }
    if([...afterSymbols].some(id=>!beforeSymbols.has(id)&&!mapped.has(id))) return reject('missing-input-correspondence');
    const hashes=computeStructuralHashesBounded(roots,{maxNodes:100000});
    if(!hashes.ok) return reject('expression-hash-budget');
    guard.take('workItems',hashes.traversalCount);
    const scope=Object.freeze({kind:'pure-expression-only',identity:guard.identity,candidateId:candidate.candidateId,
      beforeValueId:candidate.beforeValueId,afterValueId:candidate.afterValueId,
      beforeHash:hashes.hashes[0],afterHash:hashes.hashes[1],preconditionHashes:Object.freeze(hashes.hashes.slice(2)),
      correspondence:Object.freeze(inputs),memoryObservables:Object.freeze([]),effectObservables:Object.freeze([]),
      taint:taintResult?Object.freeze({modelIdentity:taintResult.modelIdentity,queryHash:taintResult.evidence.queryHash}):null});
    const backend=candidate.backendTier==='tiered'?new TieredBvBackend():new ExhaustiveBvBackend();
    if(candidate.backendTier!=null&&!['tiered','exhaustive'].includes(candidate.backendTier)) return reject('unsupported-backend');
    session=backend.createSession({timeoutMs:candidate.timeoutMs??120,signal:candidate.signal});
    const proof=await verifyBoundedEquivalence({beforeTarget:before,afterTarget:after,
      correspondence:{inputs},preconditions:preconditions.slice(),memoryRegions:[],session,
      options:{timeoutMs:candidate.timeoutMs??120,signal:candidate.signal,architecture:identity.architecture,
        bitWidth:before.sort.width??null,proofScope:scope}});
    guard.check();
    if(taintResult && !isTaintQueryResult(taintResult,guard.identity)) return reject('stale-taint');
    if(proof.verdict!=='proved'||!isProvedEvidence(proof.evidence)) return reject(proof.reasonCode??'proof-ineligible',proof);
    const result=Object.freeze({eligible:true,scope:'pure-expression-only',verdict:'proved',reason:'proved-equivalent',
      identity:guard.identity,binding:scope,bindingDigest:stableDigest(scope),before,after,evidence:proof.evidence});
    receipts.set(result,{scope,taintResult,getCurrentIdentity:candidate.getCurrentIdentity,signal:candidate.signal,isCancelled:candidate.isCancelled});return result;
  } catch(error) {
    if(!(error instanceof QueryFailure)) throw error;
    return reject(error.reason);
  } finally { session?.dispose(); }
}
export function isAdoptableCandidate(result,{identity=result?.identity,before=result?.before,after=result?.after}={}) {
  const receipt=receipts.get(result);
  if(!receipt||!sameMemoryIdentity(identity,result.identity)||before!==result.before||after!==result.after) return false;
  return (!receipt.taintResult || isTaintQueryResult(receipt.taintResult,identity)) && !receipt.signal?.aborted && !receipt.isCancelled?.() && (!receipt.getCurrentIdentity || sameMemoryIdentity(identity,receipt.getCurrentIdentity()));
}
