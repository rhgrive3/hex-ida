/*
 * Semantic IR public-core compatibility facade.
 *
 * Semantic IR v2 compatibility is the Phase 3 production default after the
 * completed shadow differential. Legacy ARM64 remains an explicit oracle mode;
 * there is still no catch-and-fallback path between the engines.
 */
export * from './architecture/compat/ir-core-arm64-aapcs64-v1.js';

import {
  buildIR as buildLegacyIR,
  OP as LEGACY_OP,
  VK as LEGACY_VK,
  MK as LEGACY_MK,
  stackPointerProvenanceOf as legacyStackPointerProvenanceOf,
} from './architecture/compat/ir-core-arm64-aapcs64-v1.js';
import { buildCfg, EDGE } from './cfg.js';
import { stableDigest } from './core/identity/index.js';
import {
  SEMANTIC_V2_MIGRATION_MODES,
  buildSemanticV2CompatibilityPipeline,
} from './semantics/compat/index.js';
import {
  canonicalMemoryForwardingContextForLoad,
  isCanonicalExactMemoryForwarding,
} from './semantics/memoryssa/queries.js';
import { ARM64_ARCHITECTURE } from './targets/architecture/index.js';
import { resolveABIPlugin } from './targets/abi/index.js';
import { semanticAbiAdapter } from './analysis/semantic-function-base.js';

// Historical callers receive the canonical registry classifier through this
// compatibility name.  The v2 compatibility pipeline itself always uses the
// identity-carrying adapter below and never runs a private ABI classifier.
export function classifyCallArguments(instruction = {}, options = {}) {
  const source = instruction && typeof instruction === 'object' ? instruction : {};
  const target = {
    ...options,
    abiId:options.abiId ?? source.abiId,
    abi:options.abi ?? source.abi,
    callingConvention:options.callingConvention ?? source.callingConvention,
    architectureId:options.architectureId ?? source.architectureId,
    architecture:options.architecture ?? source.architecture ?? source.architectureId,
    platformId:options.platformId ?? source.platformId,
    platform:options.platform ?? source.platform ?? source.platformId,
    callPrototype:source.callPrototype ?? options.callPrototype,
  };
  const plugin = resolveABIPlugin(target, { legacyDefault:true });
  return plugin.classifyArguments({
    callTarget:source.callTarget ?? source.target ?? null,
    callPrototype:target.callPrototype ?? null,
  }, target);
}

let semanticMigrationMode = SEMANTIC_V2_MIGRATION_MODES.V2_COMPAT;
let lastSemanticV2Instrumentation = null;

function normalizeMode(mode) {
  const value = mode ?? semanticMigrationMode;
  if (value === SEMANTIC_V2_MIGRATION_MODES.LEGACY || value === SEMANTIC_V2_MIGRATION_MODES.V2_COMPAT) return value;
  throw new TypeError('semantic-migration-mode-unsupported');
}

/** Explicit process/session migration switch. Legacy-v1 remains available as the compatibility oracle. */
export function setSemanticMigrationMode(mode) {
  semanticMigrationMode = normalizeMode(mode);
  lastSemanticV2Instrumentation = null;
  return semanticMigrationMode;
}

export function getSemanticMigrationMode() { return semanticMigrationMode; }
export function getLastSemanticV2Instrumentation() { return lastSemanticV2Instrumentation; }

function asLegacyAddress(address) {
  if (address == null) return null;
  try { return typeof address === 'bigint' ? address : BigInt(address); }
  catch { return null; }
}

function rowResolver(model, opts) {
  if (typeof opts?.rowOfAddress === 'function') {
    return (address) => {
      const normalized = asLegacyAddress(address);
      return normalized == null ? null : opts.rowOfAddress(normalized);
    };
  }
  const rows = new Map();
  for (const instruction of model?.instructions ?? []) {
    if (instruction?.address != null && Number.isSafeInteger(instruction.row)) rows.set(instruction.address.toString(), instruction.row);
  }
  return (address) => address == null ? null : (rows.get(address.toString()) ?? null);
}

function edgeKind(edge) {
  if (edge.kind === EDGE.TAKEN) return 'conditional-true';
  if (edge.kind === EDGE.JUMP) return 'branch';
  if (edge.kind === EDGE.UNKNOWN) return 'unknown';
  return 'fallthrough';
}

function ephemeralBinaryId(model) {
  const identity = (model?.instructions ?? []).map((instruction) => ({
    address: instruction?.address ?? null,
    mnemonic: instruction?.mnemonic ?? null,
    operands: instruction?.operands ?? null,
  }));
  return `migration-model-${stableDigest(identity)}`;
}

function canonicalCompatibilityAbiAdapter(options = {}, binaryId = null, sliceId = null) {
  const plugin = resolveABIPlugin({
    ...options,
    architecture:options.architecture ?? options.architectureId ?? 'arm64',
    binaryId:binaryId ?? options.binaryId,
    sliceId:sliceId ?? options.sliceId,
  }, { legacyDefault:true });
  return semanticAbiAdapter(plugin, {
    ...options,
    architecture:options.architecture ?? options.architectureId ?? plugin.architectureId,
    binaryId:binaryId ?? options.binaryId,
    sliceId:sliceId ?? options.sliceId,
  });
}

/*
 * Legacy v1 region-root presentation.  Placement/classification authority is
 * always the adapter selected above; this helper only describes the legacy
 * memory-root view needed by the old ARM64 projection.  Refuse to manufacture
 * xN roots when a different canonical profile is selected.
 */
function aapcs64RegionRootDescriptorProvider(options = {}, abiAdapter = null) {
  const explicit = options.rootDescriptorProvider ?? options.regionOptions?.rootDescriptorProvider ?? null;
  return (request) => {
    if (typeof explicit === 'function') {
      const supplied = explicit(request);
      if (supplied != null) return supplied;
    }
    if (String(abiAdapter?.id || '').toLowerCase() !== 'aapcs64') return null;
    const identity = request?.variable?.physicalIdentity;
    if (identity?.kind !== 'register') return null;
    const registerId = String(identity.registerId ?? '');
    if (registerId === 'sp') {
      return {
        kind: 'stack-like',
        addressSpace: request.expectedAddressSpace ?? 'memory',
        baseOffset: 0,
        linearOffsets: true,
        rootIdentity: {
          kind: 'abi-storage-root',
          abi: abiAdapter.id,
          storageClass: 'function-local-stack',
          registerId,
        },
      };
    }
    const argument = /^x([0-7])$/.exec(registerId);
    if (!argument) return null;
    return {
      kind: 'rooted-object',
      addressSpace: request.expectedAddressSpace ?? 'memory',
      baseOffset: 0,
      linearOffsets: true,
      rootIdentity: {
        kind: 'abi-entry-argument-root',
        abi: abiAdapter.id,
        storageClass: 'external-entry-memory',
        argumentIndex: Number(argument[1]),
        registerId,
      },
    };
  };
}

function valueDominatesLegacyInstruction(value, inst, projected) {
  if (!value || !inst) return false;
  if (value.kind === LEGACY_VK.ARG) return true;
  const definition = value.def;
  if (!definition || definition === inst) return false;
  if (definition.block === inst.block) return Number(definition.row) <= Number(inst.row);
  const dominators = projected.dominators?.[inst.block];
  return dominators instanceof Set && dominators.has(definition.block);
}

function legacyDefinitionRecency(value, inst, projected) {
  if (!value || value.kind === LEGACY_VK.ARG || !value.def) return { scope:0, depth:0, row:Number.NEGATIVE_INFINITY };
  const definition = value.def;
  if (definition.block === inst.block) {
    return { scope:2, depth:Number.MAX_SAFE_INTEGER, row:Number(definition.row ?? Number.NEGATIVE_INFINITY) };
  }
  const dominators = projected.dominators?.[inst.block];
  if (!(dominators instanceof Set) || !dominators.has(definition.block)) {
    return { scope:-1, depth:-1, row:Number.NEGATIVE_INFINITY };
  }
  const definitionDominators = projected.dominators?.[definition.block];
  return {
    scope:1,
    depth:definitionDominators instanceof Set ? definitionDominators.size : 0,
    row:Number(definition.row ?? Number.NEGATIVE_INFINITY),
  };
}

function detachLegacyArguments(inst) {
  for (const arg of inst.args ?? []) {
    const value = arg?.value;
    if (!Array.isArray(value?.uses)) continue;
    value.uses = value.uses.filter((use) => use !== inst);
  }
  inst.args = [];
}

function selectReachingRegisterValue(projected, inst, reg, bits = null, excluded = null) {
  const candidates = (projected.values ?? [])
    .filter((value) => value !== excluded && value.reg === reg && value.kind !== LEGACY_VK.UNDEF
      && valueDominatesLegacyInstruction(value, inst, projected))
    .sort((left, right) => {
      const leftRecency = legacyDefinitionRecency(left, inst, projected);
      const rightRecency = legacyDefinitionRecency(right, inst, projected);
      if (leftRecency.scope !== rightRecency.scope) return rightRecency.scope - leftRecency.scope;
      if (leftRecency.depth !== rightRecency.depth) return rightRecency.depth - leftRecency.depth;
      if (leftRecency.row !== rightRecency.row) return rightRecency.row - leftRecency.row;
      const leftWidth = Number(bits) > 0 && left.bits === Number(bits) ? 1 : 0;
      const rightWidth = Number(bits) > 0 && right.bits === Number(bits) ? 1 : 0;
      if (leftWidth !== rightWidth) return rightWidth - leftWidth;
      return (right.id ?? 0) - (left.id ?? 0);
    });
  return candidates[0] ?? null;
}

function replaceLegacyArg(inst, from, to) {
  if (!inst || !from || !to || from === to) return false;
  let changed = false;
  for (const arg of inst.args ?? []) {
    if (arg?.value !== from) continue;
    arg.value = to;
    arg.bits = to.bits || arg.bits;
    changed = true;
  }
  if (!changed) return false;
  if (Array.isArray(from.uses)) from.uses = from.uses.filter((use) => use !== inst);
  if (!Array.isArray(to.uses)) to.uses = [];
  if (!to.uses.includes(inst)) to.uses.push(inst);
  return true;
}

/*
 * Generic SSA is deliberately ABI-neutral and therefore treats an unknown call's
 * state category as a broad clobber. The selected canonical ABI adapter may
 * recover only a callee-preserved physical register state. Memory effects are
 * not changed.
 */
function restoreCanonicalPreservedStateReads(projected, adapter) {
  let callerSaved = [];
  try { callerSaved = adapter?.callerSaved?.() ?? []; } catch { callerSaved = []; }
  const callerSavedSet = new Set(callerSaved.map(String));
  for (const inst of projected.instructions ?? []) {
    if (inst.op !== LEGACY_OP.MOV || !inst.extra?.stateRead || inst.args?.length !== 1) continue;
    const identity = inst.extra.stateRead?.physicalIdentity;
    if (identity?.kind !== 'register') continue;
    const reg = String(identity.registerId ?? '');
    if (!reg || callerSavedSet.has(reg)) continue;
    const unknown = inst.args[0]?.value;
    const call = unknown?.def;
    if (unknown?.kind !== LEGACY_VK.UNDEF || call?.op !== LEGACY_OP.CALL) continue;
    const reaching = selectReachingRegisterValue(projected, call, reg, inst.dst?.bits ?? unknown.bits, unknown);
    if (!reaching) continue;
    replaceLegacyArg(inst, unknown, reaching);
    inst.extra.abiPreservedState = true;
    inst.extra.abiPreservedStateEvidence = `canonical-${adapter?.id || 'abi'}-callee-preserved`;
  }
}

function exactLegacyConstant(value, active = new Set()) {
  if (!value || active.has(value.id)) return null;
  if (value.const != null) {
    try { return BigInt(value.const); } catch { return null; }
  }
  const def = value.def;
  if (!def) return null;
  active.add(value.id);
  let result = null;
  if (def.op === LEGACY_OP.CONST || def.op === LEGACY_OP.ADDR) {
    try { result = BigInt(def.extra?.value ?? def.extra?.target); } catch { result = null; }
  } else if (def.op === LEGACY_OP.MOV && def.args?.length === 1) {
    const inner = exactLegacyConstant(def.args[0]?.value, active);
    if (inner != null) {
      if (def.sub === 'trunc' || def.sub === 'zext') result = BigInt.asUintN(Number(value.bits || 64), inner);
      else if (def.sub == null || def.sub === 'copy' || def.sub === 'bitcast') result = inner;
    }
  } else if (def.op === LEGACY_OP.BIN && def.args?.length >= 2) {
    const left = exactLegacyConstant(def.args[0]?.value, active);
    const right = exactLegacyConstant(def.args[1]?.value, active);
    if (left != null && right != null) {
      const bits = Number(value.bits || 64);
      if (def.sub === 'add') result = left + right;
      else if (def.sub === 'sub') result = left - right;
      else if (def.sub === 'mul') result = left * right;
      else if (def.sub === 'and') result = left & right;
      else if (def.sub === 'or') result = left | right;
      else if (def.sub === 'xor') result = left ^ right;
      else if (def.sub === 'shl') result = left << right;
      else if (def.sub === 'lshr') result = BigInt.asUintN(bits, left) >> right;
      if (result != null) result = BigInt.asUintN(bits, result);
    }
  }
  active.delete(value.id);
  return result;
}

function propagateExactLegacyConstants(projected) {
  for (const value of projected.values ?? []) {
    if (value.const != null) continue;
    const constant = exactLegacyConstant(value);
    if (constant != null) value.const = BigInt.asUintN(Number(value.bits || 64), constant);
  }
}

function canonicalAddressBase(value, active = new Set()) {
  if (!value || active.has(value.id)) return value;
  active.add(value.id);
  const def = value.def;
  if (def?.op === LEGACY_OP.MOV && def.args?.length === 1
      && (def.extra?.stateRead || def.extra?.stateWrite || def.sub == null)) {
    const inner = canonicalAddressBase(def.args[0]?.value, active);
    active.delete(value.id);
    return inner || value;
  }
  active.delete(value.id);
  return value;
}

/*
 * MemorySSA alias conclusions remain authoritative. This restores only the
 * legacy public location shape from already-proven precise address metadata.
 */
function restoreAapcs64PublicLocations(projected) {
  for (const inst of projected.instructions ?? []) {
    if (inst.op !== LEGACY_OP.LOAD && inst.op !== LEGACY_OP.STORE) continue;
    if ((inst.loc?.kind !== LEGACY_MK.UNKNOWN && inst.loc?.kind !== LEGACY_MK.STACK) || inst.addr?.precise !== true || inst.addr.index != null) continue;
    const stack = legacyStackPointerProvenanceOf(inst.addr.base);
    if (stack?.must === true) {
      const offset = BigInt(stack.offset ?? 0n) + BigInt(inst.addr.disp ?? 0n);
      const size = inst.addr.size ?? inst.extra?.size ?? null;
      const existing = inst.loc?.kind === LEGACY_MK.STACK && inst.loc.disp != null && BigInt(inst.loc.disp) === offset
        && (inst.loc.size == null || size == null || Number(inst.loc.size) === Number(size)) ? inst.loc : null;
      const key = existing?.key ?? `stack:${offset.toString()}`;
      const loc = existing ?? {
        key,
        kind: LEGACY_MK.STACK,
        disp: offset,
        size,
        regionId: inst.loc?.regionId ?? null,
        origin: inst.loc?.origin ?? inst.addr?.origin ?? null,
        compatAbiPreservedAddress: true,
      };
      if (!existing) projected.locations?.set?.(key, loc);
      inst.loc = loc;
      inst.extra = { ...(inst.extra ?? {}), compatAbiPreservedAddress: true };
      continue;
    }
    const base = canonicalAddressBase(inst.addr.base);
    if (base?.def?.op !== LEGACY_OP.LOAD
        || !isCanonicalExactMemoryForwarding(base.def.memoryForwarding,
          canonicalMemoryForwardingContextForLoad(base.def.memoryForwarding, base.def,
            base.def.memoryForwardingContext ?? base.def.extra?.memoryForwardingContext))) continue;
    const disp = BigInt(inst.addr.disp ?? 0n);
    const size = inst.addr.size ?? inst.extra?.size ?? null;
    const key = `field:loaded:${base.id}+${disp.toString()}:s${size ?? '?'}`;
    const loc = {
      key,
      kind: LEGACY_MK.FIELD,
      base,
      disp,
      size,
      regionId: inst.loc?.regionId ?? null,
      origin: inst.loc?.origin ?? inst.addr?.origin ?? null,
      aliasUncertain: true,
      compatibilityShapeOnly: true,
    };
    projected.locations?.set?.(key, loc);
    inst.loc = loc;
    inst.extra = { ...(inst.extra ?? {}), compatibilityShapeOnly: true };
  }
}

function attachCanonicalCallArguments(projected) {
  for (const inst of projected.instructions ?? []) {
    if (inst.op !== LEGACY_OP.CALL || !Array.isArray(inst.callArguments)) continue;
    detachLegacyArguments(inst);
    const seen = new Set();
    const uncertainValueIds = [];
    for (const descriptor of inst.callArguments) {
      const reg = descriptor?.reg == null ? null : String(descriptor.reg);
      if (!reg) continue;
      const value = selectReachingRegisterValue(projected, inst, reg, descriptor.bits ?? null);
      if (!value || seen.has(value.id)) continue;
      seen.add(value.id);
      inst.args.push({ value, bits:value.bits || descriptor.bits || 64 });
      if (!Array.isArray(value.uses)) value.uses = [];
      if (!value.uses.includes(inst)) value.uses.push(inst);
      if (descriptor?.possible === true || descriptor?.mustUse === false || descriptor?.exact === false) {
        uncertainValueIds.push(value.semanticSsaValueId ?? value.semanticValueId ?? value.id);
      }
    }
    inst.extra = {
      ...(inst.extra ?? {}),
      abiProjectedArgumentValueIds: inst.args.map((arg) => arg.value?.semanticSsaValueId ?? arg.value?.semanticValueId ?? arg.value?.id),
      abiPossibleArgumentValueIds: uncertainValueIds,
    };
  }
}

function attachCanonicalTypedCallResults(projected, instructionByRow, adapter, options = {}) {
  for (const inst of projected.instructions ?? []) {
    if (inst.op !== LEGACY_OP.CALL || inst.dst) continue;
    const decoded = instructionByRow.get(inst.row) ?? null;
    const prototype = (() => {
      try { return decoded == null ? null : options.callPrototypeFor?.(decoded.callTarget ?? null, decoded) ?? options.callPrototype ?? null; }
      catch { return null; }
    })();
    const result = adapter?.classifyCall?.({
      call:{ target:decoded?.callTarget ?? null, callPrototype:prototype },
    }) ?? null;
    // A legacy scalar destination is valid only for one complete canonical
    // register location. Aggregate/multi-register returns stay in the full
    // returnLocations metadata carried by the call node.
    const returnLocations = Array.isArray(result?.returnLocations) ? result.returnLocations : [];
    if (result?.unsupported === true
      || returnLocations.length !== 1
      || returnLocations[0]?.kind !== 'register'
      || returnLocations[0]?.aggregate === true
      || !result?.returnReg
      || String(returnLocations[0]?.reg ?? '') !== String(result.returnReg)) continue;
    const reg = String(result.returnReg);
    const bits = Number(result.returnBits || 64);
    const candidates = (projected.values ?? [])
      .filter((value) => value?.reg === reg
        && value?.sourceEntityId === inst.semanticNodeId
        && value?.def == null)
      .sort((left, right) => Number(right.id ?? -1) - Number(left.id ?? -1));
    const priorVersion = Math.max(-1, ...(projected.values ?? [])
      .filter((value) => value?.reg === reg)
      .map((value) => Number(value.version ?? -1)));
    const value = candidates[0] ?? {
      id: (projected.values ?? []).length,
      vid: (projected.values ?? []).length + 1,
      kind: LEGACY_VK.DEF,
      reg,
      stateKey: null,
      version: priorVersion + 1,
      bits,
      def: null,
      uses: [],
      const: null,
      range: null,
      signed: null,
      nullable: null,
      type: null,
      label: reg,
      semanticValueId: null,
      semanticSsaValueId: null,
      sourceEntityId: inst.semanticNodeId,
      machineType: null,
      origin: inst.origin ?? null,
      compatibilityShapeOnly: true,
    };
    if (!candidates[0]) projected.values.push(value);
    value.kind = LEGACY_VK.DEF;
    value.reg = reg;
    value.bits = bits;
    value.def = inst;
    value.unknown = true;
    delete value.undefined;
    delete value.clobbered;
    value.compatDerived = 'typed-abi-call-result';
    inst.dst = value;
    inst.returnReg = reg;
    inst.returnBits = bits;
    inst.returnEvidence = result.returnEvidence || `canonical-${adapter?.id || 'abi'}-call`;
    inst.extra = {
      ...(inst.extra ?? {}),
      compatTypedCallResult: true,
      compatTypedCallResultEvidence: inst.returnEvidence,
      returnLocations,
      returnPieces:result.returnPieces ?? null,
    };
  }
}

function valueMayCarryStackAddress(value) {
  const proof = legacyStackPointerProvenanceOf(value);
  return proof?.must === true || proof?.may === true;
}

/*
 * Keep canonical MemorySSA conservative across unknown calls. For the legacy-v1
 * compatibility shape only, reconnect one same-block stack load to its previous
 * stack store when the address of caller-local stack storage is proven not to
 * escape across any intervening call/barrier. The canonical memUse remains the
 * call-clobber node, so this cannot turn MemorySSA's unknown into NoAlias.
 */

function invalidateEscapedStackForwarding(projected) {
  for (const load of projected.instructions ?? []) {
    if (load.op !== LEGACY_OP.LOAD || load.loc?.kind !== LEGACY_MK.STACK || !load.reachingStore) continue;
    const store = load.reachingStore;
    const block = projected.blocks?.[load.block];
    if (!block || store.block !== load.block) continue;
    for (const inst of block.insts ?? []) {
      if (Number(inst.row) <= Number(store.row) || Number(inst.row) >= Number(load.row)) continue;
      if (inst.op !== LEGACY_OP.CALL) continue;
      if (!(inst.args ?? []).some((arg) => valueMayCarryStackAddress(arg?.value))) continue;
      const priorMemoryUse = load.memUse ?? null;
      load.reachingStore = undefined;
      load.memUse = {
        kind:'clobber',
        definitionId:null,
        regionId:priorMemoryUse?.regionId ?? load.loc?.regionId ?? null,
        clobberingInstructionId:inst.id,
        previousDefinitionId:priorMemoryUse?.definitionId ?? null,
        compatibilityDerived:true,
        evidence:'aapcs64-stack-argument-escape',
      };
      load.extra = {
        ...(load.extra ?? {}),
        compatStackEscapeInvalidation:true,
        compatStackEscapeCallInstructionId:inst.id,
        canonicalMemoryUseKind:priorMemoryUse?.kind ?? null,
        canonicalMemoryDefinitionId:priorMemoryUse?.definitionId ?? null,
      };
      break;
    }
  }
}

/**
 * Semantic IR return nodes carry the architectural control target (for A64 RET,
 * typically the link register). That is not a source-language return value.
 */
function attachCanonicalFunctionReturns(projected, adapter, options = {}) {
  const returnEvidence = (() => {
    try {
      const classified = adapter?.classifyFunctionReturn?.({
        functionPrototype:options.functionPrototype ?? null,
        returnType:options.returnType ?? null,
        returnClass:options.returnClass ?? null,
        returnBits:options.returnBits ?? null,
        returnsValue:options.returnsValue,
      });
      return classified?.evidence
        ?? (adapter?.id === 'aapcs64' ? 'prototype-aapcs64' : `canonical-${adapter?.id || 'abi'}-return`);
    } catch { return `canonical-${adapter?.id || 'abi'}-return`; }
  })();
  const locations = adapter?.returnLocations?.({
    functionPrototype:options.functionPrototype ?? null,
    returnType:options.returnType ?? null,
    returnClass:options.returnClass ?? null,
    returnBits:options.returnBits ?? null,
    returnsValue:options.returnsValue,
  }) ?? [];
  for (const inst of projected?.instructions ?? []) {
    if (inst.op !== LEGACY_OP.RET) continue;
    detachLegacyArguments(inst);
    inst.returnReg = null;
    inst.returnEvidence = null;
    inst.extra = {
      ...(inst.extra ?? {}),
      abiReturnLocations:locations,
    };
    if (locations.length !== 1 || locations[0]?.kind !== 'register' || locations[0]?.aggregate === true) continue;
    const result = locations[0];
    const value = selectReachingRegisterValue(projected, inst, result.reg, result.bits ?? null);
    if (!value) continue;
    inst.args = [{ value, bits:value.bits || result.bits || 64 }];
    if (!Array.isArray(value.uses)) value.uses = [];
    if (!value.uses.includes(inst)) value.uses.push(inst);
    inst.returnReg = result.reg;
    inst.returnEvidence = returnEvidence;
    inst.extra = {
      ...(inst.extra ?? {}),
      abiProjectedReturnValueId: value.semanticSsaValueId ?? value.semanticValueId ?? value.id,
      abiProjectedReturnEvidence: inst.returnEvidence,
    };
  }
}

function buildV2CompatFromLegacyModel(model, opts = {}) {
  if (!model?.instructions?.length) return null;
  const rowOfAddress = rowResolver(model, opts);
  const legacyCfg = opts.cfg ?? buildCfg(model, { rowOfAddress });
  const instructionByRow = new Map(model.instructions.map((instruction) => [instruction.row, instruction]));
  const blocks = legacyCfg.nodes.map((node) => {
    const instructions = [];
    for (let row = node.startRow; row <= node.endRow; row++) {
      const instruction = instructionByRow.get(row);
      if (!instruction || instruction.data) continue;
      instructions.push({
        decoded: instruction,
        address: instruction.address,
        size: 4,
        mode: 'a64',
      });
    }
    const first = instructions[0]?.decoded?.address;
    if (first == null) throw new TypeError('semantic-v2-compat-empty-basic-block');
    return {
      key: `legacy-block-${node.index}`,
      startAddress: first,
      instructions,
      successors: node.succ
        .filter((successor) => successor.to >= 0)
        .map((successor) => ({ to: `legacy-block-${successor.to}`, kind: edgeKind(successor) })),
    };
  });
  const binaryId = String(opts.binaryId ?? model.binaryId ?? ephemeralBinaryId(model));
  const sliceId = String(opts.sliceId ?? model.sliceId ?? `migration-slice-${stableDigest({ binaryId, architecture: 'arm64' })}`);
  const abiAdapter = opts.abiAdapter ?? canonicalCompatibilityAbiAdapter(opts, binaryId, sliceId);
  const result = buildSemanticV2CompatibilityPipeline({
    architecturePlugin: ARM64_ARCHITECTURE,
    decoderSemanticVersion: String(opts.decoderSemanticVersion ?? 'legacy-model-decoder-v1'),
    binaryId,
    sliceId,
    addressWidthBits: 64,
    canonicalStartIdentity: { address: model.startAddress ?? model.instructions[0].address },
    entryBlockKey: legacyCfg.entry >= 0 ? `legacy-block-${legacyCfg.entry}` : blocks[0]?.key,
    blocks,
    abiAdapter,
    rootDescriptorProvider: aapcs64RegionRootDescriptorProvider(opts, abiAdapter),
  }, {
    signal: opts.signal,
    semanticIrOptions: opts.semanticIrOptions,
    ssaOptions: opts.ssaOptions,
    memorySsaOptions: opts.memorySsaOptions,
    compatOptions: {
      rowOfNode(node) {
        const address = node?.origin?.virtualRanges?.[0]?.start;
        return address == null ? null : rowOfAddress(address);
      },
      textOfNode(node) {
        const address = node?.origin?.virtualRanges?.[0]?.start;
        const row = address == null ? null : rowOfAddress(address);
        const instruction = row == null ? null : instructionByRow.get(row);
        return instruction ? `${instruction.mnemonic} ${instruction.operands ?? ''}`.trim() : `semantic-v2 ${node.kind}`;
      },
      ...(opts.compatOptions ?? {}),
    },
  });
  if (process.env.HEX_DEBUG_C2_MEM === '1') {
    process.stderr.write(JSON.stringify(result.memorySsa?.regions ?? [], null, 2) + '\n');
    process.stderr.write(JSON.stringify((result.memorySsa?.regions ?? []).filter((region) => region.kind === 'unknown').map((region) => {
      const sourceId = region.uncertaintyIdentity?.sourceEntityId;
      const node = result.semanticIr?.nodes?.find((candidate) => String(candidate.id) === String(sourceId));
      const addressId = node?.memory?.addressExpr?.valueId;
      const value = result.semanticIr?.values?.find((candidate) => String(candidate.id) === String(addressId));
      const definition = result.semanticIr?.nodes?.find((candidate) => String(candidate.id) === String(value?.definitionNodeId));
      const addressInputs = (definition?.inputs ?? []).map((inputId) => {
        const inputValue = result.semanticIr?.values?.find((candidate) => String(candidate.id) === String(inputId));
        const inputDefinition = result.semanticIr?.nodes?.find((candidate) => String(candidate.id) === String(inputValue?.definitionNodeId));
        return {
          valueId: inputValue?.id,
          valueKind: inputValue?.kind,
          definitionNodeId: inputValue?.definitionNodeId,
          definitionKind: inputDefinition?.kind,
          variable: inputDefinition?.variable?.physicalIdentity?.registerId ?? null,
        };
      });
      const stateUses = (result.ssa?.uses ?? []).filter((use) => String(use.sourceEntityId) === String(definition?.inputs?.[0] ?? sourceId));
      const readNodeIds = new Set(addressInputs.filter((input) => input.definitionKind === 'state-read').map((input) => String(input.definitionNodeId)));
      const readUses = (result.ssa?.uses ?? []).filter((use) => readNodeIds.has(String(use.sourceEntityId)));
      const readValueIds = new Set(readUses.map((use) => String(use.valueId)));
      const pointerValue = result.semanticIr?.values?.find((candidate) => String(candidate.id) === 'semantic_value_3badd2c473b95936bb72aa67d5fb1655');
      const pointerDefinition = result.semanticIr?.nodes?.find((candidate) => String(candidate.id) === String(pointerValue?.definitionNodeId));
      const scalarUses = (result.ssa?.uses ?? []).filter((use) => String(use.sourceEntityId) === String(node?.id));
      const relevantIds = new Set(scalarUses.map((use) => String(use.valueId)));
      return {
        region: { id: region.id, kind: region.kind, widthBits: region.widthBits },
        node: { id: node?.id, kind: node?.kind, inputs: node?.inputs, address: node?.memory?.addressExpr },
        addressValue: { id: value?.id, definitionNodeId: value?.definitionNodeId },
        addressDefinition: { id: definition?.id, kind: definition?.kind, inputs: definition?.inputs },
        addressInputs,
        scalarSsa: {
          uses: scalarUses.map((use) => ({ sourceEntityId: use.sourceEntityId, valueId: use.valueId, kind: use.proof?.kind, sem: use.proof?.sourceSemanticValueId })),
          definitions: (result.ssa?.definitions ?? []).filter((candidate) => relevantIds.has(String(candidate.valueId))).map((candidate) => ({ valueId: candidate.valueId, kind: candidate.kind, src: candidate.sourceEntityId, proof: candidate.proof?.kind, sem: candidate.proof?.sourceSemanticValueId })),
        },
        readSsa: {
          uses: readUses.map((use) => ({ sourceEntityId: use.sourceEntityId, valueId: use.valueId, kind: use.proof?.kind, sem: use.proof?.sourceSemanticValueId })),
          definitions: (result.ssa?.definitions ?? []).filter((candidate) => readValueIds.has(String(candidate.valueId))).map((candidate) => ({ valueId: candidate.valueId, kind: candidate.kind, src: candidate.sourceEntityId, proof: candidate.proof?.kind, sem: candidate.proof?.sourceSemanticValueId })),
        },
        pointerSource: {
          value: pointerValue ? { id: pointerValue.id, definitionNodeId: pointerValue.definitionNodeId, variableKey: pointerValue.variableKey } : null,
          definition: pointerDefinition ? { id: pointerDefinition.id, kind: pointerDefinition.kind, variable: pointerDefinition.variable?.physicalIdentity?.registerId ?? null, inputs: pointerDefinition.inputs } : null,
        },
        stateUses,
      };
    }), null, 2) + '\n');
    process.stderr.write(JSON.stringify(result.memorySsa?.accessMetadata?.filter((item) => item.entityKind === 'use' && item.sourceKind === 'load').map((item) => ({
      id: item.memorySsaEntityId,
      node: item.nodeId,
      region: item.regionId,
      range: item.byteRange,
      proof: item.rangeProof,
      coverage: result.memorySsa.byteCoverage?.find((coverage) => String(coverage.useId) === String(item.memorySsaEntityId)),
    })), null, 2) + '\n');
  }
  restoreCanonicalPreservedStateReads(result.legacyV1, abiAdapter);
  restoreAapcs64PublicLocations(result.legacyV1);
  propagateExactLegacyConstants(result.legacyV1);
  attachCanonicalCallArguments(result.legacyV1);
  attachCanonicalTypedCallResults(result.legacyV1, instructionByRow, abiAdapter, opts);
  invalidateEscapedStackForwarding(result.legacyV1);
  attachCanonicalFunctionReturns(result.legacyV1, abiAdapter, opts);
  if (process.env.HEX_DEBUG_C2_LEGACY === '1') {
    process.stderr.write(JSON.stringify(result.legacyV1.instructions.filter((item) => item.op === 'load').map((item) => ({
      row: item.row,
      loc: item.loc?.key,
      fwd: item.memoryForwarding?.status,
      reason: item.memoryForwarding?.reason,
      reach: item.reachingStore?.row,
      context: item.memoryForwardingContext,
    })), null, 2) + '\n');
  }
  lastSemanticV2Instrumentation = result.instrumentation;
  return result.legacyV1;
}

/**
 * Explicit semantic-engine dispatch. No v2 exception is caught and rerouted to
 * legacy; semantic-v2-compat either returns its compatibility projection or
 * fails/returns explicit unknowns from the v2 pipeline.
 */
export function buildIR(model, opts = {}) {
  const mode = normalizeMode(opts.semanticMigrationMode);
  if (mode === SEMANTIC_V2_MIGRATION_MODES.LEGACY) return buildLegacyIR(model, opts);
  lastSemanticV2Instrumentation = null;
  return buildV2CompatFromLegacyModel(model, opts);
}
