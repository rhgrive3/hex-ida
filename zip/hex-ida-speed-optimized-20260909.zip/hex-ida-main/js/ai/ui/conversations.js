/*
 * Conversations: the state behind "New chat" and the recent-chat list.
 *
 * A conversation owns everything a turn was asked under — transcript, mode,
 * style, scope and the provider/model selection — so switching chats is a
 * pointer change, never a replay. The id is stable and travels to the engine
 * as `conversationId`, which is what binds a UI chat to a runtime session.
 *
 * Persistence is deliberately small: the UI transcript only, bounded by
 * conversation count, turn count and text length, bucketed per binary so one
 * binary never shows another binary's chat. Evidence and binary data are never
 * copied into storage — a restored turn renders as its answer text.
 *
 * Pure module — no DOM. Tested by tests/ai-ui-conversations.mjs.
 */
import { normalizeResponse } from '../render/normalize.js';

export const MAX_CONVERSATIONS = 20;
export const MAX_PERSISTED_TURNS = 40;
export const MAX_PERSISTED_TEXT = 4000;
export const MAX_PERSISTED_ERROR = 400;
export const MAX_TITLE = 28;
export const LEGACY_STORAGE_KEY = 'hex.ai.conversations.v1';
export const STORAGE_KEY = 'hex.ai.conversations.v2';

let counter = 0;
/** Ids stay unique inside a page even when two conversations are made in the same millisecond. */
export function newConversationId() {
  counter += 1;
  return 'c-' + Date.now().toString(36) + '-' + counter.toString(36);
}

export function createConversation(fields = {}) {
  const now = Date.now();
  return {
    id: fields.id || newConversationId(),
    title: String(fields.title || ''),
    createdAt: fields.createdAt || now,
    updatedAt: fields.updatedAt || now,
    turns: Array.isArray(fields.turns) ? fields.turns : [],
    mode: fields.mode || 'chat',
    style: fields.style || 'beginner',
    scope: fields.scope || 'auto',
    provider: fields.provider || null,
    model: fields.model || null,
    reasoning: fields.reasoning || null,
    namespace: fields.namespace == null ? null : String(fields.namespace),
    busy: false,
    controller: null,
    lastQuestion: fields.lastQuestion || null,
  };
}

/**
 * A title from the first question, without an LLM call.
 *
 * Truncation is the whole trick: a question already says what the chat is
 * about, so the list only needs its head, with the trailing question mark
 * dropped because every row would otherwise end the same way.
 */
export function deriveTitle(question) {
  const text = String(question || '').replace(/\s+/g, ' ').trim();
  if (!text) return '';
  const head = text.split(/[\n。．.!?！？]/)[0].trim() || text;
  const clean = head.replace(/[？?！!、,。．.\s]+$/, '');
  const source = clean || head;
  return source.length > MAX_TITLE ? source.slice(0, MAX_TITLE - 1) + '…' : source;
}

export function conversationTitle(conversation, ja = true) {
  if (conversation && conversation.title) return conversation.title;
  return ja ? '新しいチャット' : 'New chat';
}

/* ── persistence ────────────────────────────────────────────── */

/** Keep the UTF-16 storage cap without cutting a supplementary code point. */
function persistedErrorDetail(value) {
  const text = String(value);
  let end = Math.min(text.length, MAX_PERSISTED_ERROR);
  if (end > 0 && end < text.length) {
    const last = text.charCodeAt(end - 1);
    const next = text.charCodeAt(end);
    if (last >= 0xd800 && last <= 0xdbff && next >= 0xdc00 && next <= 0xdfff) end--;
  }
  return text.slice(0, end);
}

function serializeTurn(turn) {
  const base = { role: turn.role, mode: turn.mode, style: turn.style, scope: turn.scope, at: turn.at || Date.now() };
  if (turn.role === 'user') return { ...base, text: String(turn.text || '').slice(0, MAX_PERSISTED_TEXT) };
  const answer = turn.response && turn.response.answerText ? turn.response.answerText : turn.text;
  const record = { ...base, status: turn.status === 'running' ? 'cancelled' : turn.status, text: String(answer || '').slice(0, MAX_PERSISTED_TEXT) };
  if (record.status === 'error' && turn.error) record.error = persistedErrorDetail(turn.error);
  return record;
}

function reviveTurn(raw, index) {
  const mode = raw.mode || 'chat';
  const style = raw.style || 'beginner';
  const scope = raw.scope || 'auto';
  const text = String(raw.text || '');
  const base = { id: 'r' + index + '-' + Math.random().toString(36).slice(2, 7), mode, style, scope, at: raw.at || Date.now() };
  if (raw.role === 'user') return { ...base, role: 'user', text };
  const status = raw.status === 'running' ? 'cancelled' : (raw.status || 'done');
  const error = status === 'error' && raw.error ? persistedErrorDetail(raw.error) : null;
  return {
    ...base, role: 'assistant', status,
    effectiveScope: scope, activity: [], error, text: '',
    response: text ? normalizeResponse({ answer: text }, { mode, style }) : null,
  };
}

export function serializeConversation(conversation) {
  return {
    id: conversation.id, title: conversation.title,
    createdAt: conversation.createdAt, updatedAt: conversation.updatedAt,
    mode: conversation.mode, style: conversation.style, scope: conversation.scope,
    provider: conversation.provider, model: conversation.model, reasoning: conversation.reasoning,
    lastQuestion: conversation.lastQuestion || null,
    turns: conversation.turns.slice(-MAX_PERSISTED_TURNS).map(serializeTurn),
  };
}

export function reviveConversation(raw, namespace) {
  const turns = Array.isArray(raw && raw.turns) ? raw.turns.map(reviveTurn) : [];
  return createConversation({ ...raw, turns, namespace });
}
/**
 * Bounded localStorage for chat history.
 *
 * `namespace()` is read late, so a binary switch writes to a different bucket
 * instead of merging two binaries' chats. A storage failure (private mode, a
 * full quota) is not an error the user should ever see: history is a
 * convenience, the live conversation lives in memory.
 */
const MAX_NAMESPACES = 6;
const INDEX_KEY = 'hex.ai.conversations.v2.index';

// The managed index metadata and a conversation bucket share one flat keyspace
// (`${key}.${namespace}`), so a namespace literally named `index` would turn the
// index key into a data bucket: save() would overwrite the conversations with
// the index object and load() would return an empty history (#5789). The
// reserved name fails closed instead of colliding.
const RESERVED_NAMESPACE = 'index';

export function createConversationStore({ namespace, storage, key = STORAGE_KEY } = {}) {
  const backing = () => {
    if (storage) return storage;
    try { return typeof localStorage === 'undefined' ? null : localStorage; } catch { return null; }
  };
  const currentNamespace = () => {
    let value = null;
    try { value = typeof namespace === 'function' ? namespace() : namespace; } catch { value = null; }
    return value == null || value === '' ? 'default' : String(value);
  };
  // Re-canonicalize defensively: a boxed/coercible key (e.g. `new String(...)`
  // with a throwing toString) must never alias the default store's bucket or
  // index paths, and custom stores must not own the legacy v1 key.
  const storageKey = (() => {
    try { return String(key); } catch { return null; }
  })();
  // `index` is the managed-metadata component (`INDEX_KEY` / `${key}.index`):
  // a bucket rooted at it would alias conversation data onto the index key,
  // deterministically destroying history (#5789). That namespace fails closed
  // at the storage boundary — same contract as quota/private-mode failures:
  // nothing persists, nothing corrupts, the live conversation stays in memory.
  const isReservedNamespace = (space) => space === RESERVED_NAMESPACE;
  const bucketKey = (space) => `${storageKey}.${space}`;
  const indexKey = () => storageKey === STORAGE_KEY ? INDEX_KEY : `${storageKey}.index`;
  const ownsLegacyStorage = storageKey === STORAGE_KEY;

  const readIndex = () => {
    const store = backing();
    if (!store) return nullIndex();
    try {
      const raw = store.getItem(indexKey());
      const parsed = raw ? JSON.parse(raw) : null;
      return parsed && typeof parsed === 'object' ? toNullIndex(parsed) : nullIndex();
    } catch { return nullIndex(); }
  };

  const writeIndex = (index) => {
    const store = backing();
    if (!store) return false;
    try {
      store.setItem(indexKey(), JSON.stringify(index));
      return true;
    } catch { return false; }
  };

  // Namespace strings are arbitrary, so the index must treat prototype
  // sensitive keys (`__proto__`, `constructor`, `prototype`) as plain data.
  // A prototypeful object would route `index['__proto__'] = ...` through the
  // inherited setter and silently drop the entry, leaving the bucket outside
  // clear()/eviction accounting. A null-prototype map keeps every namespace
  // an own enumerable property while JSON round-trips stay compatible.
  const nullIndex = () => Object.create(null);
  const toNullIndex = (source) => {
    const index = nullIndex();
    for (const [name, value] of Object.entries(source)) index[name] = value;
    return index;
  };
  const setEntry = (index, name, value) => {
    Object.defineProperty(index, name, { value, enumerable: true, configurable: true, writable: true });
  };
  const dropEntry = (index, name) => {
    if (Object.prototype.hasOwnProperty.call(index, name)) delete index[name];
  };

  const migrateLegacyIfNeeded = () => {
    if (!ownsLegacyStorage) return;
    const store = backing();
    if (!store) return;
    try {
      const legacyRaw = store.getItem(LEGACY_STORAGE_KEY);
      if (!legacyRaw) return;
      const legacyAll = JSON.parse(legacyRaw);
      if (legacyAll && typeof legacyAll === 'object') {
        const index = readIndex();
        for (const [sp, list] of Object.entries(legacyAll)) {
          if (Array.isArray(list) && list.length) {
            const bk = bucketKey(sp);
            if (!store.getItem(bk)) {
              store.setItem(bk, JSON.stringify(list));
              setEntry(index, sp, lastTouched(list));
            }
          }
        }
        writeIndex(index);
        store.removeItem(LEGACY_STORAGE_KEY);
      }
    } catch { /* best effort */ }
  };

  return {
    get key() {
      return isReservedNamespace(currentNamespace()) ? null : bucketKey(currentNamespace());
    },
    namespace: currentNamespace,
    available: () => !!backing(),
    load(space = currentNamespace()) {
      const store = backing();
      if (!store) return [];
      if (isReservedNamespace(space)) return [];
      migrateLegacyIfNeeded();
      try {
        const raw = store.getItem(bucketKey(space));
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) return parsed.map((item) => reviveConversation(item, space));
        }
        if (ownsLegacyStorage) {
          const legacyRaw = store.getItem(LEGACY_STORAGE_KEY);
          if (legacyRaw) {
            const parsed = JSON.parse(legacyRaw);
            if (parsed && typeof parsed === 'object' && Array.isArray(parsed[space])) {
              return parsed[space].map((item) => reviveConversation(item, space));
            }
          }
        }
      } catch { return []; }
      return [];
    },
    save(conversations, space = currentNamespace()) {
      const store = backing();
      if (!store) return false;
      if (isReservedNamespace(space)) return false;
      migrateLegacyIfNeeded();
      const keep = conversations
        .filter((item) => item.turns.length)
        .slice(-MAX_CONVERSATIONS)
        .map(serializeConversation);

      const bk = bucketKey(space);
      const index = readIndex();
      try {
        if (keep.length) {
          store.setItem(bk, JSON.stringify(keep));
          setEntry(index, space, lastTouched(keep));
        } else {
          store.removeItem(bk);
          dropEntry(index, space);
        }
      } catch { return false; }

      const spaces = Object.keys(index);
      if (spaces.length > MAX_NAMESPACES) {
        const ranked = spaces
          .filter((name) => name !== space && !isReservedNamespace(name))
          .sort((a, b) => (index[a] || 0) - (index[b] || 0));
        for (const name of ranked.slice(0, spaces.length - MAX_NAMESPACES)) {
          dropEntry(index, name);
          try { store.removeItem(bucketKey(name)); } catch { /* best effort */ }
        }
      }
      writeIndex(index);
      return true;
    },
    clear() {
      const store = backing();
      if (!store) return;
      try {
        const index = readIndex();
        for (const space of Object.keys(index)) {
          if (isReservedNamespace(space)) continue;
          try { store.removeItem(bucketKey(space)); } catch { /* best effort */ }
        }
        store.removeItem(indexKey());
        if (ownsLegacyStorage) store.removeItem(LEGACY_STORAGE_KEY);
      } catch { /* best effort */ }
    },
  };
}

function lastTouched(bucket) {
  if (!Array.isArray(bucket) || !bucket.length) return 0;
  return bucket.reduce((max, item) => Math.max(max, item.updatedAt || 0), 0);
}

export default { createConversation, createConversationStore, deriveTitle, conversationTitle };
