import { aiBudget, AIError } from '../schema.js';
import { normalizeTurnRequest, validateAIResult, validateModelDecision } from '../validation.js';
import { createTurnSnapshot, createSnapshotContext } from './snapshot.js';
import { ScopeController } from './scope.js';
import { routeIntent, shouldRunPlanner } from '../routing/intent.js';
import { selectToolWindow } from './tool-window.js';
import { assertWireBudget, providerCapabilities, semanticBudgetFor } from '../budget/wire.js';
import { createHexToolRegistry } from '../tools/index.js';
import {
  addressString, assertLiveBindingsUnchanged, compactCandidate, deterministicDecision,
  createMonotonicClock, ensureRunning, humanError, maxWireUsage, memoryAnchor, normalizeError, providerDiagnostics,
  remainingTime, requiredScopeForTool, resolveMonotonicClock, sessionMatchesSnapshot, stableStringify, wireMeta,
} from './runtime-support.js';

const MIN_MODEL_REPAIR_REMAINING_MS = 45000;

function normalizeExternalSignal(value) {
  if (value == null) return null;
  if ((typeof value !== 'object' && typeof value !== 'function')
      || typeof value.aborted !== 'boolean'
      || typeof value.addEventListener !== 'function'
      || typeof value.removeEventListener !== 'function') {
    throw new AIError('invalid_model_output', 'AI turn signal must be AbortSignal-compatible.');
  }
  return value;
}

export async function executeTurn(input = {}, options = {}) {
    const request = normalizeTurnRequest(input);
    const budgetOverrides = { ...request.budget, ...options.budget };
    const providerTimeout = this.provider?.turnTimeoutMs?.(request.mode, request);
    const providerHasNoDefaultTimeout = providerTimeout == null;
    if (budgetOverrides.timeoutMs == null && !providerHasNoDefaultTimeout) {
      const providerDefault = Number(providerTimeout);
      budgetOverrides.timeoutMs = Number.isFinite(providerDefault) && providerDefault > 0
        ? Math.floor(providerDefault)
        : (request.mode === 'agent' ? 120000 : 30000);
    }
    const budget = aiBudget(request.mode, budgetOverrides);
    const providerDefault = Number(providerTimeout);
    const turnTimeoutMs = Number.isFinite(providerDefault) && providerDefault > 0
      ? Math.min(budget.timeoutMs, Math.floor(providerDefault))
      : budget.timeoutMs;
    const monotonicNow = createMonotonicClock(resolveMonotonicClock(options.clock, options.monotonicNow, options.now));
    const started = monotonicNow(), activity = [], observations = [];
    let modelCalls = 0, toolCalls = 0, contextBytes = 0, plan = null, decision = null, limitReason = null;
    let wireUsage = { semanticContextBytes: 0, toolSchemaBytes: 0, historyBytes: 0, wireBytes: 0, estimatedInputTokens: 0 };
    const externalSignal = normalizeExternalSignal(options.signal ?? request.signal);
    if (externalSignal?.aborted) throw new AIError('cancelled', 'AI investigation was cancelled.');
    const turnController = new AbortController();
    const externalAbort = () => turnController.abort(externalSignal?.reason || 'cancelled');
    if (externalSignal) { externalSignal.addEventListener('abort', externalAbort, { once: true }); if (externalSignal.aborted) externalAbort(); }
    const deadline = Number.isFinite(turnTimeoutMs) ? setTimeout(() => turnController.abort('timeout'), turnTimeoutMs) : null;
    this.activeControllers.add(turnController);
    const signal = turnController.signal;
    const addActivity = (event) => {
      const value = { ...event, timestamp: event.timestamp || new Date().toISOString() };
      activity.push(value); if (typeof options.onActivity === 'function') options.onActivity(value);
    };

    try {
      ensureRunning(signal, started, turnTimeoutMs, monotonicNow);
      const snapshot = createTurnSnapshot(this.localContext, request);
      const intent = request.intent || routeIntent(request.goal, snapshot);
      request.intent = intent;
      const scopeController = new ScopeController(snapshot, request.scope, { onExpand: addActivity });
      scopeController.ensureForIntent(intent);
      request.effectiveScope = scopeController.effectiveScope;
      const snapshotContext = createSnapshotContext(this.localContext, snapshot, scopeController);

      let session = request.sessionId ? await this.sessionStore.get(request.sessionId) : null;
      ensureRunning(signal, started, turnTimeoutMs, monotonicNow);
      if (session && !sessionMatchesSnapshot(session, snapshot)) {
        throw new AIError('scope_violation', 'The requested AI session belongs to a different binary or project.');
      }
      if (!session) {
        session = await this.sessionStore.create({
          binaryId: snapshot.binaryId, binaryIdentity: snapshot.binaryIdentity, projectId: snapshot.projectIdentity, conversationId: request.conversationId || null,
          mode: request.mode, style: request.style, scope: request.scope, effectiveScope: scopeController.effectiveScope, goal: request.goal,
          investigationMemory: { goal: request.goal, anchor: memoryAnchor(snapshot, scopeController.effectiveScope) },
        });
      }

      const stores = this.storesFor(session, snapshot.binaryId);
      // Turn-local store references: the shared `this.*Store` projection below
      // is only a post-turn introspection pointer. Every execution read in this
      // turn uses the captured references — a concurrent turn on the same
      // runtime re-points the shared fields across awaits, and this turn must
      // never read or write the other turn's stores (#6216).
      const evidenceStore = stores.evidenceStore, hypothesisStore = stores.hypothesisStore, proposalStore = stores.proposalStore;
      this.evidenceStore = evidenceStore; this.hypothesisStore = hypothesisStore; this.proposalStore = proposalStore;
      const registry = createHexToolRegistry(snapshotContext, {
        evidenceStore: evidenceStore, maxFunctions: budget.maxFunctions, maxDisassembly: budget.maxDisassembly, onActivity: addActivity,
      });

      await this.sessionStore.update(session.id, {
        mode: request.mode, style: request.style, scope: request.scope, effectiveScope: scopeController.effectiveScope, goal: request.goal,
        conversationId: request.conversationId ?? session.conversationId ?? null,
        binaryIdentity: snapshot.binaryIdentity, projectId: snapshot.projectIdentity,
      });
      await this.sessionStore.updateMemory(session.id, { goal: request.goal, anchor: memoryAnchor(snapshot, scopeController.effectiveScope) });
      await this.sessionStore.appendMessage(session.id, { role: 'user', content: request.goal });
      session = await this.sessionStore.get(session.id);
      addActivity({ type: 'turn-start', label: request.mode === 'agent' ? '調査を開始' : '質問を解析', intent, requestedScope: request.scope, effectiveScope: scopeController.effectiveScope, snapshotId: snapshot.id });

      try {
        ensureRunning(signal, started, turnTimeoutMs, monotonicNow);
        if (this.planner && shouldRunPlanner(request, snapshot, intent)) {
          assertLiveBindingsUnchanged(this.localContext, snapshot);
          addActivity({ type: 'plan-start', label: '決定論的候補探索を開始' });
          plan = await this.planner(request.goal, snapshotContext, {
            maxFunctions: budget.maxFunctions, maxDisassembly: budget.maxDisassembly,
            maxSearchResults: request.maxSearchResults || 40,
            timeoutMs: Math.max(1, Math.min(turnTimeoutMs, request.plannerTimeoutMs || 15000)),
            isCancelled: () => !!signal?.aborted || monotonicNow() - started >= turnTimeoutMs,
            tools: registry.legacyTools,
          });
          assertLiveBindingsUnchanged(this.localContext, snapshot);
          const plannedEvidence = evidenceStore.ingestPlan(plan);
          observations.push({
            tool: 'deterministic_goal_planner', summary: `${plan.candidates?.length || 0} ranked candidates`, evidenceIds: plannedEvidence.map((item) => item.id),
            data: { candidates: (plan.candidates || []).slice(0, 20).map(compactCandidate), best: plan.best ? { address: addressString(plan.best.address), name: plan.best.name, verified: !!plan.best.verification?.verified } : null, missingEvidence: plan.missingEvidence || [] },
          });
          addActivity({ type: 'candidate-update', label: `候補を ${plan.candidates?.length || 0} 関数に絞り込み`, count: plan.candidates?.length || 0 });
          if (plan.exhausted) addActivity({ type: 'budget', label: '決定論的 planner の予算上限に到達' });
        } else if (request.mode === 'agent') addActivity({ type: 'plan-skip', label: '現在の質問は局所解析で解決可能なため planner を省略', intent });

        if (!this.provider || typeof this.provider.nextTurn !== 'function') decision = deterministicDecision(plan, request);
        else {
          if (typeof this.provider.prepareCapabilities === 'function') {
            await this.provider.prepareCapabilities({ signal, timeoutMs: Math.min(5000, remainingTime(started, turnTimeoutMs, monotonicNow)) });
            ensureRunning(signal, started, turnTimeoutMs, monotonicNow);
          }
          const seenCalls = new Map(); let repairs = 0;
          while (modelCalls < budget.maxModelCalls) {
            ensureRunning(signal, started, turnTimeoutMs, monotonicNow);
            request.effectiveScope = scopeController.effectiveScope;
            const caps = providerCapabilities(this.provider);
            const maxTools = Math.max(1, Math.min(10, typeof caps.maxTools === 'number' && Number.isFinite(caps.maxTools) && caps.maxTools > 0 ? Math.floor(caps.maxTools) : 10));
            const window = selectToolWindow(registry, { mode: request.mode, requestedScope: request.scope, effectiveScope: scopeController.effectiveScope, intent, observations, hypotheses: hypothesisStore.all(), maxTools });
            const tools = window.tools;
            if (!tools.length) throw new AIError('invalid_tool_call', `No model-visible tools are available in ${scopeController.effectiveScope} scope.`);
            const messages = session.messages.slice(-8).map(({ role, content }) => ({ role, content }));
            const semanticBytes = semanticBudgetFor({ messages, tools, meta: wireMeta(request, scopeController, intent, session.id), capabilities: caps, configuredBytes: budget.contextBytes });
            const built = this.contextBroker.buildModelContext({
              request, session, evidenceStore: evidenceStore, hypotheses: hypothesisStore.all(), observations,
              budgetBytes: semanticBytes, snapshot, effectiveScope: scopeController.effectiveScope, includeHistory: false,
            });
            contextBytes = Math.max(contextBytes, built.bytes);
            const payloadForBudget = { messages, context: built.context, tools, meta: wireMeta(request, scopeController, intent, session.id) };
            const measured = assertWireBudget(payloadForBudget, caps);
            wireUsage = maxWireUsage(wireUsage, measured);
            let next;
            try {
              modelCalls++;
              addActivity({ type: 'model-start', label: '次の解析手順を選択', phase: window.phase, toolCount: tools.length, effectiveScope: scopeController.effectiveScope });
              next = await this.provider.nextTurn({
                sessionId: session.id, mode: request.mode, style: request.style,
                conversationId: request.conversationId || null,
                provider: request.provider || null,
                model: request.model || null,
                reasoning: request.reasoning || null,
                scope: scopeController.effectiveScope, requestedScope: request.scope, effectiveScope: scopeController.effectiveScope,
                intent, task: request.task || null, messages, context: built.context, tools,
              }, {
                signal,
                ...(Number.isFinite(turnTimeoutMs) ? { timeoutMs: remainingTime(started, turnTimeoutMs, monotonicNow) } : {}),
              });
              const visibleToolNames = tools.map((tool) => tool.name);
              const previousTool = observations.length ? observations[observations.length - 1]?.tool : null;
              if (
                next?.type === 'tool'
                && previousTool
                && next.tool === previousTool
                && registry.has(previousTool)
                && scopeController.scopeAllowsTool(scopeController.effectiveScope, previousTool, next.arguments)
                && !visibleToolNames.includes(previousTool)
              ) visibleToolNames.push(previousTool);
              next = validateModelDecision(next, visibleToolNames);
            } catch (error) {
              const normalized = normalizeError(error, signal);
              const repairable = normalized.type === 'invalid_model_output' || normalized.type === 'invalid_tool_call';
              if (repairable && repairs === 0 && modelCalls < budget.maxModelCalls) {
                const repairRemainingMs = Number.isFinite(turnTimeoutMs) ? remainingTime(started, turnTimeoutMs, monotonicNow) : null;
                if (repairRemainingMs == null || repairRemainingMs >= MIN_MODEL_REPAIR_REMAINING_MS) {
                  repairs++;
                  observations.push({ tool: 'protocol_guardrail', summary: `Previous model response rejected: ${normalized.message}`, evidenceIds: [] });
                  addActivity({ type: 'model-repair', label: 'モデル出力の形式を1回だけ再確認', ...(repairRemainingMs == null ? {} : { remainingMs: repairRemainingMs }) });
                  continue;
                }
                addActivity({ type: 'model-repair-skip', label: '残り時間が少ないためモデル出力の再確認を省略', remainingMs: repairRemainingMs });
              }
              throw normalized;
            }
            addActivity({ type: 'model-result', label: next.type === 'tool' ? `ツール ${next.tool} を選択` : '回答候補を生成' });
            if (next.type === 'final') { decision = next; break; }
            if (toolCalls >= budget.maxToolCalls) { limitReason = 'tool-call-budget'; break; }
            if (registry.accounting.cost + registry.costWeight(next.tool) > budget.maxCost) { limitReason = 'tool-cost-budget'; break; }
            const signature = `${next.tool}:${stableStringify(next.arguments)}`;
            const repeated = (seenCalls.get(signature) || 0) + 1; seenCalls.set(signature, repeated);
            if (repeated > 2) { limitReason = 'repeated-tool-loop'; break; }

            const requiredScope = requiredScopeForTool(next.tool);
            if (requiredScope) scopeController.expandTo(requiredScope, next.purpose || next.tool);
            request.effectiveScope = scopeController.effectiveScope;
            assertLiveBindingsUnchanged(this.localContext, snapshot);
            scopeController.assertToolCall(next.tool, next.arguments);
            const observation = await registry.execute(next.tool, next.arguments, { scope: scopeController.effectiveScope, signal });
            toolCalls++;
            observations.push({ tool: next.tool, summary: observation.summary, evidenceIds: observation.evidenceIds, data: observation.modelData });
            await this.sessionStore.updateMemory(session.id, { importantPriorActions: [{ tool: next.tool, summary: observation.summary, evidenceIds: observation.evidenceIds }] });
            session = await this.sessionStore.get(session.id);
          }
          if (!decision && !limitReason && modelCalls >= budget.maxModelCalls) limitReason = 'model-call-budget';
        }
      } catch (error) {
        const normalized = normalizeError(error, signal);
        // A cancelled turn must surface as a cancelled rejection: it is never
        // a fallback answer, and cancelled turns finalize/persist nothing
        // (#5632). Timeout/budget limits keep the deterministic fallback.
        if (normalized.type === 'cancelled') throw normalized;
        // Live-binding violations must never become a fallback decision.
        // The inner catch runs caller-supplied onActivity synchronously, so a
        // drift detected at the planner boundary could otherwise be masked by
        // restoring the bindings before the final guard. Latch fail-closed.
        if (normalized.type === 'scope_violation') throw normalized;
        limitReason = normalized.type;
        addActivity({ type: 'error', errorType: normalized.type, label: humanError(normalized), ...(providerDiagnostics(normalized) || {}) });
        if (!decision) decision = deterministicDecision(plan, request, normalized);
      }

      assertLiveBindingsUnchanged(this.localContext, snapshot);
      if (!decision) decision = deterministicDecision(plan, request, new AIError('budget_exhausted', 'The investigation budget was exhausted.'));
      // The deadline/cancellation contract holds to the final return: a turn
      // whose budget expired during finalization must not resolve as a normal
      // success (#5606). A cancelled turn rejects (see the catch above); a
      // timed-out turn keeps the graceful budget-exhausted policy.
      const assertDeadlineHonest = () => {
        try { ensureRunning(signal, started, turnTimeoutMs, monotonicNow); }
        catch (error) {
          if (error instanceof AIError && error.type === 'cancelled') throw error;
          if (!limitReason) limitReason = error instanceof AIError ? error.type : 'budget_exhausted';
        }
      };
      assertDeadlineHonest();
      const result = await this.finalize({ request, decision, plan, activity, modelCalls, toolCalls, contextBytes, wireUsage, started, monotonicNow, limitReason, registry, snapshot, effectiveScope: scopeController.effectiveScope, stores: { evidenceStore, hypothesisStore, proposalStore }, signal });
      // Every asynchronous persistence boundary gets a pre/post binding check.
      // The payloads below are snapshot-derived; a live workbench switch while
      // a persistence adapter is awaiting cannot turn this turn into a normal
      // completion or inject current runtime identity into old session memory.
      const persistWithBindingCheck = async (operation) => {
        assertLiveBindingsUnchanged(this.localContext, snapshot);
        try {
          return await operation();
        } finally {
          // A rejected write must still prove that the live binding did not
          // drift before the rejection escapes this turn.
          assertLiveBindingsUnchanged(this.localContext, snapshot);
        }
      };
      await persistWithBindingCheck(() => this.sessionStore.appendMessage(session.id, { role: 'assistant', content: result.answer }));
      await persistWithBindingCheck(() => this.sessionStore.updateMemory(session.id, {
        anchor: memoryAnchor(snapshot, scopeController.effectiveScope),
        confirmedFacts: result.evidence.filter((item) => item.status === 'verified').map((item) => ({ id: item.id, summary: item.summary || item.title, functionAddress: item.functionAddress })),
        activeHypotheses: result.hypotheses.filter((item) => item.status === 'open' || item.status === 'supported'),
        rejectedHypotheses: result.hypotheses.filter((item) => item.status === 'rejected'),
        unresolvedQuestions: result.followups,
        importantPriorActions: result.actions,
      }));
      await persistWithBindingCheck(() => this.sessionStore.update(session.id, {
        effectiveScope: scopeController.effectiveScope, hypotheses: hypothesisStore.all(),
        confirmedFindings: typeof evidenceStore.byStatus === 'function'
          ? evidenceStore.byStatus('verified')
          : evidenceStore.all().filter((item) => item.status === 'verified'), proposedActions: proposalStore.all(),
        lastActivity: activity[activity.length - 1] || null,
      }));
      result.sessionId = session.id;
      // Final honest re-check right before the successful return: an expiry
      // that fired during the persistence awaits must demote the result to
      // the budget-exhausted policy, never a clean success (#5606).
      assertDeadlineHonest();
      if (limitReason && result.limits && !result.limits.reason) result.limits = { exhausted: true, reason: limitReason };
      return validateAIResult(result);
    } finally {
      clearTimeout(deadline); this.activeControllers.delete(turnController);
      if (externalSignal) externalSignal.removeEventListener('abort', externalAbort);
    }
}