import { EVIDENCE_STATUSES } from './schema.js';
import { addressText, jsonSafe } from './validation.js';
import { evidenceStoreToCanonicalGraph } from '../core/evidence/compat.js';
import { stableDigest } from '../core/identity/index.js';

const DETERMINISTIC_VERIFICATION = Symbol('deterministic-verification');

const SEMANTIC_SOURCE_KEYS = Object.freeze([
  'id', 'kind', 'status', 'address', 'addr', 'functionAddress', 'function', 'row', 'instructionId',
  'operation', 'relation', 'location', 'source', 'sink', 'value', 'threshold', 'condition', 'operator',
  'name', 'selector', 'signature', 'confidence', 'verified', 'reason', 'evidence', 'verification',
]);

function compactSource(value) {
  const safe = jsonSafe(value);
  const text = JSON.stringify(safe);
  if (text.length <= 4096) return safe;
  if (!safe || typeof safe !== 'object' || Array.isArray(safe)) return { oversized: true, bytes: text.length, type: Array.isArray(safe) ? 'array' : typeof safe };
  const semantic = {};
  for (const key of SEMANTIC_SOURCE_KEYS) if (safe[key] !== undefined) semantic[key] = safe[key];
  return { oversized: true, bytes: text.length, semantic };
}

function firstAddress(value) {
  if (!value || typeof value !== 'object') return null;
  return addressText(value.functionAddress ?? value.function ?? value.address ?? value.addr ?? value.target);
}

/*
 * add() 境界で timestamp を canonical graph が受理できる string に限定する。
 * 欠けていれば現時点の ISO string を入れる。string 以外は保存せず拒否する
 * （fail-closed）。canonical 側の createdAt は string しか受理しない。
 */
function evidenceTimestamp(value) {
  if (value == null || value === '') return new Date().toISOString();
  if (typeof value !== 'string') throw new TypeError('evidence-invalid-timestamp');
  return value;
}

function factRows(result) {
  const rows = [];
  for (const key of ['results', 'updates', 'sites', 'functions', 'paths', 'causalPaths']) {
    const values = Array.isArray(result && result[key]) ? result[key] : [];
    values.forEach((row, index) => rows.push({ key, index, row }));
  }
  if (!rows.length && result && typeof result === 'object') rows.push({ key: 'result', index: null, row: result });
  return rows;
}

function evidenceIds(row) {
  const ids = new Set();
  if (row && typeof row.id === 'string') ids.add(row.id);
  for (const id of Array.isArray(row && row.evidence) ? row.evidence : []) {
    if (typeof id === 'string') ids.add(id);
    else if (id && typeof id.id === 'string') ids.add(id.id);
  }
  return Array.from(ids);
}

function verifiedEvidenceIds(value) {
  const ids = new Set();
  const add = (entry) => {
    if (typeof entry === 'string' && entry) ids.add(entry);
    else if (entry && typeof entry.id === 'string') ids.add(entry.id);
  };
  for (const key of ['verifiedEvidenceIds', 'verifiedEvidence', 'verifiedIds']) {
    for (const entry of Array.isArray(value && value[key]) ? value[key] : []) add(entry);
  }
  for (const entry of Array.isArray(value?.verification?.evidenceIds) ? value.verification.evidenceIds : []) add(entry);
  return ids;
}

function semanticRecord(record) {
  if (!record) return null;
  return jsonSafe({
    id: record.id,
    kind: record.kind,
    title: record.title,
    sourceTool: record.sourceTool,
    sourceBinding: record.sourceBinding || null,
    address: record.address || null,
    functionAddress: record.functionAddress || null,
    functionName: record.functionName || null,
    summary: record.summary || null,
    sourceData: record.sourceData ?? null,
    navigation: record.navigation ?? null,
  });
}

function sameSemanticRecord(left, right) {
  return JSON.stringify(semanticRecord(left)) === JSON.stringify(semanticRecord(right));
}

// Observation provenance references are identity keys, not presentation text:
// only a canonical non-empty primitive string may reach a record, so a
// structured value can never launder into another observation's identity
// (#5425). Identity fields fail closed; `path` stays a normalized projection.
function canonicalIdentityRef(value) {
  return typeof value === 'string' && value.length > 0 ? value : null;
}

// A present-but-unusable sourceRef: neither canonicalizable to a reference
// nor absent. String refs are always canonical; object refs must carry at
// least one canonical identity field; any other shape is malformed.
function malformedSourceRef(sourceRef) {
  if (sourceRef == null) return false;
  if (typeof sourceRef === 'string') return sourceRef.length === 0;
  if (typeof sourceRef !== 'object') return true;
  if (Object.hasOwn(sourceRef, 'detailRef') && sourceRef.detailRef != null && !canonicalIdentityRef(sourceRef.detailRef)) return true;
  if (Object.hasOwn(sourceRef, 'evidenceSourceId') && sourceRef.evidenceSourceId != null && !canonicalIdentityRef(sourceRef.evidenceSourceId)) return true;
  if (Object.hasOwn(sourceRef, 'bindingKey') && sourceRef.bindingKey != null && !canonicalIdentityRef(sourceRef.bindingKey)) return true;
  if (canonicalIdentityRef(sourceRef.detailRef) || canonicalIdentityRef(sourceRef.evidenceSourceId)) return false;
  return true;
}

function normalizeSourceRef(sourceRef) {
  if (!sourceRef) return null;
  if (typeof sourceRef === 'string') return { detailRef: sourceRef, path: '$' };
  if (typeof sourceRef !== 'object') return null;
  if (canonicalIdentityRef(sourceRef.detailRef)) return {
    detailRef: sourceRef.detailRef,
    path: String(sourceRef.path || '$'),
    ...(canonicalIdentityRef(sourceRef.bindingKey) ? { bindingKey: sourceRef.bindingKey } : {}),
  };
  if (canonicalIdentityRef(sourceRef.evidenceSourceId)) return { evidenceSourceId: sourceRef.evidenceSourceId, path: String(sourceRef.path || '$') };
  return null;
}

export class EvidenceStore {
  constructor(initial = [], options = {}) {
    if (!Array.isArray(initial) && initial && typeof initial === 'object') {
      options = initial;
      initial = [];
    }
    this.records = new Map();
    this.recordOrder = new Map();
    this.statusIds = new Map(EVIDENCE_STATUSES.map((status) => [status, []]));
    this.nextRecordOrder = 0;
    this.nextSourcePayloadOrder = 0;
    this.sourcePayloads = new Map();
    this.observationStore = options.observationStore || null;
    for (const evidence of initial) this.add(evidence);
  }

  restorePersistedConfirmed(initial = []) {
    for (const evidence of Array.isArray(initial) ? initial : []) {
      this.add(evidence, evidence?.status === 'verified' ? DETERMINISTIC_VERIFICATION : null);
    }
    return this;
  }

  setObservationStore(store) {
    this.observationStore = store || null;
    if (this.observationStore) {
      for (const record of this.records.values()) {
        const sourceId = record.sourceRef?.evidenceSourceId;
        if (sourceId && this.sourcePayloads.has(sourceId)) {
          const stored = this.observationStore.put({
            tool: record.sourceTool || 'evidence-source', arguments: { evidenceId: record.id },
            fullResult: this.sourcePayloads.get(sourceId), functionIdentity: record.functionAddress ?? record.address ?? null, deterministic: true, effectiveScope: record.effectiveScope || null, scopeBoundary: record.scopeBoundary || null,
          });
          record.sourceRef = { detailRef: stored.id, path: record.sourceRef.path || '$', bindingKey: stored.binding.key };
          record.sourceBinding = stored.binding.key;
          this.sourcePayloads.delete(sourceId);
        }
        if (record.sourceRef?.detailRef) this.observationStore.pin?.(record.sourceRef.detailRef);
      }
    }
    return this;
  }

  add(input, authority = null) {
    if (!input || typeof input !== 'object') return null;
    // Validate before either source-data persistence path can create durable state.
    // The same normalized value is reused for the canonical record (#5946).
    const timestamp = evidenceTimestamp(input.timestamp);
    // An explicitly supplied but malformed sourceRef is a caller contract
    // violation: rejecting the whole evidence record keeps the malformed
    // provenance from being silently replaced (new observation) or dropped
    // (no sourceRef) while sourceData persists anyway (#5425).
    if (malformedSourceRef(input.sourceRef)) return null;
    let explicitId = null;
    if (input.id != null && input.id !== '') {
      if (typeof input.id !== 'string') return null;
      explicitId = input.id.trim();
      if (!explicitId) return null;
    }
    let status = EVIDENCE_STATUSES.includes(input.status) ? input.status : 'unknown';
    if (status === 'verified' && authority !== DETERMINISTIC_VERIFICATION) status = 'supported';

    let sourceRef = normalizeSourceRef(input.sourceRef);
    let createdLocalId = null;
    if (!sourceRef && input.sourceData != null) {
      if (this.observationStore) {
        const stored = this.observationStore.put({
          tool: input.sourceTool || 'evidence-source',
          arguments: { sourceId: input.sourceId || null, evidenceKind: input.kind || 'observation' },
          fullResult: input.sourceData,
          functionIdentity: input.functionAddress ?? input.address ?? null,
          deterministic: true,
          effectiveScope: typeof input.effectiveScope === 'string' && input.effectiveScope ? input.effectiveScope : null,
          scopeBoundary: typeof input.scopeBoundary === 'string' && input.scopeBoundary ? input.scopeBoundary : null,
        });
        sourceRef = { detailRef: stored.id, path: '$', bindingKey: stored.binding.key };
      } else {
        const localId = `evsrc_${stableDigest([input.sourceTool || 'unknown', input.sourceId || null, this.nextSourcePayloadOrder++]).slice(0, 32)}`;
        this.sourcePayloads.set(localId, input.sourceData);
        createdLocalId = localId;
        sourceRef = { evidenceSourceId: localId, path: '$' };
      }
    }
    const sourceBinding = String(input.sourceBinding ?? sourceRef?.bindingKey ?? '');
    const identity = JSON.stringify(jsonSafe([
      input.sourceTool || 'unknown', input.sourceId || null, sourceBinding || null, input.address ?? null,
      input.functionAddress ?? null, input.kind || 'observation', input.title || '',
    ]));
    const id = explicitId || `ev_${stableDigest(identity).slice(0, 32)}`;
    const record = {
      id,
      kind: String(input.kind || 'observation'),
      status,
      title: String(input.title || input.kind || 'Tool evidence').slice(0, 300),
      sourceTool: String(input.sourceTool || 'unknown'),
    };
    if (sourceBinding) record.sourceBinding = sourceBinding;
    if (sourceRef) record.sourceRef = sourceRef;
    if (typeof input.effectiveScope === 'string' && input.effectiveScope) record.effectiveScope = input.effectiveScope;
    if (typeof input.scopeBoundary === 'string' && input.scopeBoundary) record.scopeBoundary = input.scopeBoundary;
    const address = addressText(input.address);
    const functionAddress = addressText(input.functionAddress);
    if (address) record.address = address;
    if (functionAddress) record.functionAddress = functionAddress;
    if (input.functionName) record.functionName = String(input.functionName).slice(0, 500);
    if (input.summary) record.summary = String(input.summary).slice(0, 2000);
    if (input.sourceData != null) record.sourceData = compactSource(input.sourceData);
    if (Number.isFinite(input.confidence)) record.confidence = Math.max(0, Math.min(1, input.confidence));
    /*
     * timestamp は canonical snapshot が要求する ISO string にここで正規化する。
     * number など string 以外をそのまま保存すると、add() は成功したのに
     * canonicalSnapshot() だけが必ず失敗する record になってしまう（#5946）。
     */
    record.timestamp = timestamp;
    if (input.navigation) record.navigation = jsonSafe(input.navigation);

    const previous = this.records.get(id);
    if (previous?.status === 'verified') {
      if (createdLocalId) this.sourcePayloads.delete(createdLocalId);
      if (!sameSemanticRecord(previous, record)) return previous;
      return previous;
    }
    if (!this.recordOrder.has(id)) this.recordOrder.set(id, this.nextRecordOrder++);
    this.records.set(id, { ...previous, ...record });
    const storedRecord = this.records.get(id);
    const previousSourceId = previous?.sourceRef?.evidenceSourceId ?? null;
    const nextSourceId = storedRecord?.sourceRef?.evidenceSourceId ?? null;
    if (previousSourceId && previousSourceId !== nextSourceId) {
      let stillReferenced = false;
      for (const item of this.records.values()) {
        if (item.sourceRef?.evidenceSourceId === previousSourceId) {
          stillReferenced = true;
          break;
        }
      }
      if (!stillReferenced) this.sourcePayloads.delete(previousSourceId);
    }
    this._indexStatus(id, previous?.status || null, storedRecord?.status || null);
    if (storedRecord?.sourceRef?.detailRef) this.observationStore?.pin?.(storedRecord.sourceRef.detailRef);
    return storedRecord;
  }

  ingest(toolName, result, { verifier = false, sourceRef = null, effectiveScope = null, scopeBoundary = null } = {}) {
    const output = result && result.result != null ? result.result : result;
    if (!output || typeof output !== 'object') return [];
    const rootSourceRef = normalizeSourceRef(sourceRef);
    const outputVerifiedIds = verifiedEvidenceIds(output);
    const rows = factRows(output);
    const created = [];
    for (const { key, index, row } of rows) {
      if (!row || typeof row !== 'object') continue;
      const ids = evidenceIds(row);
      if (!ids.length && key === 'result' && !firstAddress(row) && !output.evidence) continue;
      const addr = firstAddress(row) || firstAddress(output);
      const fnAddr = addressText(row.functionAddress ?? row.function ?? output.functionAddress ?? output.address);
      const sourceIds = ids.length ? ids : (Array.isArray(output.evidence) ? output.evidence.filter((x) => typeof x === 'string') : []);
      const rowVerifiedIds = verifiedEvidenceIds(row);
      const rowVerdict = row.verified === true || row.status === 'verified' || row.verification?.verified === true;
      const singleTopLevelVerdict = rows.length === 1 && key === 'result' && (output.verified === true || output.status === 'verified');
      const rowSourceRef = rootSourceRef ? {
        ...rootSourceRef,
        path: key === 'result' ? (rootSourceRef.path || '$') : `${rootSourceRef.path === '$' ? '$.' : `${rootSourceRef.path}.`}${key}[${index}]`,
      } : null;
      for (const sourceId of sourceIds.length ? sourceIds : [null]) {
        const sourceVerified = sourceId != null && (rowVerifiedIds.has(sourceId) || outputVerifiedIds.has(sourceId));
        const verified = verifier === true && (sourceVerified || rowVerdict || singleTopLevelVerdict);
        const status = verified ? 'verified' : 'supported';
        const kind = String(row.kind || key || 'observation');
        const evidence = this.add({
          sourceId, sourceTool: toolName, sourceRef: rowSourceRef, sourceBinding: rowSourceRef?.bindingKey,
          kind, status, address: addr, functionAddress: fnAddr,
          effectiveScope, scopeBoundary,
          functionName: row.functionName || row.name || output.name,
          title: `${toolName}: ${kind}`,
          summary: summarizeRow(row), sourceData: row,
          confidence: Number.isFinite(row.confidence) ? row.confidence : (status === 'verified' ? 1 : 0.75),
          navigation: addr ? { address: addr } : undefined,
        }, verified ? DETERMINISTIC_VERIFICATION : null);
        if (evidence) created.push(evidence);
      }
    }
    return uniqueById(created);
  }

  ingestPlan(plan) {
    const out = [];
    /*
     * 決定的検証 authority の照合に使う identity は、canonical に潰せない値を
     * 受理しない。address は addressText() で正規化できる表現だけ、evidence ID は
     * primitive string だけを比較する。jsonSafe() のような打切り projection で
     * hash すると、打切り範囲外だけが異なる別値を同一視できる（#5952）。
     */
    const addressIdentity = (value) => {
      const text = addressText(value);
      return text == null ? null : `address:${text}`;
    };
    const evidenceIdIdentity = (value) =>
      typeof value === 'string' && value.length > 0 ? `id:${value}` : null;
    for (const candidate of plan && plan.candidates || []) {
      const isVerifiedBest = !!(candidate.verification?.verified && plan.best
        && addressIdentity(plan.best.address) !== null
        && addressIdentity(plan.best.address) === addressIdentity(candidate.address));
      const explicitlyVerified = new Set([
        ...(candidate.verification?.evidenceIds || []),
        ...(candidate.verification?.verifiedEvidenceIds || []),
      ].map((id) => evidenceIdIdentity(id)).filter((id) => id !== null));
      for (const sourceId of candidate.evidence || []) {
        const verified = isVerifiedBest && explicitlyVerified.has(evidenceIdIdentity(sourceId));
        out.push(this.add({
          sourceId, sourceTool: 'deterministic-goal-planner', kind: 'candidate-source', status: verified ? 'verified' : 'supported',
          functionAddress: candidate.address, functionName: candidate.name,
          title: `${verified ? 'Verified' : 'Ranked'} source for ${candidate.name || addressText(candidate.address)}`,
          summary: `Deterministic score ${candidate.score}; sources: ${(candidate.sources || []).join(', ')}`,
          sourceData: { score: candidate.score, sources: candidate.sources, sourceId }, confidence: verified ? 1 : 0.75,
        }, verified ? DETERMINISTIC_VERIFICATION : null));
      }
      if (isVerifiedBest) {
        out.push(this.add({
          sourceTool: 'deterministic-goal-planner',
          sourceId: `candidate:${addressText(candidate.address) || String(candidate.address)}`,
          kind: 'candidate-verification', status: 'verified',
          functionAddress: candidate.address, functionName: candidate.name,
          title: `Verified candidate ${candidate.name || addressText(candidate.address)}`,
          summary: `Deterministic verifier confirmed the candidate; score ${candidate.score}.`,
          sourceData: { score: candidate.score, sources: candidate.sources, verification: candidate.verification }, confidence: 1,
        }, DETERMINISTIC_VERIFICATION));
      }
    }
    return uniqueById(out.filter(Boolean));
  }

  _indexStatus(id, previousStatus, nextStatus) {
    if (previousStatus === nextStatus) return;
    if (previousStatus && this.statusIds.has(previousStatus)) {
      const previous = this.statusIds.get(previousStatus);
      const at = previous.indexOf(id);
      if (at >= 0) previous.splice(at, 1);
    }
    if (!nextStatus) return;
    if (!this.statusIds.has(nextStatus)) this.statusIds.set(nextStatus, []);
    const target = this.statusIds.get(nextStatus);
    const order = this.recordOrder.get(id) ?? Number.MAX_SAFE_INTEGER;
    let low = 0, high = target.length;
    while (low < high) {
      const mid = (low + high) >> 1;
      const other = this.recordOrder.get(target[mid]) ?? Number.MAX_SAFE_INTEGER;
      if (other < order) low = mid + 1; else high = mid;
    }
    target.splice(low, 0, id);
  }

  recentByStatus(status, limit = 32) {
    const ids = this.statusIds.get(String(status)) || [];
    const count = Math.max(0, Math.trunc(Number(limit) || 0));
    const start = Math.max(0, ids.length - count);
    const out = [];
    for (let index = start; index < ids.length; index++) {
      const record = this.records.get(ids[index]);
      if (record) out.push(record);
    }
    return out;
  }

  byStatus(status) {
    const ids = this.statusIds.get(String(status)) || [];
    const out = [];
    for (const id of ids) { const record = this.records.get(id); if (record) out.push(record); }
    return out;
  }

  sourceDataFor(id) {
    const record = typeof id === 'object' ? id : this.get(id);
    if (!record?.sourceRef?.evidenceSourceId) return null;
    return this.sourcePayloads.get(record.sourceRef.evidenceSourceId) ?? null;
  }

  has(id) { return typeof id === 'string' && id.length > 0 ? this.records.has(id) : false; }
  get(id) { return typeof id === 'string' && id.length > 0 ? (this.records.get(id) || null) : null; }
  all() { return Array.from(this.records.values()); }
  pinned(ids) { return (ids || []).map((id) => this.get(id)).filter(Boolean); }
  hasAddress(value) {
    const address = addressText(value);
    return !!address && this.all().some((item) => item.address === address || item.functionAddress === address);
  }
  verifiedIds() { return this.byStatus('verified').map((item) => item.id); }
  canonicalSnapshot() { return evidenceStoreToCanonicalGraph(this); }
}

function summarizeRow(row) {
  const parts = [];
  for (const key of ['kind', 'operation', 'relation', 'name', 'text', 'reason']) if (row[key] != null) parts.push(`${key}=${String(row[key]).slice(0, 300)}`);
  const addr = firstAddress(row);
  if (addr) parts.push(`address=${addr}`);
  return parts.join('; ').slice(0, 2000) || 'Deterministic tool observation';
}

function uniqueById(values) {
  return Array.from(new Map(values.map((value) => [value.id, value])).values());
}
