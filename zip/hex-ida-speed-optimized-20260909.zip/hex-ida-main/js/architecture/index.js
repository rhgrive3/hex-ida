import {
  architecturePluginV2,
  architecturePluginsV2,
  ArchitecturePluginV2,
  registerArchitecturePlugin,
  canonicalArchitectureId,
  normalizeArchitecturePositiveInteger,
} from '../targets/architecture/index.js';

const ADAPTER_CACHE = new WeakMap();
const MAX_SAFE_ROW = BigInt(Number.MAX_SAFE_INTEGER);

function normalizeArchitectureAddress(value) {
  if (typeof value === 'bigint') return value;
  if (typeof value === 'number') return Number.isSafeInteger(value) ? BigInt(value) : null;
  if (typeof value !== 'string') return null;
  const text = value.trim();
  if (!/^(?:[+-]?\d+|[+-]?0[xX][0-9a-fA-F]+)$/.test(text)) return null;
  try { return BigInt(text); } catch { return null; }
}

function ownTruthy(object, key) {
  return object != null && Object.prototype.hasOwnProperty.call(object, key) && !!object[key];
}

function normalizeAdapterHook(value, name, fallback = null) {
  if (value === undefined) return fallback;
  if (typeof value !== 'function') throw new TypeError(`${name} must be a function`);
  return value;
}

export class ArchitectureAdapter {
  constructor(definition) {
    const id = canonicalArchitectureId(definition?.id);
    if (!id) throw new TypeError('architecture id is required');
    this.id = id;
    this.instructionAlignment = normalizeArchitecturePositiveInteger(definition.instructionAlignment ?? 1, 'instructionAlignment');
    this.fixedInstructionSize = normalizeArchitecturePositiveInteger(definition.fixedInstructionSize, 'fixedInstructionSize', { nullable: true });
    this.viewerCompatible = !!definition.viewerCompatible;
    this.decode = normalizeAdapterHook(definition.decode, 'decode');
    this.assemble = normalizeAdapterHook(definition.assemble, 'assemble');
    this.controlFlow = normalizeAdapterHook(definition.controlFlow, 'controlFlow', () => null);
    this.callKind = normalizeAdapterHook(definition.callKind, 'callKind', () => null);
    this.returnKind = normalizeAdapterHook(definition.returnKind, 'returnKind', () => null);
    this.rowForAddress = normalizeAdapterHook(definition.rowForAddress, 'rowForAddress', (region, address) => {
      if (this.fixedInstructionSize == null || !region) return null;
      const normalizedAddress = normalizeArchitectureAddress(address);
      if (normalizedAddress == null) return null;
      const rel = normalizedAddress - BigInt(region.vmAddr);
      const size = BigInt(this.fixedInstructionSize);
      const alignment = BigInt(this.instructionAlignment);
      if (normalizedAddress % alignment !== 0n) return null;
      if (rel < 0n || rel + size > BigInt(region.size)) return null;
      if (rel % size !== 0n) return null;
      const row = rel / size;
      if (row > MAX_SAFE_ROW) return null;
      return Number(row);
    });
    this.addressForRow = normalizeAdapterHook(definition.addressForRow, 'addressForRow', (region, row) => {
      if (this.fixedInstructionSize == null || !region) return null;
      const n = row;
      if (!Number.isSafeInteger(n) || n < 0) return null;
      const size = BigInt(this.fixedInstructionSize);
      const address = BigInt(region.vmAddr) + BigInt(n) * size;
      if (address % BigInt(this.instructionAlignment) !== 0n) return null;
      return address + size <= BigInt(region.vmAddr) + BigInt(region.size) ? address : null;
    });
    this.validateInstructionPlacement = normalizeAdapterHook(definition.validateInstructionPlacement, 'validateInstructionPlacement', (region, address, length) => {
      if (this.fixedInstructionSize == null) return unsupportedArchitectureResult('assemble', this.id);
      if (!region) return { ok:false, code:'patch-range', error:'アドレスがコードのセクション範囲外です。' };
      const normalizedAddress = normalizeArchitectureAddress(address);
      if (normalizedAddress == null) return { ok:false, code:'patch-range', error:'アドレスがコードのセクション範囲外です。' };
      const rel = normalizedAddress - BigInt(region.vmAddr);
      const size = BigInt(this.fixedInstructionSize);
      if (rel < 0n || rel + size > BigInt(region.size)) return { ok:false, code:'patch-range', error:'アドレスがコードのセクション範囲外です。' };
      const alignment = BigInt(this.instructionAlignment);
      if (normalizedAddress % alignment !== 0n || rel % alignment !== 0n || !Number.isInteger(length) || length !== this.fixedInstructionSize) {
        return { ok:false, code:'instruction-placement', architecture:this.id, error:`${this.id} 命令の位置または長さが不正です。` };
      }
      return { ok:true };
    });
    Object.freeze(this);
  }
}

export class UnsupportedArchitectureError extends Error {
  constructor(operation, architecture) {
    super(`${operation} is not supported for architecture ${architecture || 'unknown'}`);
    this.name = 'UnsupportedArchitectureError';
    this.code = 'unsupported-architecture';
    this.unsupported = true;
    this.operation = operation;
    this.architecture = canonicalArchitectureId(architecture || 'unknown');
  }
}

export function unsupportedArchitectureResult(operation, architecture) {
  const error = new UnsupportedArchitectureError(operation, architecture);
  return {
    ok:false,
    unsupported:true,
    code:error.code,
    operation:error.operation,
    architecture:error.architecture,
    error:error.message,
  };
}

function legacyDefinition(plugin) {
  const controlFlow = (instruction) => plugin.classifyControlFlow(instruction);
  return {
    id: plugin.id,
    instructionAlignment: plugin.instructionAlignment,
    fixedInstructionSize: plugin.fixedInstructionSize,
    viewerCompatible: plugin.viewerCompatible,
    decode: plugin.decode || undefined,
    assemble: plugin.assemble || undefined,
    controlFlow,
    callKind(instruction) { return controlFlow(instruction) === 'call' ? 'call' : null; },
    returnKind(instruction) { return controlFlow(instruction) === 'return' ? 'return' : null; },
  };
}

function projectAdapter(plugin) {
  if (!plugin) return null;
  let cached = ADAPTER_CACHE.get(plugin);
  if (!cached) {
    cached = new ArchitectureAdapter(legacyDefinition(plugin));
    ADAPTER_CACHE.set(plugin, cached);
  }
  return cached;
}

export function registerArchitectureAdapter(definition, { replace = false } = {}) {
  const adapter = new ArchitectureAdapter(definition);
  const pluginDef = {
    id: adapter.id,
    instructionAlignment: adapter.instructionAlignment,
    fixedInstructionSize: adapter.fixedInstructionSize,
    viewerCompatible: adapter.viewerCompatible,
    decode: adapter.decode,
    assemble: adapter.assemble,
    classifyControlFlow: adapter.controlFlow,
    semanticVersion: 'legacy-adapter-v1',
    capabilities: {
      decode: adapter.decode ? 'native' : 'unsupported',
      exactEffects: 'unsupported',
      semanticAnalysis: 'unsupported',
    },
  };
  const plugin = registerArchitecturePlugin(pluginDef, { replace });
  ADAPTER_CACHE.set(plugin, adapter);
  return adapter;
}

export function architectureAdapter(id) {
  const plugin = architecturePluginV2(id) || architecturePluginV2('unknown');
  return projectAdapter(plugin);
}

export function architectureCapability(image, engine = {}) {
  const architecture = canonicalArchitectureId(image?.arch || 'unknown');
  const adapter = architectureAdapter(architecture);
  const target = architecturePluginV2(architecture);
  const engineSupported = ownTruthy(engine, architecture) || (architecture === 'arm64e' && ownTruthy(engine, 'arm64'));
  const legacyArm64Analysis = (architecture === 'arm64' || architecture === 'arm64e') && engineSupported;
  const semanticCapability = target?.capabilities?.semanticAnalysis || 'unsupported';
  const arm64Analysis = legacyArm64Analysis && semanticCapability !== 'unsupported';
  const emulationSupported = ownTruthy(engine?.emulation, architecture);
  const analysisLevel = arm64Analysis ? (architecture === 'arm64e' ? 'partial' : 'full') : 'unsupported';
  return Object.freeze({
    format: image?.format || 'unknown', architecture, endianness: image?.endian || 'unknown', bits: Number(image?.bits || 0),
    canDisassemble: engineSupported, canAnalyzeDataflow: arm64Analysis, canEmulate: emulationSupported,
    viewerCanDisassemble: engineSupported && !!adapter.viewerCompatible,
    instructionAlignment: adapter.instructionAlignment, fixedInstructionSize: adapter.fixedInstructionSize, engineVerified: !!engine.verified,
    analysisLevel, partial: analysisLevel === 'partial',
    limitations: architecture === 'arm64e' ? Object.freeze(['pointer-authentication data semantics are conservative']) : Object.freeze([]),
  });
}

export { ArchitecturePluginV2, architecturePluginV2, architecturePluginsV2 };
