import { BudgetExceededError } from '../budgets/index.js';
import { createSchedulerBudget } from '../budgets/scheduler-budget.js';
import { assertCanonicalArtifactDescriptor } from '../artifacts/contracts.js';
import {
  ANALYSIS_PRIORITY,
  ANALYSIS_SCHEDULER_VERSION,
  SchedulerCycleError,
  SchedulerDependencyError,
  SchedulerDependencyIdentityError,
} from './index.js';

export {
  ANALYSIS_PRIORITY,
  ANALYSIS_SCHEDULER_VERSION,
  SchedulerCycleError,
  SchedulerDependencyError,
  SchedulerDependencyIdentityError,
};

function strictSafeInteger(value, fallback, code, min = 0) {
  const raw = value == null ? fallback : value;
  if (typeof raw !== 'number' && !(typeof raw === 'string' && raw.trim() !== '')) throw new TypeError(code);
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < min) throw new TypeError(code);
  return n;
}
function priorityValue(value) {
  if (typeof value === 'string' && Object.hasOwn(ANALYSIS_PRIORITY, value)) return ANALYSIS_PRIORITY[value];
  return strictSafeInteger(value, ANALYSIS_PRIORITY.current, 'analysis-priority-invalid');
}
function abortError(signal) { return signal?.reason ?? new DOMException('Aborted', 'AbortError'); }
function requireArtifactId(value, code = 'artifact-id-required') {
  if (typeof value !== 'string' || !value) throw new TypeError(code);
  return value;
}
function sameStrings(a, b) { return a.length === b.length && a.every((value, index) => value === b[index]); }
function canonicalDependencies(request, artifactId) {
  const supplied = Array.isArray(request.dependencies) ? request.dependencies : [];
  const byId = new Map();
  for (const dependency of supplied) {
    const rawId = dependency?.descriptor?.artifactId;
    if (typeof rawId !== 'string' || !rawId) throw new SchedulerDependencyIdentityError(artifactId, request.descriptor?.upstreamArtifactIds || [], ['<missing-artifact-id>']);
    const id = rawId;
    if (!byId.has(id)) byId.set(id, dependency);
  }
  const dependencies = [...byId.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, dependency]) => dependency);
  const actual = dependencies.map((dependency) => requireArtifactId(dependency.descriptor.artifactId, 'artifact-dependency-id-invalid'));
  const upstream = request.descriptor?.upstreamArtifactIds;
  if (upstream != null && !Array.isArray(upstream)) throw new SchedulerDependencyIdentityError(artifactId, ['<invalid-upstream-list>'], actual);
  const expected = (upstream || []).map((id) => requireArtifactId(id, 'artifact-dependency-id-invalid')).sort();
  if (!sameStrings(expected, actual)) throw new SchedulerDependencyIdentityError(artifactId, expected, actual);
  return dependencies;
}
function uniqueSignals(...values) {
  const out=[];
  for (const value of values.flat()) if (value && !out.includes(value)) out.push(value);
  return out;
}
function requireAbortSignal(signal) {
  if (!signal || typeof signal !== 'object') throw new TypeError('scheduler-signal-invalid');
  let aborted, addEventListener, removeEventListener;
  try {
    aborted=signal.aborted;
    addEventListener=signal.addEventListener;
    removeEventListener=signal.removeEventListener;
  } catch {
    throw new TypeError('scheduler-signal-invalid');
  }
  if (typeof aborted !== 'boolean' || typeof addEventListener !== 'function' || typeof removeEventListener !== 'function') {
    throw new TypeError('scheduler-signal-invalid');
  }
  return signal;
}
function removeSignalListeners(listeners) {
  for (const [signal,listener] of listeners) {
    try { signal.removeEventListener('abort',listener); } catch {}
  }
}
function requestCompleteness(request) { return request?.completeness ?? 'complete'; }
function inflightRequirementsCompatible(producerRequest, consumerRequest) {
  // Only identical completeness requirements share a producer. In particular,
  // bounded/truncated/unsupported are not treated as an ordered lattice.
  return requestCompleteness(producerRequest) === requestCompleteness(consumerRequest);
}
function isStorageFailure(error) { return error?.name === 'ArtifactStorageError' || String(error?.code || '').startsWith('artifact-storage-'); }

class IndexedMinHeap {
  constructor(compare) { this.items=[]; this.indices=new Map(); this.compareFn=compare; this.comparisons=0; }
  get size() { return this.items.length; }
  #compare(a,b) { this.comparisons++; return this.compareFn(a,b); }
  #swap(a,b) { const x=this.items[a],y=this.items[b]; this.items[a]=y; this.items[b]=x; this.indices.set(y.artifactId,a); this.indices.set(x.artifactId,b); }
  #up(index) { while (index>0) { const parent=(index-1)>>1; if (this.#compare(this.items[index],this.items[parent])>=0) break; this.#swap(index,parent); index=parent; } }
  #down(index) { for (;;) { let best=index; const left=index*2+1,right=left+1; if (left<this.items.length&&this.#compare(this.items[left],this.items[best])<0) best=left; if (right<this.items.length&&this.#compare(this.items[right],this.items[best])<0) best=right; if (best===index) break; this.#swap(index,best); index=best; } }
  push(item) { if (this.indices.has(item.artifactId)) throw new Error('scheduler-queue-duplicate'); const index=this.items.length; this.items.push(item); this.indices.set(item.artifactId,index); this.#up(index); }
  pop() { if (!this.items.length) return null; const root=this.items[0]; this.remove(root.artifactId); return root; }
  remove(artifactId) { const index=this.indices.get(requireArtifactId(artifactId)); if (index==null) return null; const removed=this.items[index]; const last=this.items.pop(); this.indices.delete(removed.artifactId); if (index<this.items.length) { this.items[index]=last; this.indices.set(last.artifactId,index); this.#up(index); this.#down(this.indices.get(last.artifactId)); } return removed; }
}

function priorityName(value) {
  for (const [k, v] of Object.entries(ANALYSIS_PRIORITY)) {
    if (v === value) return k;
  }
  // Numeric priorities outside the named enum remain valid scheduler inputs.
  // Preserve their canonical numeric identity in lifecycle telemetry instead
  // of fabricating an unrelated current label.
  return value;
}

export class AnalysisScheduler {
  constructor({ store, maxConcurrency=2, starvationInterval=8, defaultBudget={}, onEvent=null }={}) {
    if (!store) throw new TypeError('artifact-store-required');
    if (!Number.isSafeInteger(maxConcurrency) || maxConcurrency <= 0) throw new TypeError('scheduler-max-concurrency-invalid');
    if (onEvent != null && typeof onEvent !== 'function') throw new TypeError('scheduler-on-event-invalid');
    const normalizedStarvationInterval = strictSafeInteger(starvationInterval, 8, 'scheduler-starvation-interval-invalid', 1);
    this.store=store; this.maxConcurrency=maxConcurrency; this.starvationInterval=normalizedStarvationInterval; this.defaultBudget=defaultBudget;
    this.onEvent = onEvent;
    this.seq = 0;
    this.inflight=new Map(); this.running=0; this.dispatchEpoch=0; this.dag=new Map(); this.dagEdgeCount=0; this.states=new Map(); this.activeConsumers=0;
    this.queue=new IndexedMinHeap((a,b)=>a.orderKey<b.orderKey?-1:a.orderKey>b.orderKey?1:a.artifactId.localeCompare(b.artifactId));
    this.metrics={ requests:0,cacheHits:0,producerInvocations:0,coalescedRequests:0,queueOperations:0,completedJobs:0,failedJobs:0,cancelledJobs:0,cancelledConsumers:0,orphanCancellations:0,budgetExhaustions:0,dependencyFailures:0,producerFailures:0,storageFailures:0,cycleErrors:0,cycleChecks:0,cycleTraversalSteps:0,dependencyIdentityErrors:0,maxObservedRunning:0,observerFailures:0 };
  }

  #emit(type, taskOrArtifactId, details = {}) {
    if (!this.onEvent) return;
    try {
      const artifactId = typeof taskOrArtifactId === 'string' ? taskOrArtifactId : taskOrArtifactId?.artifactId;
      const state = typeof taskOrArtifactId === 'object' && taskOrArtifactId?.state != null
        ? taskOrArtifactId.state
        : (this.states.get(artifactId) ?? null);
      // Lifecycle contract (#1189 / #3312): every event carries the schema
      // version and live scheduler gauges so observers never guess them.
      const event = Object.freeze({
        version: 1,
        seq: ++this.seq,
        type,
        artifactId,
        state,
        running: this.running,
        queued: this.queue.size,
        details: Object.freeze({ ...details }),
      });
      this.onEvent(event);
    } catch {
      this.metrics.observerFailures = (this.metrics.observerFailures || 0) + 1;
    }
  }

  request(request) { return this.#request(request,[],null,{ external:true }); }

  #request(request, ancestry, parentSignal, options = {}) {
    const descriptor=request?.descriptor;
    let artifactId;
    try {
      artifactId=requireArtifactId(descriptor?.artifactId,'artifact-request-descriptor-required');
      assertCanonicalArtifactDescriptor(descriptor);
    } catch (error) { return Promise.reject(error); }
    const firstAttempt=options.retry!==true;
    if (firstAttempt) this.metrics.requests++;
    const priority = priorityValue(request.priority);
    // Lifecycle contract (#1189 / #3313): request.received fires exactly once
    // per externally visible request() call. Dependency recursion re-enters
    // this path internally and must not re-announce the request.
    if (options.external && firstAttempt) {
      this.#emit('request.received', artifactId, {
        priority: priorityName(priority),
        dependencyCount: (descriptor?.upstreamArtifactIds || []).length,
      });
    }
    let consumerSignals;
    try { consumerSignals=uniqueSignals(request.signal,parentSignal).map(requireAbortSignal); }
    catch (error) { return Promise.reject(error); }
    const alreadyAborted=consumerSignals.find((signal)=>signal.aborted);
    if (alreadyAborted) { this.metrics.cancelledConsumers++; return Promise.reject(abortError(alreadyAborted)); }
    if (ancestry.includes(artifactId)) { this.metrics.cycleErrors++; return Promise.reject(new SchedulerCycleError([...ancestry,artifactId])); }
    let existing=this.inflight.get(artifactId);
    if (existing?.controller.signal.aborted) {
      // Publish cancellation has a durable-outcome contract (#4595): a store
      // may have committed even though the last consumer left. Do not start a
      // colliding generation until that publication outcome is known.
      if (existing.phase==='publish'||existing.phase==='completed') {
        return this.#waitForInflightSlot(existing,consumerSignals)
          .then(()=>this.#request(request,ancestry,parentSignal,{...options,retry:true}));
      }
      // Outside publication an aborted task cannot become authoritative again.
      // Detach it synchronously so a fresh consumer does not inherit the stale
      // controller. The old finally is identity-guarded and cannot delete the
      // replacement task.
      existing.superseded=true;
      if (this.inflight.get(artifactId)===existing) this.inflight.delete(artifactId);
      existing=null;
    }
    if (existing) {
      if (inflightRequirementsCompatible(existing.request,request)) {
        this.metrics.coalescedRequests++;
        const p = this.#attachConsumer(existing,consumerSignals);
        this.#emit('request.coalesced', existing, { consumerCount: existing.consumerCount });
        return p;
      }
      // A distinct completeness requirement cannot share this producer, while
      // the scheduler's queue/DAG authority is intentionally unique per
      // artifactId. Wait for the incumbent to settle, then re-enter through
      // the normal cache/producers path instead of running two colliding tasks.
      return this.#waitForInflightSlot(existing,consumerSignals)
        .then(()=>this.#request(request,ancestry,parentSignal,{...options,retry:true}));
    }

    const controller=new AbortController();
    const task={ artifactId,descriptor,request,controller,priority,enqueuedEpoch:null,orderKey:null,state:'waiting-dependency',phase:'dependency',queueResolve:null,queueReject:null,promise:null,settled:false,superseded:false,consumerCount:0 };
    controller.signal.addEventListener('abort',()=>this.#cancelQueuedTask(task),{once:true});
    task.promise=Promise.resolve()
      .then(()=>this.#execute(task,[...ancestry,artifactId]))
      .catch((error)=>{ this.#recordFailure(task,error); throw error; })
      .finally(()=>{ task.settled=true; if (this.inflight.get(artifactId)===task) this.inflight.delete(artifactId); });
    this.inflight.set(artifactId,task);
    return this.#attachConsumer(task,consumerSignals);
  }

  #attachConsumer(task, signals) {
    const active=uniqueSignals(signals,task.controller.signal);
    const aborted=active.find((signal)=>signal.aborted);
    if (aborted) { this.metrics.cancelledConsumers++; return Promise.reject(abortError(aborted)); }
    task.consumerCount++; this.activeConsumers++;
    return new Promise((resolve,reject)=>{
      let settled=false;
      const listeners=[];
      const detach=(orphaned=false)=>{
        if (settled) return false;
        settled=true;
        removeSignalListeners(listeners);
        task.consumerCount--; this.activeConsumers--;
        if (orphaned&&task.consumerCount===0&&!task.settled&&!task.controller.signal.aborted) {
          this.metrics.orphanCancellations++;
          task.controller.abort(new DOMException('No active consumers','AbortError'));
        }
        return true;
      };
      const finish=(fn,value,cancelled=false,orphaned=cancelled)=>{
        if (!detach(orphaned)) return;
        if (cancelled) this.metrics.cancelledConsumers++;
        fn(value);
      };
      const awaitPublishOutcome=(signal)=>{
        const orphaned=signal!==task.controller.signal;
        if (!detach(orphaned)) return;
        task.promise.then(
          resolve,
          ()=>{
            this.metrics.cancelledConsumers++;
            reject(abortError(signal));
          },
        );
      };
      const handleAbort=(signal)=>{
        if (task.phase==='completed') return;
        if (task.phase==='publish'&&(signal===task.controller.signal||task.consumerCount===1)) {
          awaitPublishOutcome(signal);
          return;
        }
        finish(reject,abortError(signal),true);
      };
      try {
        for (const signal of active) {
          const listener=()=>handleAbort(signal);
          listeners.push([signal,listener]); signal.addEventListener('abort',listener,{once:true});
          if (settled) break;
        }
      } catch (error) {
        finish(reject,error,false,true);
        task.promise.catch(()=>{});
        return;
      }
      if (settled) { task.promise.catch(()=>{}); return; }
      task.promise.then((value)=>finish(resolve,value),(error)=>finish(reject,error));
      const abortedAfterRegistration=active.find((signal)=>signal.aborted);
      if (abortedAfterRegistration) handleAbort(abortedAfterRegistration);
    });
  }

  #waitForInflightSlot(task, signals) {
    const active=uniqueSignals(signals);
    const aborted=active.find((signal)=>signal.aborted);
    if (aborted) { this.metrics.cancelledConsumers++; return Promise.reject(abortError(aborted)); }
    this.activeConsumers++;
    return new Promise((resolve,reject)=>{
      let settled=false;
      const listeners=[];
      const finish=(fn,value,cancelled=false)=>{
        if (settled) return;
        settled=true;
        removeSignalListeners(listeners);
        this.activeConsumers--;
        if (cancelled) this.metrics.cancelledConsumers++;
        fn(value);
      };
      try {
        for (const signal of active) {
          const listener=()=>finish(reject,abortError(signal),true);
          listeners.push([signal,listener]); signal.addEventListener('abort',listener,{once:true});
          if (settled) break;
        }
      } catch (error) {
        finish(reject,error);
        return;
      }
      if (settled) return;
      task.promise.then(()=>finish(resolve),()=>finish(resolve));
      const abortedAfterRegistration=active.find((signal)=>signal.aborted);
      if (abortedAfterRegistration) finish(reject,abortError(abortedAfterRegistration),true);
    });
  }

  async #execute(task, ancestry) {
    let dependencies;
    try { dependencies=canonicalDependencies(task.request,task.artifactId); }
    catch (error) { if (error instanceof SchedulerDependencyIdentityError) this.metrics.dependencyIdentityErrors++; throw error; }
    this.#registerDag(task.artifactId,dependencies.map((dependency)=>requireArtifactId(dependency.descriptor.artifactId,'artifact-dependency-id-invalid')));
    this.states.set(task.artifactId,'waiting-dependency');
    const dependencyResults=await this.#waitForDependencies(task,dependencies,ancestry);
    if (task.controller.signal.aborted) throw abortError(task.controller.signal);

    task.phase='cache';
    const cached=await this.store.get(task.descriptor,{signal:task.controller.signal});
    if (task.controller.signal.aborted) throw abortError(task.controller.signal);
    if (cached.status==='hit') {
      this.metrics.cacheHits++;
      this.states.set(task.artifactId,'completed');
      this.#emit('cache.hit', task, { source:'store' });
      return {...cached,state:'completed',reused:true};
    }
    return this.#enqueue(task,dependencyResults);
  }

  async #waitForDependencies(task, dependencies, ancestry) {
    if (!dependencies.length) return [];
    const waitController=new AbortController();
    const onParentAbort=()=>waitController.abort(abortError(task.controller.signal));
    if (task.controller.signal.aborted) onParentAbort(); else task.controller.signal.addEventListener('abort',onParentAbort,{once:true});
    const promises=dependencies.map((dependency)=>this.#request(dependency,ancestry,waitController.signal));
    try { return await Promise.all(promises); }
    catch (error) {
      if (task.controller.signal.aborted) throw abortError(task.controller.signal);
      if (!waitController.signal.aborted) waitController.abort(new DOMException('Dependency wait cancelled','AbortError'));
      await Promise.allSettled(promises);
      if (error instanceof SchedulerCycleError || error instanceof SchedulerDependencyIdentityError) throw error;
      this.metrics.dependencyFailures++;
      throw new SchedulerDependencyError(task.artifactId,error);
    } finally { task.controller.signal.removeEventListener('abort',onParentAbort); }
  }

  #registerDag(artifactId, dependencyIds) {
    const ids=[...dependencyIds].sort((a,b)=>a.localeCompare(b));
    for (const dependencyId of ids) {
      this.metrics.cycleChecks++;
      if (dependencyId===artifactId) { this.metrics.cycleErrors++; throw new SchedulerCycleError([artifactId,artifactId]); }
      const path=this.#pathBetween(dependencyId,artifactId);
      if (path) { this.metrics.cycleErrors++; throw new SchedulerCycleError([artifactId,...path]); }
    }
    const previous=this.dag.get(artifactId)||[];
    this.dagEdgeCount+=ids.length-previous.length;
    this.dag.set(artifactId,Object.freeze(ids));
    for (const dependencyId of ids) if (!this.dag.has(dependencyId)) this.dag.set(dependencyId,Object.freeze([]));
  }

  #pathBetween(start,target) {
    const stack=[start];
    const parent=new Map([[start,null]]);
    while (stack.length) {
      const current=stack.pop();
      this.metrics.cycleTraversalSteps++;
      if (current===target) {
        const path=[];
        for (let node=current;node!=null;node=parent.get(node)) path.push(node);
        path.reverse();
        return path;
      }
      const next=this.dag.get(current)||[];
      for (let i=next.length-1;i>=0;i--) {
        const child=next[i];
        if (parent.has(child)) continue;
        parent.set(child,current);
        stack.push(child);
      }
    }
    return null;
  }

  #enqueue(task,dependencyResults) {
    return new Promise((resolve,reject)=>{
      if (task.controller.signal.aborted) { reject(abortError(task.controller.signal)); return; }
      task.queueResolve=resolve; task.queueReject=reject; task.dependencyResults=dependencyResults; task.state='ready'; task.phase='ready'; task.enqueuedEpoch=this.dispatchEpoch;
      task.orderKey=BigInt(task.enqueuedEpoch)+(BigInt(task.priority)*BigInt(this.starvationInterval));
      this.states.set(task.artifactId,'ready'); this.queue.push(task); this.metrics.queueOperations++;
      this.#emit('queue.enqueued', task, { priority: priorityName(task.priority) });
      this.#pump();
    });
  }

  #pump() {
    while (this.running<this.maxConcurrency&&this.queue.size) {
      const task=this.queue.pop(); this.metrics.queueOperations++; this.dispatchEpoch++;
      if (task.controller.signal.aborted) { task.queueReject(abortError(task.controller.signal)); continue; }
      this.running++; this.metrics.maxObservedRunning=Math.max(this.metrics.maxObservedRunning,this.running); task.state='running'; task.phase='producer'; this.states.set(task.artifactId,'running');
      this.#emit('job.started', task, { priority: priorityName(task.priority) });
      this.#run(task).then(task.queueResolve,task.queueReject).finally(()=>{ this.running--; this.#pump(); });
    }
  }

  async #run(task) {
    const signal=task.controller.signal;
    const budget=createSchedulerBudget(task.request.budget,this.defaultBudget,signal);
    budget.checkCancelled();
    if (typeof task.request.produce!=='function') throw new TypeError('artifact-producer-required');
    this.metrics.producerInvocations++;
    task.phase='producer';
    const payload=await task.request.produce({ descriptor:task.descriptor,artifactId:task.artifactId,dependencies:task.dependencyResults,signal,budget });
    budget.checkCancelled();
    task.phase='publish';
    const published=await this.store.publish(task.descriptor,payload,{ signal,completeness:task.request.completeness??'complete',validate:task.request.validate,creation:task.request.creation });
    this.metrics.completedJobs++; this.states.set(task.artifactId,'completed'); task.phase='completed';
    this.#emit('job.completed', task, { published: true });
    return {...published,state:'completed',reused:false,budget:budget.snapshot()};
  }

  #recordFailure(task,error) {
    if (task.superseded&&task.controller.signal.aborted) {
      this.metrics.cancelledJobs++;
      const phase = task.state === 'running' ? 'running' : (task.state === 'ready' || task.phase === 'ready') ? 'queued' : 'waiting-dependency';
      this.#emit('job.cancelled', task, { phase, superseded:true });
      return;
    }
    if (error instanceof BudgetExceededError) {
      this.metrics.budgetExhaustions++;
      this.states.set(task.artifactId,'budget-exhausted');
      this.#emit('budget.exhausted', task, {
        resource: error.resource ?? null,
        limit: error.limit ?? null,
        requested: error.used ?? error.requested ?? null,
      });
      return;
    }
    if (task.controller.signal.aborted) {
      this.metrics.cancelledJobs++;
      this.states.set(task.artifactId,'cancelled');
      const phase = task.state === 'running' ? 'running' : (task.state === 'ready' || task.phase === 'ready') ? 'queued' : 'waiting-dependency';
      this.#emit('job.cancelled', task, { phase });
      return;
    }
    if (error instanceof SchedulerDependencyError) {
      this.metrics.failedJobs++;
      this.states.set(task.artifactId,'failed');
      this.#emit('dependency.failed', task, {
        dependencyArtifactId: error.cause?.artifactId || error.artifactId || null,
      });
      return;
    }
    if (task.phase==='cache'||task.phase==='publish'||isStorageFailure(error)) {
      this.metrics.failedJobs++;
      this.metrics.storageFailures++;
      this.states.set(task.artifactId,'failed');
      this.#emit('storage.failed', task, { code: error.code || null });
      return;
    }
    this.metrics.failedJobs++;
    if (task.phase==='producer') this.metrics.producerFailures++;
    this.states.set(task.artifactId,'failed');
    this.#emit('job.failed', task, { code: error.code || null, name: error.name || 'Error' });
  }

  #cancelQueuedTask(task) {
    if (task.state!=='ready') return;
    const removed=this.queue.remove(task.artifactId);
    if (!removed) return;
    this.metrics.queueOperations++;
    task.queueReject(abortError(task.controller.signal));
  }

  cancel(artifactId, reason=new DOMException('Cancelled','AbortError')) {
    const id = requireArtifactId(artifactId);
    const task=this.inflight.get(id); if (!task) return false;
    if (!task.controller.signal.aborted) task.controller.abort(reason);
    return true;
  }

  dependencyIds(artifactId) { return this.dag.get(requireArtifactId(artifactId))||Object.freeze([]); }
  state(artifactId) { return this.states.get(requireArtifactId(artifactId))||'unknown'; }
  stats() { return Object.freeze({ schedulerVersion:ANALYSIS_SCHEDULER_VERSION,starvationPolicy:'virtual-deadline-v1',starvationInterval:this.starvationInterval,running:this.running,queued:this.queue.size,inflight:this.inflight.size,activeConsumers:this.activeConsumers,dagNodes:this.dag.size,dagEdges:this.dagEdgeCount,queueComparisons:this.queue.comparisons,producerInvocationCount:this.metrics.producerInvocations,...this.metrics }); }
}
