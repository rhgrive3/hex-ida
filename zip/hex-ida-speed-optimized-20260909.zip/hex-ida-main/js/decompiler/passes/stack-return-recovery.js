import { expr, structuralKey } from '../ast/nodes.js';
import { RewriteEngine } from '../rewrite/engine.js';
import { DEFAULT_RULES } from '../rewrite/rules.js';
import { printExpression, printProgram } from '../pretty/c.js';
import { buildNZCVConditionExpression } from '../flag-semantics.js';
import {
  canonicalMemoryForwardingContextForLoad,
  isCanonicalExactMemoryForwarding,
} from '../../semantics/memoryssa/queries.js';
import { uniqueReachableMergePredecessorIndex } from './stack-join-arm-proof.js';

const INVERSE = Object.freeze({ eq:'ne', ne:'eq', lt:'ge', le:'gt', gt:'le', ge:'lt' });
const EXACT_VIEW_MOV_SUBS = new Set([null, 'copy', 'bitcast', 'trunc', 'zext']);

function valueOf(a) { return a?.value || null; }

function mapsOf(result) {
  return new Map((result.semanticAst?.values || []).map((v) => [v.valueId, v.expression]));
}

function fitWidth(node, bits, source = null) {
  bits = Number(bits || 0);
  if (!node || !bits || Number(node.bits || bits) <= bits) return node;
  return expr.unary('trunc', node, bits, node.signed ?? null, source || node.source, { fromBits:Number(node.bits || bits) });
}

function expressionOf(value, values) {
  const node = value ? values.get(value.id) || null : null;
  return node ? fitWidth(node, value?.bits, {
    row:value?.def?.row ?? null,
    address:value?.def?.address ?? null,
    ir:value?.def?.id ?? null,
    ssaUse:value?.id ?? null,
    evidence:[{ reason:'SSA value-width boundary' }],
  }) : null;
}

function simplify(node, engine) {
  return node ? engine.rewrite(node).root : null;
}

function invert(node) {
  if (node?.kind === 'compare' && INVERSE[node.op]) {
    return expr.compare(INVERSE[node.op], node.left, node.right, node.compareSigned, node.source);
  }
  return expr.unary('lnot', node, 1, false, node?.source);
}

function sameRowArithmetic(ir, cmp) {
  const row = ir.byRow?.get?.(cmp.row) || (ir.instructions || []).filter((i) => i.row === cmp.row);
  let best = null;
  for (const inst of row) {
    if (inst.id >= cmp.id) continue;
    if (inst.op !== 'bin' || inst.sub !== cmp.sub) continue;
    if (!best || inst.id > best.id) best = inst;
  }
  return best;
}

function compareFromFlags(ir, flagsValue, cond, values) {
  const cmp = flagsValue?.def;
  if (cmp?.op !== 'cmp') return null;

  // Flag-setting arithmetic is lifted as BIN then CMP on the same ARM64 row.
  // SSA renaming can make CMP read the just-written destination. The preceding
  // same-row BIN is an exact proof of the original flag-producing operands.
  const arithmetic = sameRowArithmetic(ir, cmp);
  const leftValue = valueOf(arithmetic?.args?.[0] || cmp.args?.[0]);
  const rightValue = valueOf(arithmetic?.args?.[1] || cmp.args?.[1]);
  const left = expressionOf(leftValue, values);
  const right = expressionOf(rightValue, values);
  if (!left || !right) return null;
  const bits = Number(cmp.bits || leftValue?.bits || rightValue?.bits || left.bits || right.bits || 64);

  return buildNZCVConditionExpression(cmp.sub || 'sub', cond, left, right, bits, {
    address: cmp.address,
    row: cmp.row,
    ir: cmp.id,
    ssaUses: [leftValue?.id, rightValue?.id].filter((x) => x != null),
    evidence: [{ reason: arithmetic ? 'same-row flag-producing arithmetic operands' : 'NZCV compare operands' }],
  });
}

function branchCondition(ir, term, values) {
  const kind = term?.extra?.kind || term?.sub || '';
  const tested = valueOf(term?.args?.[0]);

  if (kind === 'cbz' || kind === 'cbnz') {
    const x = expressionOf(tested, values);
    return x ? expr.compare(kind === 'cbz' ? 'eq' : 'ne', x, expr.constant(0, x.bits || 64), null, term.source) : null;
  }

  if (kind === 'tbz' || kind === 'tbnz') {
    const select = tested?.def;
    if (select?.op === 'sel' && (select.sub === 'set' || select.sub === 'setm')) {
      const flags = valueOf(select.args?.[select.args.length - 1]);
      const materialized = compareFromFlags(ir, flags, select.cond, values);
      if (materialized) return kind === 'tbz' ? invert(materialized) : materialized;
    }

    const x = expressionOf(tested, values);
    if (!x) return null;
    const bit = Number(term.extra?.bit ?? 0);
    const bits = Number(tested?.bits || x.bits || 64);
    if (bit === bits - 1) {
      return expr.compare(kind === 'tbz' ? 'ge' : 'lt', x, expr.constant(0, bits, true), true, term.source);
    }
    const shifted = expr.binary('lshr', x, expr.constant(bit, bits, false), bits, false, term.source);
    const masked = expr.binary('and', shifted, expr.constant(1, bits, false), bits, false, term.source);
    return expr.compare(kind === 'tbz' ? 'eq' : 'ne', masked, expr.constant(0, bits, false), false, term.source);
  }

  if (kind === 'cond' || term?.cond) {
    const flags = valueOf(term.args?.[term.args.length - 1]);
    return compareFromFlags(ir, flags, term.cond || term.extra?.cond, values);
  }
  return null;
}

function targetBlock(ir, term, opts) {
  const address = term?.extra?.target;
  if (address == null) return null;
  const row = opts.rowOfAddress?.(address);
  if (row == null) return null;
  return ir.blocks?.find((b) => row >= b.startRow && row <= b.endRow)?.index ?? null;
}

function terminal(block) {
  const xs = block?.insts || [];
  for (let i = xs.length - 1; i >= 0; i--) if (['cbr','br','ret'].includes(xs[i]?.op)) return xs[i];
  return null;
}

function branchArms(ir, block, term, opts) {
  const succ = block?.succ || [];
  if (term?.op !== 'cbr' || succ.length < 2) return { yes:succ[0] ?? null, no:succ[1] ?? null, exact:term?.op !== 'cbr' };
  const yes = targetBlock(ir, term, opts);
  return yes != null && succ.includes(yes)
    ? { yes, no:succ.find((x) => x !== yes) ?? null, exact:true }
    : { yes:null, no:null, exact:false };
}

function armPredecessorIndex(ir, controller, successor, merge, predecessors) {
  return uniqueReachableMergePredecessorIndex(
    ir, controller.index, successor, merge, predecessors,
  );
}

function dominates(ir, candidate, node) {
  const view = ir.dominators?.[node];
  if (view?.has) return view.has(candidate);
  let cur = node, guard = (ir.blocks?.length || 0) + 2;
  while (cur != null && cur >= 0 && guard-- > 0) {
    if (cur === candidate) return true;
    cur = ir.idom?.[cur] ?? ir.blocks?.[cur]?.idom ?? -1;
  }
  return false;
}

function domDepth(ir, block) {
  let depth = 0, cur = block, guard = (ir.blocks?.length || 0) + 2;
  while (cur != null && cur >= 0 && guard-- > 0) { depth++; cur = ir.idom?.[cur] ?? ir.blocks?.[cur]?.idom ?? -1; }
  return depth;
}

function controller(ir, merge, predecessors, opts) {
  const candidates = [];
  for (const block of ir.blocks || []) {
    if (!dominates(ir, block.index, merge)) continue;
    const term = terminal(block);
    if (term?.op !== 'cbr' || (block.succ || []).length < 2) continue;
    const arms = branchArms(ir, block, term, opts);
    if (!arms.exact) continue;
    const yesIndex = armPredecessorIndex(ir, block, arms.yes, merge, predecessors);
    const noIndex = armPredecessorIndex(ir, block, arms.no, merge, predecessors);
    if (yesIndex >= 0 && noIndex >= 0 && yesIndex !== noIndex) candidates.push({ term, yesIndex, noIndex, depth:domDepth(ir, block.index) });
  }
  candidates.sort((a,b) => b.depth - a.depth);
  if (!candidates.length) return null;
  if (candidates.length > 1 && candidates[0].depth === candidates[1].depth) return null;
  return candidates[0];
}

function storeValue(inst, key, values) {
  if (inst?.op !== 'store' || inst.loc?.key !== key) return null;
  let node = expressionOf(valueOf(inst.args?.[0]), values);
  if (!node) return null;
  const bytes = Number(inst.size || inst.loc?.size || inst.addr?.size || 0);
  const bits = bytes > 0 ? bytes * 8 : 0;
  if (bits) node = fitWidth(node, bits, {
    address:inst.address,
    row:inst.row,
    ir:inst.id,
    evidence:[{ reason:`exact ${bits}-bit stack-store boundary` }],
  });
  return node;
}

function reachingRegisterDefinition(ir, atInst, reg) {
  let best = null, bestDepth = -1, bestRow = -Infinity;
  for (const value of ir?.values || []) {
    if (value?.reg !== reg || !value.def || value.clobbered) continue;
    const def = value.def;
    if (def.block === atInst.block) {
      if (def.row == null || atInst.row == null || def.row >= atInst.row) continue;
      if (def.row > bestRow) { best = value; bestRow = def.row; bestDepth = Number.MAX_SAFE_INTEGER; }
      continue;
    }
    if (!dominates(ir, def.block, atInst.block)) continue;
    const depth = domDepth(ir, def.block);
    if (bestDepth !== Number.MAX_SAFE_INTEGER && (depth > bestDepth || (depth === bestDepth && (def.row ?? -Infinity) > bestRow))) {
      best = value; bestDepth = depth; bestRow = def.row ?? -Infinity;
    }
  }
  return best;
}

function exactViewTrace(value, active = new Set()) {
  if (!value || active.has(value.id)) return null;
  active.add(value.id);
  let current = value;
  const steps = [];
  while (current?.def?.op === 'mov' && current.def.args?.length === 1) {
    const def = current.def;
    const sub = def.sub ?? null;
    const exactIdentity = sub == null || sub === 'copy' || sub === 'bitcast'
      || def.extra?.stateRead || def.extra?.stateWrite;
    if (!exactIdentity && !EXACT_VIEW_MOV_SUBS.has(sub)) break;
    const source = valueOf(def.args[0]);
    if (!source || active.has(source.id)) break;
    if (sub === 'trunc' || sub === 'zext') {
      steps.push(`${sub}:${Number(source.bits || 0)}>${Number(current.bits || 0)}`);
    }
    active.add(source.id);
    current = source;
  }
  return { root: current, bits:Number(value.bits || 0), steps };
}

function storedViewProjectsValue(stored, expected, store) {
  if (!stored || !expected || !store) return false;
  if (stored === expected || stored.id === expected.id) return true;
  const a = exactViewTrace(stored), b = exactViewTrace(expected);
  if (!a?.root || !b?.root || a.root.id !== b.root.id) return false;
  const widthBits = Number((store.loc?.size ?? store.addr?.size ?? store.extra?.size ?? 0) * 8);
  if (widthBits > 0 && Number(stored.bits || 0) !== widthBits) return false;
  if (a.steps.length < b.steps.length) return false;
  const suffix = a.steps.slice(a.steps.length - b.steps.length);
  return suffix.every((step, index) => step === b.steps[index]);
}

function committedStoreBarrier(inst, key) {
  if (inst?.op === 'clobber' || inst?.op === 'unknown') return true;
  if (inst?.op === 'call') return (inst.memKills || []).some((loc) => loc?.key === key);
  if (inst?.op !== 'store') return false;
  return !inst.loc?.key || inst.loc?.kind === 'unknown' || inst.loc.key === key;
}

function storeOfExactValue(ir, blockIndex, value) {
  let current = blockIndex;
  const seen = new Set();
  const later = [];
  let guard = Math.min(64, (ir?.blocks?.length || 0) + 2);
  while (current != null && current >= 0 && guard-- > 0 && !seen.has(current)) {
    seen.add(current);
    const instructions = [...(ir?.blocks?.[current]?.insts || [])]
      .sort((a,b) => (b.row ?? -1) - (a.row ?? -1) || (b.id ?? -1) - (a.id ?? -1));
    for (const inst of instructions) {
      if (inst?.op === 'store' && inst.loc?.kind !== 'stack' && inst.loc?.kind !== 'unknown'
          && inst.loc?.key && storedViewProjectsValue(valueOf(inst.args?.[0]), value, inst)) {
        if (!dominates(ir, current, blockIndex)) return null;
        if (later.some((candidate) => committedStoreBarrier(candidate, inst.loc.key))) return null;
        return inst;
      }
      later.push(inst);
    }
    const predecessors = [...(ir?.blocks?.[current]?.pred || [])];
    if (predecessors.length !== 1) return null;
    current = predecessors[0];
  }
  return null;
}

function semanticLocationForStore(result, store) {
  return (result.semanticAst?.stores || []).find((item) =>
    (item.source?.ir || []).some((id) => Number(id) === Number(store?.id)))?.location || null;
}

function locationIdentity(location) {
  if (!location) return null;
  if (location.kind === 'field') {
    return `field:${location.offset ?? ''}:${location.name || ''}:${structuralKey(location.base)}`;
  }
  if (location.kind === 'index') {
    return `index:${location.scale || 1}:${structuralKey(location.base)}:${structuralKey(location.index)}`;
  }
  return `${location.kind}:${location.key || location.text || location.name || ''}`;
}

function semanticLocationForProvenSnapshot(result, definition) {
  const projected = (result.semanticAst?.values || []).find((item) =>
    String(item?.valueId ?? '') === String(definition?.dst?.id ?? ''))?.expression ?? null;
  if (projected?.kind === 'load'
      && projected.location?.kind !== 'stack' && projected.location?.kind !== 'unknown') return projected.location;

  const key = definition?.extra?.committedLocationKey ?? definition?.loc?.key;
  if (!key) return null;
  const rows = new Set((definition.extra?.committedStoreRows || [])
    .map(Number).filter(Number.isFinite));
  const locations = (result.ir?.instructions || [])
    .filter((store) => store?.op === 'store'
      && store.loc?.kind !== 'stack' && store.loc?.kind !== 'unknown'
      && store.loc?.key === key
      && (rows.size === 0 || rows.has(Number(store.row))))
    .map((store) => semanticLocationForStore(result, store));
  if (!locations.length || locations.some((location) => !location)) return null;
  const identity = locationIdentity(locations[0]);
  if (!identity || locations.some((location) => locationIdentity(location) !== identity)) return null;
  return locations[0];
}

function committedLocationForPhi(result, value) {
  const definition = value?.def;
  if (definition?.op === 'load'
      && (definition.extra?.committedPhiSnapshot === true || definition.extra?.committedSnapshotView === true)
      && definition.loc?.kind !== 'stack' && definition.loc?.kind !== 'unknown') {
    const location = semanticLocationForProvenSnapshot(result, definition);
    if (location) return location;
  }

  const phi = definition;
  if (phi?.op !== 'phi' || !(phi.incoming || []).length) return null;
  const locations = [];
  for (const incoming of phi.incoming || []) {
    const store = storeOfExactValue(result.ir, incoming.from, incoming.value);
    if (!store) return null;
    const location = semanticLocationForStore(result, store);
    if (!location) return null;
    locations.push(location);
  }
  const identity = locationIdentity(locations[0]);
  if (!identity || locations.some((loc) => locationIdentity(loc) !== identity)) return null;
  return locations[0];
}

function canonicalReturnRegister(result, root, opts = {}) {
  const adapter = opts.abiAdapter || result?.abiAdapter || result?.ctx?.abiAdapter || null;
  if (adapter?.supported === true && typeof adapter.returnLocations === 'function') {
    const returnType = opts.returnType
      ?? opts.functionPrototype?.returnType
      ?? opts.prototype?.returnType
      ?? result?.prototype?.returnType
      ?? result?.types?.ret?.type
      ?? (root?.bits ? `int${root.bits}` : null);
    if (!returnType) return null;
    try {
      const locations = adapter.returnLocations({
        functionPrototype:{ returnType, returnsValue:true },
        returnType,
      });
      return Array.isArray(locations) && locations.length === 1
        && locations[0]?.kind === 'register' && locations[0]?.aggregate !== true
        ? String(locations[0].reg || '') || null : null;
    } catch {
      return null;
    }
  }
  if (adapter) return null;
  // The old ARM64 facade predates the canonical ABI envelope. Preserve its
  // presentation-only x0 behavior, while a v2 IR without an adapter remains
  // unknown instead of acquiring a private ABI rule.
  if (opts.legacyAArch64 === true || result?.ir?.compat?.projection !== 'semantic-ir-v2-to-v1') return 'x0';
  return null;
}

function committedReturnValue(result, root, ret, opts = {}) {
  if (root?.kind !== 'load' || root.location?.kind !== 'stack' || !root.location?.key) return null;
  const returnRegister = canonicalReturnRegister(result, root, opts);
  if (!returnRegister) return null;
  const reaching = reachingRegisterDefinition(result.ir, ret, returnRegister);
  const load = reaching?.def;
  if (load?.op !== 'load' || load.loc?.key !== root.location.key) return null;
  if (!isCanonicalExactMemoryForwarding(load.memoryForwarding,
    canonicalMemoryForwardingContextForLoad(load.memoryForwarding, load,
      load.memoryForwardingContext ?? load.extra?.memoryForwardingContext))) return null;
  const definitionIds = new Set(load.memoryForwarding.contributingDefinitionIds.map(String));
  const stackStores = (result.ir.instructions || []).filter((candidate) => {
    const definitionId = candidate?.memDef?.definitionId ?? candidate?.extra?.memoryDefinitionId ?? null;
    return candidate?.op === 'store'
      && candidate?.loc?.kind === 'stack'
      && candidate.loc.key === root.location.key
      && definitionId != null
      && definitionIds.has(String(definitionId));
  });
  if (stackStores.length !== 1) return null;
  const stackStore = stackStores[0];
  const spilled = valueOf(stackStore?.args?.[0]);
  const location = committedLocationForPhi(result, spilled);
  if (!location) return null;
  return expr.load(location, root.bits || 64, root.source, {
    signed: root.signed ?? null,
    proof: 'all SSA phi predecessors committed the exact spilled value to one lvalue',
  });
}

function unsafeBarrier(inst, key) {
  if (inst?.op === 'clobber' || inst?.op === 'unknown') return true;
  if (inst?.op === 'call') {
    // buildMemorySSA has already proven which locations this call can kill.
    // A private caller stack slot is absent from memKills and is safe to carry
    // through the call; an escaped stack address is present and remains a barrier.
    return (inst.memKills || []).some((loc) => loc?.key === key);
  }
  return inst?.op === 'store' && inst.loc?.key !== key && (!inst.loc?.key || inst.loc?.kind === 'unknown');
}

function before(ir, block, row) {
  return (ir.instructions || [])
    .filter((i) => i.block === block && (row == null || i.row < row))
    .sort((a,b) => (b.row ?? -1) - (a.row ?? -1));
}

function resolve(ir, blockIndex, beforeRow, key, values, opts, engine, active, depth = 0) {
  if (blockIndex == null || depth > 64) return null;
  const token = `${blockIndex}:${beforeRow ?? 'end'}:${key}`;
  if (active.has(token)) return null;
  active.add(token);
  try {
    for (const inst of before(ir, blockIndex, beforeRow)) {
      const stored = storeValue(inst, key, values);
      if (stored) return stored;
      if (unsafeBarrier(inst, key)) return null;
    }

    const block = ir.blocks?.[blockIndex];
    const predecessors = [...(block?.pred || [])];
    if (!predecessors.length) return null;
    const incoming = predecessors.map((pred) => resolve(ir, pred, null, key, values, opts, engine, active, depth + 1));
    if (incoming.some((x) => !x)) return null;
    const unique = new Map(incoming.map((x) => [structuralKey(x), x]));
    if (unique.size === 1) return incoming[0];
    if (predecessors.length !== 2 || unique.size !== 2) return null;

    const control = controller(ir, blockIndex, predecessors, opts);
    if (!control) return null;
    const condition = simplify(branchCondition(ir, control.term, values), engine);
    if (!condition) return null;
    const bits = incoming[0]?.bits || incoming[1]?.bits || 64;
    const signed = condition.compareSigned ?? incoming[0]?.signed ?? incoming[1]?.signed ?? null;
    return simplify(expr.select(condition, incoming[control.yesIndex], incoming[control.noIndex], bits, signed, {
      address:control.term.address,
      row:control.term.row,
      ir:control.term.id,
      evidence:[{ reason:'exact stack CFG join' }],
    }), engine);
  } finally {
    active.delete(token);
  }
}

function rewriteReturn(result, expression, opts) {
  const output = result.semanticAst?.outputs?.find((x) => x.name === 'return');
  if (!output) return false;
  output.expression = expression;
  let changed = false;
  for (const node of result.cAst?.body || []) {
    if (node.semantic?.op === 'return' || /^return\b/.test(String(node.text || '').trim())) {
      node.text = `return ${printExpression(expression)};`;
      if (node.semantic) node.semantic.expression = expression;
      changed = true;
    }
  }
  if (!changed) return false;
  const printed = printProgram(result.cAst, { columnWidth:opts.columnWidth || opts.prettyColumnWidth || 88 });
  result.pseudocode = printed.text;
  result.sourceMap = printed.mapping;
  result.lines = result.cAst.body.map((node) => ({
    kind:node.kind, indent:node.indent, text:node.text,
    row:node.source?.rows?.[0] ?? null, addr:node.source?.addresses?.[0] ?? null,
    note:null, source:node.source,
  }));
  return true;
}

function committedStackSpillOnExactReturnPath(result, root, ret) {
  for (const inst of before(result.ir, ret.block, ret.row)) {
    if (inst?.op === 'store' && inst.loc?.kind === 'stack' && inst.loc.key === root.location.key) {
      const location = committedLocationForPhi(result, valueOf(inst.args?.[0]));
      return location ? { stackStore:inst, location } : null;
    }
    if (unsafeBarrier(inst, root.location.key)) return null;
  }
  return null;
}

function removeProofOnlyStackSpill(result, stackStore, opts) {
  const body = result.cAst?.body;
  if (!Array.isArray(body) || !stackStore) return false;
  const storeRow = Number(stackStore.row);
  const storeId = String(stackStore.id);
  const filtered = body.filter((node) => {
    const text = String(node?.text || '');
    if (!/^\s*local_[A-Za-z0-9_]+\s*=/.test(text)) return true;
    const rows = node?.source?.rows || [];
    const ir = node?.source?.ir || [];
    const isSpill = rows.some((row) => Number(row) === storeRow) || ir.some((id) => String(id) === storeId);
    return !isSpill;
  });
  if (filtered.length === body.length) return false;
  result.cAst.body = filtered;
  const printed = printProgram(result.cAst, { columnWidth:opts.columnWidth || opts.prettyColumnWidth || 88 });
  result.pseudocode = printed.text;
  result.sourceMap = printed.mapping;
  result.lines = result.cAst.body.map((node) => ({
    kind:node.kind, indent:node.indent, text:node.text,
    row:node.source?.rows?.[0] ?? null, addr:node.source?.addresses?.[0] ?? null,
    note:null, source:node.source,
  }));
  return true;
}

export function recoverExactStackReturn(result, opts = {}) {
  if (!result?.semantic || !result.ir || !result.semanticAst || !result.cAst) return result;
  const output = result.semanticAst.outputs?.find((x) => x.name === 'return');
  const root = output?.expression;
  if (root?.kind !== 'load' || root.location?.kind !== 'stack' || !root.location?.key) return result;
  const ret = [...(result.ir.instructions || [])].reverse().find((i) => i.op === 'ret');
  if (!ret) return result;

  const values = mapsOf(result);
  const engine = new RewriteEngine(DEFAULT_RULES, {
    maxIterations:10,
    nodeBudget:Math.min(2048, Number(opts.decompilerNodeBudget || 12000)),
    timeBudgetMs:Math.min(12, Math.max(4, Number(opts.decompilerTimeBudgetMs || 50) / 4)),
    maxApplications:512,
  });
  let committed = committedReturnValue(result, root, ret, opts);
  let committedSpill = null;
  if (!committed) {
    const proof = committedStackSpillOnExactReturnPath(result, root, ret);
    if (proof) {
      committedSpill = proof.stackStore;
      committed = expr.load(proof.location, root.bits || 64, root.source, {
        signed:root.signed ?? null,
        proof:'exact return-path spill carries an SSA phi whose predecessors commit one lvalue',
      });
    }
  }
  const recovered = committed || resolve(result.ir, ret.block, ret.row, root.location.key, values, opts, engine, new Set());
  // A stack load means no useful reconstruction happened. A committed non-stack
  // field/global load is an intentional high-level return and must be retained.
  if (!recovered || (recovered.kind === 'load' && recovered.location?.kind === 'stack') || !rewriteReturn(result, recovered, opts)) return result;
  if (committedSpill) removeProofOnlyStackSpill(result, committedSpill, opts);

  result.rewriteProof = [...(result.rewriteProof || []), {
    rule:'exact-stack-return-recovery', phase:'memory-ssa',
    evidence:{ kind:'cfg-memory-ssa', detail:'exact stack return reconstructed from predecessor stores and flag-producing SSA evidence' },
  }];
  result.metrics = { ...(result.metrics || {}), rewrittenExpressions:(result.metrics?.rewrittenExpressions || 0) + 1, sourceMappedNodes:result.sourceMap?.length || 0 };
  result.ctx = { ...(result.ctx || {}), decompilerPipeline:{ ...(result.ctx?.decompilerPipeline || {}), exactStackReturnRecovered:true } };
  return result;
}
