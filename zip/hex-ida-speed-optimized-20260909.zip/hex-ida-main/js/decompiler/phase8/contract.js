/**
 * Phase 8 pass contract.
 *
 * Every Phase 8 middle-end pass — SCCP, GVN/CSE, effect-aware DCE, induction,
 * structuring, aggregate recovery, language providers — declares itself through
 * this one contract. The point is not bureaucracy: it is that an optimizer which
 * invents its own publication, cancellation and invalidation rules is an
 * optimizer nobody can prove safe afterwards (PHASE8_CHECKPOINT_CONTRACTS P8-1).
 *
 * A descriptor answers "what does this pass read, keep and destroy". A result
 * answers "what actually happened, how complete was it, and what may now be
 * reused". Both are frozen and both are validated fail-closed: an unknown stage,
 * an undeclared analysis key, or a result that claims to have changed something
 * while declaring nothing invalidated is an error at construction time rather
 * than a stale cache three passes later.
 *
 * P8-0 shipped the versioned skeleton and one identity pass through the real
 * production pipeline. P8-1 added `produces` and the staged/atomic transaction
 * in ./transaction.js. P8-2 separated producing a fact from rewriting the
 * program: an analysis pass changes the state without transforming anything, and
 * requiring it to invent a transform record would have made provenance a
 * formality. The shape is versioned so a contract change invalidates derived
 * artifacts instead of silently reinterpreting them. P8-3 added the `deadCode`
 * key; a pass that does not preserve it now invalidates it, which is the
 * conservative direction. P8-4 added `induction`, the loop/trip fact summary
 * that structuring and aggregate recovery consume instead of each deriving
 * their own. P8-7 added `providerHints`, the refinement layer's output, kept as
 * its own key so a provider version change invalidates provider-derived
 * artifacts and nothing else.
 */

/**
 * Bumped when the descriptor/result shape changes in a way that makes older
 * published Phase 8 results uninterpretable. It is part of artifact key
 * material, so a bump invalidates derived artifacts rather than silently
 * reusing them (EP-005 evidence-invalidation rule, MIGRATION_GUARDRAILS §CI).
 */
export const PHASE8_CONTRACT_VERSION = 6;

/**
 * Ordered pipeline stages. Order here is the dependency order Phase 8 accepts;
 * it is a declared contract rather than the incidental order of an array
 * literal, which is what the P8-1 merge blockers explicitly reject.
 */
export const PASS_STAGES = Object.freeze([
  'canonical-facts',
  'scalar-optimization',
  'memory-optimization',
  'loop-facts',
  'high-level-recovery',
  'structuring',
  'providers',
  'rendering',
]);

/**
 * Analyses a pass may declare it consumes, preserves or invalidates. Anything
 * outside this set is a typo or an undeclared dependency; both are errors.
 */
export const ANALYSIS_KEYS = Object.freeze([
  'cfg',
  'dominators',
  'loops',
  'ssa',
  'memorySsa',
  'alias',
  'effects',
  'ranges',
  'valueNumbers',
  'deadCode',
  'induction',
  'types',
  'aggregates',
  'summaries',
  'origins',
  'structuredRegions',
  'providerHints',
]);

/** What a pass run did. `unsupported` is a first-class answer, never skip-green. */
export const PASS_STATUSES = Object.freeze(['unchanged', 'changed', 'degraded', 'unsupported']);

/** How complete the pass's own reasoning was. Budget truncation is `partial`. */
export const COMPLETENESS = Object.freeze(['complete', 'partial', 'unknown']);

/** Budget classes. A pass declares the cost class it belongs to up front. */
export const BUDGET_CLASSES = Object.freeze(['interactive', 'standard', 'exhaustive']);

const STAGE_SET = new Set(PASS_STAGES);
const ANALYSIS_SET = new Set(ANALYSIS_KEYS);
const STATUS_SET = new Set(PASS_STATUSES);
const COMPLETENESS_SET = new Set(COMPLETENESS);
const BUDGET_SET = new Set(BUDGET_CLASSES);
const PASS_RESULT_KEYS = new Set([
  'contractVersion', 'passId', 'passVersion', 'stage', 'status', 'changed',
  'completeness', 'transforms', 'diagnostics', 'invalidated', 'produced',
  'preserved', 'stopReason',
]);

function fail(code) { throw new TypeError(code); }

function nonEmptyString(value, code) {
  if (typeof value !== 'string' || value.length === 0) fail(code);
  return value;
}

function analysisList(values, code) {
  if (values == null) return Object.freeze([]);
  if (!Array.isArray(values)) fail(code);
  const unique = [...new Set(values)];
  for (const key of unique) {
    if (typeof key !== 'string' || !ANALYSIS_SET.has(key)) fail(`${code}:${String(key)}`);
  }
  return Object.freeze(unique.sort());
}

function diagnosticList(values) {
  if (values == null) return Object.freeze([]);
  if (!Array.isArray(values)) fail('phase8-pass-diagnostics-invalid');
  return Object.freeze(values.map((item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) fail('phase8-pass-diagnostic-invalid');
    return Object.freeze({
      severity: nonEmptyString(item.severity, 'phase8-pass-diagnostic-severity-required'),
      code: nonEmptyString(item.code, 'phase8-pass-diagnostic-code-required'),
      message: nonEmptyString(item.message, 'phase8-pass-diagnostic-message-required'),
      // Why the pass could not do better. A missed optimization with no reason
      // recorded is indistinguishable from a pass that never ran.
      reason: item.reason == null ? null : String(item.reason),
    });
  }));
}

function transformList(values) {
  if (values == null) return Object.freeze([]);
  if (!Array.isArray(values)) fail('phase8-pass-transforms-invalid');
  return Object.freeze(values.map((item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) fail('phase8-pass-transform-invalid');
    return Object.freeze({
      kind: nonEmptyString(item.kind, 'phase8-pass-transform-kind-required'),
      // Provenance is not optional. A transform that cannot say which semantic
      // entities it rewrote cannot be audited, and Phase 8's hard-zero exit gate
      // is `provenanceLossCount = 0`.
      targets: Object.freeze([...new Set(
        (Array.isArray(item.targets) && item.targets.length > 0
          ? item.targets
          : fail('phase8-pass-transform-targets-required'))
          .map((target) => nonEmptyString(target, 'phase8-pass-transform-target-invalid')),
      )].sort()),
      proof: nonEmptyString(item.proof, 'phase8-pass-transform-proof-required'),
      originRefs: Object.freeze([...new Set(
        (item.originRefs ?? []).map((ref) => nonEmptyString(ref, 'phase8-pass-transform-origin-invalid')),
      )].sort()),
    });
  }));
}

/**
 * Declares one Phase 8 pass.
 *
 * `preserves` and `invalidates` must be disjoint: a pass that claims to both
 * keep and destroy an analysis has not decided what it does, and downstream
 * reuse would depend on which check ran first.
 */
export function createPassDescriptor(input = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) fail('phase8-pass-descriptor-invalid');
  const id = nonEmptyString(input.id, 'phase8-pass-id-required');
  const version = nonEmptyString(input.version, 'phase8-pass-version-required');
  const stage = nonEmptyString(input.stage, 'phase8-pass-stage-required');
  if (!STAGE_SET.has(stage)) fail(`phase8-pass-unknown-stage:${stage}`);
  const budgetClass = input.budgetClass ?? 'standard';
  if (!BUDGET_SET.has(budgetClass)) fail(`phase8-pass-unknown-budget-class:${budgetClass}`);
  const consumes = analysisList(input.consumes, 'phase8-pass-unknown-consumed-analysis');
  const preserves = analysisList(input.preserves, 'phase8-pass-unknown-preserved-analysis');
  const invalidates = analysisList(input.invalidates, 'phase8-pass-unknown-invalidated-analysis');
  const produces = analysisList(input.produces, 'phase8-pass-unknown-produced-analysis');
  for (const key of invalidates) {
    if (preserves.includes(key)) fail(`phase8-pass-preserves-and-invalidates:${key}`);
  }
  // Producing an analysis and preserving it are contradictory claims: the
  // consumer cannot both keep its cached version and receive a new one.
  for (const key of produces) {
    if (preserves.includes(key)) fail(`phase8-pass-preserves-and-produces:${key}`);
  }
  return Object.freeze({
    contractVersion: PHASE8_CONTRACT_VERSION,
    id,
    version,
    stage,
    stageIndex: PASS_STAGES.indexOf(stage),
    budgetClass,
    consumes,
    preserves,
    invalidates,
    // Analyses this pass writes. The transaction refuses a staged write to
    // anything not declared here, so an undeclared production cannot become an
    // undeclared dependency for everything downstream.
    produces,
    // A pass that must run even under an exhausted budget so the public result
    // stays structurally valid. Optional passes are skipped instead.
    required: input.required === true,
    description: input.description == null ? '' : String(input.description),
  });
}

/**
 * Records what one pass run produced.
 *
 * `changed` and `status` are kept consistent here rather than by convention:
 * a `changed` status with no invalidated analyses and no transforms is the exact
 * shape that produces a stale downstream fact, so it is rejected.
 */
export function createPassResult(input = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) fail('phase8-pass-result-invalid');
  const descriptor = input.descriptor;
  if (!descriptor || descriptor.contractVersion !== PHASE8_CONTRACT_VERSION) fail('phase8-pass-result-descriptor-required');
  const status = nonEmptyString(input.status, 'phase8-pass-result-status-required');
  if (!STATUS_SET.has(status)) fail(`phase8-pass-result-unknown-status:${status}`);
  const completeness = input.completeness ?? 'complete';
  if (!COMPLETENESS_SET.has(completeness)) fail(`phase8-pass-result-unknown-completeness:${completeness}`);
  const transforms = transformList(input.transforms);
  const diagnostics = diagnosticList(input.diagnostics);
  const invalidated = analysisList(input.invalidated, 'phase8-pass-result-unknown-invalidated-analysis');
  for (const key of invalidated) {
    if (!descriptor.invalidates.includes(key)) fail(`phase8-pass-result-undeclared-invalidation:${key}`);
  }
  const produced = analysisList(input.produced, 'phase8-pass-result-unknown-produced-analysis');
  for (const key of produced) {
    if (!descriptor.produces.includes(key)) fail(`phase8-pass-result-undeclared-production:${key}`);
  }
  if ((status === 'unchanged' || status === 'unsupported') && input.changed === true) {
    fail(`phase8-pass-result-${status}-changed`);
  }
  if (status === 'changed' && input.changed === false) fail('phase8-pass-result-changed-not-changed');
  const changed = status === 'changed' ? true : status === 'degraded' ? input.changed !== false : false;
  // A change has to be accounted for by something: a program transformation or a
  // produced analysis. These are different things. An analysis pass that proved
  // nothing still changed the state — "SCCP ran and found nothing" is not the
  // same fact as "SCCP never ran" — and forcing it to file a transform record
  // with no target would turn provenance into a formality.
  if (changed && transforms.length === 0 && produced.length === 0) fail('phase8-pass-result-changed-without-transform-or-production');
  if (!changed && transforms.length > 0) fail('phase8-pass-result-transform-without-change');
  if (!changed && produced.length > 0) fail('phase8-pass-result-production-without-change');
  if (!changed && invalidated.length > 0) {
    fail(`phase8-pass-result-${status}-invalidates`);
  }
  if (status === 'unsupported' && completeness === 'complete') fail('phase8-pass-result-unsupported-claims-complete');
  return Object.freeze({
    contractVersion: PHASE8_CONTRACT_VERSION,
    passId: descriptor.id,
    passVersion: descriptor.version,
    stage: descriptor.stage,
    status,
    changed,
    completeness,
    transforms,
    diagnostics,
    invalidated,
    produced,
    // Analyses that survive this pass, derived from the declaration rather than
    // restated by the pass body, so the two cannot drift.
    preserved: descriptor.preserves,
    stopReason: input.stopReason == null ? null : nonEmptyString(input.stopReason, 'phase8-pass-result-stop-reason-invalid'),
  });
}

/** The common "this pass looked and had nothing safe to do" answer. */
export function unchangedResult(descriptor, { completeness = 'complete', diagnostics = [], stopReason = null } = {}) {
  return createPassResult({ descriptor, status: 'unchanged', changed: false, completeness, diagnostics, stopReason });
}

const PASS_RESULT_SNAPSHOT_NODE_LIMIT = 10_000;
const PASS_RESULT_SNAPSHOT_PROPERTY_LIMIT = 10_000;
const PASS_RESULT_SNAPSHOT_EDGE_LIMIT = 20_000;
const SNAPSHOT_RESULT = 'result';
const SNAPSHOT_DIAGNOSTIC = 'diagnostic';
const SNAPSHOT_TRANSFORM = 'transform';
const SNAPSHOT_DIAGNOSTICS = 'diagnostics';
const SNAPSHOT_TRANSFORMS = 'transforms';
const SNAPSHOT_STRING_ARRAY = 'string-array';
const SNAPSHOT_SCALAR = 'scalar';
const DIAGNOSTIC_RESULT_KEYS = new Set(['severity', 'code', 'message', 'reason']);
const TRANSFORM_RESULT_KEYS = new Set(['kind', 'targets', 'proof', 'originRefs']);

function snapshotAllowedKeys(schema) {
  if (schema === SNAPSHOT_RESULT) return PASS_RESULT_KEYS;
  if (schema === SNAPSHOT_DIAGNOSTIC) return DIAGNOSTIC_RESULT_KEYS;
  if (schema === SNAPSHOT_TRANSFORM) return TRANSFORM_RESULT_KEYS;
  return null;
}

function snapshotChildSchema(schema, key) {
  if (schema === SNAPSHOT_RESULT) {
    if (key === 'diagnostics') return SNAPSHOT_DIAGNOSTICS;
    if (key === 'transforms') return SNAPSHOT_TRANSFORMS;
    if (key === 'invalidated' || key === 'produced' || key === 'preserved') return SNAPSHOT_STRING_ARRAY;
    return SNAPSHOT_SCALAR;
  }
  if (schema === SNAPSHOT_DIAGNOSTIC) return SNAPSHOT_SCALAR;
  if (schema === SNAPSHOT_TRANSFORM) {
    return key === 'targets' || key === 'originRefs' ? SNAPSHOT_STRING_ARRAY : SNAPSHOT_SCALAR;
  }
  return SNAPSHOT_SCALAR;
}

function snapshotArrayElementSchema(schema) {
  if (schema === SNAPSHOT_DIAGNOSTICS) return SNAPSHOT_DIAGNOSTIC;
  if (schema === SNAPSHOT_TRANSFORMS) return SNAPSHOT_TRANSFORM;
  return SNAPSHOT_SCALAR;
}

function snapshotPassResultData(value) {
  const active = new Set();
  const cloned = new Map();
  let nodes = 0;
  let properties = 0;
  let edges = 0;

  const clone = (current, schema) => {
    if (schema === SNAPSHOT_SCALAR) {
      if (typeof current === 'function') throw new TypeError('phase8-pass-result-function-property');
      if (current == null || typeof current !== 'object') return current;
      throw new TypeError('phase8-pass-result-non-data-object');
    }
    if (current == null || typeof current !== 'object' || typeof current === 'function') {
      throw new TypeError('phase8-pass-result-non-data-object');
    }
    if (active.has(current)) throw new TypeError('phase8-pass-result-cycle');
    const previous = cloned.get(current);
    if (previous !== undefined) {
      if (previous.schema !== schema) throw new TypeError('phase8-pass-result-shared-shape');
      return previous.value;
    }
    if (nodes >= PASS_RESULT_SNAPSHOT_NODE_LIMIT) throw new TypeError('phase8-pass-result-too-large');

    const array = Array.isArray(current);
    const arraySchema = schema === SNAPSHOT_DIAGNOSTICS
      || schema === SNAPSHOT_TRANSFORMS || schema === SNAPSHOT_STRING_ARRAY;
    if (array !== arraySchema) throw new TypeError('phase8-pass-result-shape');
    const prototype = Object.getPrototypeOf(current);
    if (array ? prototype !== Array.prototype : (prototype !== Object.prototype && prototype !== null)) {
      throw new TypeError('phase8-pass-result-non-data-object');
    }

    let length = null;
    if (array) {
      // Array length is a data descriptor and can be checked before Reflect.
      // ownKeys materializes one index key per element, so a hostile sparse
      // array must not allocate that list before the snapshot budget applies.
      const lengthDescriptor = Object.getOwnPropertyDescriptor(current, 'length');
      if (!lengthDescriptor || !Object.hasOwn(lengthDescriptor, 'value')
        || !Number.isSafeInteger(lengthDescriptor.value) || lengthDescriptor.value < 0) {
        throw new TypeError('phase8-pass-result-array-length-invalid');
      }
      length = lengthDescriptor.value;
      if (length > PASS_RESULT_SNAPSHOT_PROPERTY_LIMIT) {
        throw new TypeError('phase8-pass-result-too-large');
      }
    }

    // Enumerate once, reject schema-incompatible keys before reading any
    // descriptors, and account for the whole container before cloning a value.
    const keys = Reflect.ownKeys(current);
    if (keys.length > PASS_RESULT_SNAPSHOT_PROPERTY_LIMIT) {
      throw new TypeError('phase8-pass-result-too-large');
    }
    const allowedKeys = snapshotAllowedKeys(schema);
    if (allowedKeys && keys.some((key) => typeof key !== 'string' || !allowedKeys.has(key))) {
      throw new TypeError('phase8-pass-result-unknown-property');
    }
    if (keys.some((key) => typeof key !== 'string')) {
      throw new TypeError('phase8-pass-result-symbol-property');
    }

    let edgeCount = keys.length;
    if (array) {
      if (keys.length !== length + 1) throw new TypeError('phase8-pass-result-array-shape-invalid');
      edgeCount = length;
    }
    if (properties + keys.length > PASS_RESULT_SNAPSHOT_PROPERTY_LIMIT
      || edges + edgeCount > PASS_RESULT_SNAPSHOT_EDGE_LIMIT) {
      throw new TypeError('phase8-pass-result-too-large');
    }
    properties += keys.length;
    edges += edgeCount;
    nodes += 1;

    active.add(current);
    try {
      if (array) {
        const copy = new Array(length);
        const elementSchema = snapshotArrayElementSchema(schema);
        for (let index = 0; index < length; index += 1) {
          const descriptor = Object.getOwnPropertyDescriptor(current, String(index));
          if (!descriptor || !Object.hasOwn(descriptor, 'value')) {
            throw new TypeError('phase8-pass-result-accessor');
          }
          copy[index] = clone(descriptor.value, elementSchema);
        }
        const frozen = Object.freeze(copy);
        cloned.set(current, { schema, value: frozen });
        return frozen;
      }

      const copy = Object.create(null);
      for (const key of keys) {
        const descriptor = Object.getOwnPropertyDescriptor(current, key);
        if (!descriptor || !Object.hasOwn(descriptor, 'value')) {
          throw new TypeError('phase8-pass-result-accessor');
        }
        Object.defineProperty(copy, key, {
          value: clone(descriptor.value, snapshotChildSchema(schema, key)),
          enumerable: true,
          writable: true,
          configurable: true,
        });
      }
      const frozen = Object.freeze(copy);
      cloned.set(current, { schema, value: frozen });
      return frozen;
    } finally {
      active.delete(current);
    }
  };

  try {
    return clone(value, SNAPSHOT_RESULT);
  } catch {
    return null;
  }
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/**
 * Validates untrusted PassResult candidates fail-closed and non-coercively.
 *
 * Guaranteed never to call `.toString()`, `.valueOf()`, getters, or convert
 * objects into strings or numbers.
 */
function isCanonicalList(values) {
  for (let i = 1; i < values.length; i += 1) {
    if (values[i - 1] >= values[i]) return false;
  }
  return true;
}

function isDescriptorAuthorizedList(values, allowed) {
  return isCanonicalList(values) && values.every((key) => allowed.includes(key));
}

function isCanonicalPassResultOwned(result, descriptor = null) {
  try {
    if (result == null || typeof result !== 'object' || Array.isArray(result)) return false;
    const keys = Reflect.ownKeys(result);
    if (keys.some((key) => typeof key !== 'string' || !PASS_RESULT_KEYS.has(key))) return false;
    if (result.contractVersion !== PHASE8_CONTRACT_VERSION) return false;
    if (!isNonEmptyString(result.passId)) return false;
    if (!isNonEmptyString(result.passVersion)) return false;
    if (typeof result.stage !== 'string' || !STAGE_SET.has(result.stage)) return false;
    if (typeof result.status !== 'string' || !STATUS_SET.has(result.status)) return false;
    if (typeof result.changed !== 'boolean') return false;
    if (typeof result.completeness !== 'string' || !COMPLETENESS_SET.has(result.completeness)) return false;
    if (result.stopReason != null && !isNonEmptyString(result.stopReason)) return false;

    if (!Array.isArray(result.invalidated)) return false;
    for (let i = 0; i < result.invalidated.length; i++) {
      const item = result.invalidated[i];
      if (typeof item !== 'string' || !ANALYSIS_SET.has(item)) return false;
    }

    if (!Array.isArray(result.produced)) return false;
    for (let i = 0; i < result.produced.length; i++) {
      const item = result.produced[i];
      if (typeof item !== 'string' || !ANALYSIS_SET.has(item)) return false;
    }

    if (!Array.isArray(result.preserved)) return false;
    for (let i = 0; i < result.preserved.length; i++) {
      const item = result.preserved[i];
      if (typeof item !== 'string' || !ANALYSIS_SET.has(item)) return false;
    }

    if (!Array.isArray(result.diagnostics)) return false;
    for (let i = 0; i < result.diagnostics.length; i++) {
      const diag = result.diagnostics[i];
      if (diag == null || typeof diag !== 'object' || Array.isArray(diag)) return false;
      if (!isNonEmptyString(diag.severity)) return false;
      if (!isNonEmptyString(diag.code)) return false;
      if (!isNonEmptyString(diag.message)) return false;
      if (diag.reason != null && typeof diag.reason !== 'string') return false;
    }

    if (!Array.isArray(result.transforms)) return false;
    for (let i = 0; i < result.transforms.length; i++) {
      const tx = result.transforms[i];
      if (tx == null || typeof tx !== 'object' || Array.isArray(tx)) return false;
      if (!isNonEmptyString(tx.kind)) return false;
      if (!isNonEmptyString(tx.proof)) return false;
      if (!Array.isArray(tx.targets) || tx.targets.length === 0) return false;
      for (let j = 0; j < tx.targets.length; j++) {
        if (!isNonEmptyString(tx.targets[j])) return false;
      }
      if (tx.originRefs != null) {
        if (!Array.isArray(tx.originRefs)) return false;
        for (let k = 0; k < tx.originRefs.length; k++) {
          if (!isNonEmptyString(tx.originRefs[k])) return false;
        }
      }
    }

    if ((result.status === 'unchanged' || result.status === 'unsupported') && result.changed === true) {
      return false;
    }
    if (result.status === 'changed' && result.changed === false) {
      return false;
    }
    if (result.changed && result.transforms.length === 0 && result.produced.length === 0) {
      return false;
    }
    if (!result.changed && (result.transforms.length > 0 || result.produced.length > 0 || result.invalidated.length > 0)) {
      return false;
    }
    if (result.status === 'unsupported' && result.completeness === 'complete') {
      return false;
    }

    // `preserved` is derived from the invoked descriptor by createPassResult;
    // accepting a caller-supplied policy list would let the transaction commit
    // with one authority while its published ledger names another. The other
    // policy lists are observations, so they may be subsets, but every entry
    // must be declared by the invoked descriptor and retain analysisList's
    // sorted/unique canonical form.
    if (descriptor != null) {
      if (!Array.isArray(descriptor.preserves) || result.preserved.length !== descriptor.preserves.length
        || result.preserved.some((key, index) => key !== descriptor.preserves[index])) return false;
      if (!Array.isArray(descriptor.invalidates) || !isDescriptorAuthorizedList(result.invalidated, descriptor.invalidates)) return false;
      if (!Array.isArray(descriptor.produces) || !isDescriptorAuthorizedList(result.produced, descriptor.produces)) return false;
    }

    return true;
  } catch {
    return false;
  }
}


/**
 * Returns the canonical owned snapshot for an untrusted pass result.
 *
 * The transaction boundary uses this returned value for every later contract
 * check and publication decision, so a caller-owned accessor cannot validate
 * one value and substitute another before commit.
 */
export function snapshotCanonicalPassResult(result, descriptor = null) {
  const snapshot = snapshotPassResultData(result);
  return snapshot != null && isCanonicalPassResultOwned(snapshot, descriptor) ? snapshot : null;
}

/** Returns whether an untrusted pass result is a canonical, owned data value. */
export function isCanonicalPassResult(result) {
  return snapshotCanonicalPassResult(result) != null;
}
