import { ByteView } from './reader.js';
import { BinaryImage, functionSeed } from './model.js';
import { parseImports, parseExports, parseExceptionFunctions, parseBaseRelocations, parseCoffSymbols, parseDelayImports, parseTlsDirectory, parseLoadConfig, directory, peMachineName, createPEMetadataBudget } from './pe-loader.js';

const IMAGE_DIRECTORY_ENTRY_EXPORT = 0;
const IMAGE_DIRECTORY_ENTRY_IMPORT = 1;
const IMAGE_DIRECTORY_ENTRY_EXCEPTION = 3;
const IMAGE_DIRECTORY_ENTRY_BASERELOC = 5;
const IMAGE_DIRECTORY_ENTRY_TLS = 9;
const IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG = 10;
const IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT = 13;
const WINDOWS_IMAGE_RAW_ALIGNMENT = 0x200;

function windowsImageSectionRawMapping(pointerToRawData, { sectionAlignment } = {}) {
  if (pointerToRawData === 0) {
    return { effectiveFileOffset: 0, fileBacked: false, roundedDown: false };
  }
  // The Windows loader's 0x200 sector round-down only applies to images
  // mapped at the default page granularity. Low-alignment images
  // (SectionAlignment < 0x1000, e.g. pefile issue #465's resource-only PE
  // with SectionAlignment = FileAlignment = 0x10) are consumed with their
  // declared raw offsets: the loader does not reinterpret PointerToRawData,
  // and rounding it down would redirect the mapping into the MZ/header
  // bytes (#5539).
  if (Number.isSafeInteger(sectionAlignment) && sectionAlignment > 0 && sectionAlignment < 0x1000) {
    return {
      effectiveFileOffset: pointerToRawData,
      fileBacked: true,
      roundedDown: false,
      policy: 'low-alignment-declared-raw-offset',
    };
  }
  const effectiveFileOffset = pointerToRawData - (pointerToRawData % WINDOWS_IMAGE_RAW_ALIGNMENT);
  return {
    effectiveFileOffset,
    fileBacked: true,
    roundedDown: effectiveFileOffset !== pointerToRawData,
  };
}

function isPowerOfTwo(value) {
  return Number.isInteger(value) && value > 0 && (value & (value - 1)) === 0;
}

function validPEFileAlignment(fileAlignment, sectionAlignment) {
  if (!isPowerOfTwo(fileAlignment)) return false;
  if (sectionAlignment > 0 && sectionAlignment < 0x1000) return fileAlignment === sectionAlignment;
  return fileAlignment >= 0x200 && fileAlignment <= 0x10000;
}

function windowsImageSectionRawSize(sizeOfRawData, fileAlignment, sectionAlignment) {
  const alignmentValid = validPEFileAlignment(fileAlignment, sectionAlignment);
  if (sizeOfRawData === 0 || !alignmentValid) {
    return { effectiveRawSize: sizeOfRawData, alignmentValid, roundedUp: false };
  }
  const effectiveRawSize = Math.ceil(sizeOfRawData / fileAlignment) * fileAlignment;
  return { effectiveRawSize, alignmentValid: true, roundedUp: effectiveRawSize !== sizeOfRawData };
}

function seedValidatedEntrypoint(image, entryRva, sizeOfImage, machine) {
  const address = image.imageBase + BigInt(entryRva);
  const reject = (reason) => {
    image.warnings.push(`PE entrypoint 0x${entryRva.toString(16)} rejected: ${reason}`);
    image.metadata.entrypointValid = false;
    image.metadata.entrypointDiagnostic = reason;
  };
  if (entryRva >= sizeOfImage) { reject('RVA is outside SizeOfImage'); return; }
  const segment = image.segments.find((s) => s.source === 'PE-section' &&
    address >= s.address && address < s.address + s.size);
  if (!segment) { reject('RVA is not mapped by a section'); return; }
  if (!segment.perms?.execute) { reject('section is not executable'); return; }
  const offset = address - segment.address;
  if (offset < 0n || offset >= segment.fileSize) { reject('entrypoint has no file-backed instruction byte'); return; }
  // RISC-V base ISA is IALIGN=32 (4-byte); the issue only demands rejecting
  // non-instruction-boundary addresses, and 2 is the loosest legal IALIGN, so
  // 2-byte alignment is the fail-closed floor for RISC-V entrypoints (#5545).
  const alignment = machine === 0xaa64 || machine === 0x01c0 ? 4n
    : machine === 0x5032 || machine === 0x5064 || machine === 0x01c4 ? 2n
    : 1n;
  if (address % alignment !== 0n) { reject(`address is not ${alignment}-byte aligned`); return; }
  image.metadata.entrypointValid = true;
  image.metadata.entrypointDiagnostic = null;
  image.functions.push(functionSeed(address, { source: 'entrypoint', confidence: 0.9 }));
}

function reconcileExportFunctionEvidence(image) {
  const exportNames = new Map();
  for (const ex of image.exports || []) {
    if (!ex || ex.kind === 'forwarder' || ex.address == null || ex.address === 0n || !ex.name) continue;
    const address = BigInt(ex.address).toString();
    const names = exportNames.get(address);
    if (names) names.add(ex.name);else exportNames.set(address,new Set([ex.name]));
  }
  let rejectedExportOnly = 0;
  image.functions = (image.functions || []).filter((f) => {
    if (f?.source !== 'export') return true;
    rejectedExportOnly++;
    return false;
  });
  let corroborated = 0;
  for (const f of image.functions) {
    if (f?.address == null) continue;
    const names = exportNames.get(BigInt(f.address).toString());
    const name = names?.values().next().value || null;
    if (!name) continue;
    corroborated++;
    if (!f.name) f.name = name;
    f.sources = [...new Set([...(f.sources || [f.source]), 'export-name'])];
  }
  image.metadata.peExportFunctionEvidence = {
    policy:'export-is-symbol-evidence-not-function-proof',
    rejectedExportOnly,
    corroborated,
  };
}

export function parsePE(input, options = {}) {
  const bytes = new ByteView(input).bytes;
  const r = new ByteView(bytes, { littleEndian: true });
  if (r.length < 0x40 || r.u16(0) !== 0x5a4d) throw new Error('not a PE file');
  const pe = r.u32(0x3c);
  if (pe + 24 > r.length || r.u32(pe) !== 0x00004550) throw new Error('invalid PE signature');
  const coff = pe + 4;
  const machine = r.u16(coff);
  const numberOfSections = r.u16(coff + 2);
  const timestamp = r.u32(coff + 4);
  const ptrSymbols = r.u32(coff + 8);
  const numberOfSymbols = r.u32(coff + 12);
  const sizeOptional = r.u16(coff + 16);
  const characteristics = r.u16(coff + 18);
  const opt = coff + 20;
  if (opt + sizeOptional > r.length) throw new Error('PE optional header is truncated');
  if (sizeOptional < 2) throw new Error('PE optional header is too small for its magic');
  const magic = r.u16(opt);
  if (magic !== 0x10b && magic !== 0x20b) throw new Error(`unsupported PE optional magic 0x${magic.toString(16)}`);
  const bits = magic === 0x20b ? 64 : 32;
  const minimumOptionalSize = bits === 64 ? 112 : 96;
  if (sizeOptional < minimumOptionalSize) throw new Error(`PE optional header size ${sizeOptional} is smaller than ${minimumOptionalSize}`);
  const entryRva = r.u32(opt + 16);
  const imageBase = bits === 64 ? r.u64(opt + 24) : BigInt(r.u32(opt + 28));
  const sectionAlignment = r.u32(opt + 32);
  const fileAlignment = r.u32(opt + 36);
  const sizeOfImage = r.u32(opt + 56);
  const sizeOfHeaders = r.u32(opt + 60);
  const subsystem = r.u16(opt + 68);
  const numberOfRvaAndSizes = r.u32(opt + (bits === 64 ? 108 : 92));
  const dirBase = opt + (bits === 64 ? 112 : 96);
  const directories = [];
  // Bounds safety (how many entries physically fit) and format validity (how
  // many were declared) are separate questions (#6118): a declared count that
  // the optional header cannot hold is truncation, not absence.
  const availableEntries = Math.max(0, Math.floor((opt + sizeOptional - dirBase) / 8));
  const requiredKnownEntries = Math.min(numberOfRvaAndSizes, 16);
  const dirCount = Math.min(requiredKnownEntries, availableEntries);
  const directoryShortfall = requiredKnownEntries - dirCount;
  for (let i = 0; i < dirCount; i++) directories.push({ rva: r.u32(dirBase + i * 8), size: r.u32(dirBase + i * 8 + 4) });

  const image = new BinaryImage(bytes, {
    format: 'pe', arch: peMachineName(machine), bits, endian: 'little', platform: 'windows',
    imageBase, entrypoint: entryRva ? imageBase + BigInt(entryRva) : null,
    metadata: { machine, timestamp, characteristics, subsystem, sectionAlignment, fileAlignment, sizeOfImage, sizeOfHeaders, directories, peSectionRawMappings: [], peSectionRawSizes: [] },
  });
  if (directoryShortfall > 0) {
    image.metadata.peDataDirectoriesTruncated = true;
    image.metadata.peDataDirectoryShortfall = directoryShortfall;
    image.warnings.push(`PE optional header declares ${numberOfRvaAndSizes} data directories but SizeOfOptionalHeader ${sizeOptional} only holds ${dirCount}; ${directoryShortfall} declared entries are missing and the missing range is truncation, not a format fact`);
  }

  image.addSegment({ name: 'headers', address: imageBase, size: BigInt(sizeOfHeaders), fileOffset: 0n, fileSize: BigInt(Math.min(sizeOfHeaders, bytes.length)), perms: { read: true, write: false, execute: false }, source: 'PE-headers' });
  const secBase = opt + sizeOptional;
  if (numberOfSections > 4096 || secBase + numberOfSections * 40 > r.length) throw new Error('PE section table is invalid');
  for (let i = 0; i < numberOfSections; i++) {
    const p = secBase + i * 40;
    // Executable-image section-table names are literal 8-byte fields. The
    // /NNN indirection belongs to COFF object-file section names; using it
    // here can replace an image section's identity with unrelated symbol data.
    const name = r.ascii(p, 8);
    const virtualSize = r.u32(p + 8);
    const virtualAddress = r.u32(p + 12);
    const sizeRaw = r.u32(p + 16);
    const ptrRaw = r.u32(p + 20);
    const flags = r.u32(p + 36);
    const address = imageBase + BigInt(virtualAddress);
    const virtualExtent = BigInt(virtualSize || sizeRaw);
    // Section virtual ranges live inside the 32-bit RVA domain and inside the
    // declared SizeOfImage; BigInt arithmetic would otherwise happily map a
    // section past 2^32 that no PE image can express (#6097). Keep the raw
    // header facts, but do not promote such a section to canonical mapping.
    const startRva = BigInt(virtualAddress);
    const endRva = startRva + virtualExtent;
    const rvaLimit = 1n << 32n;
    const beyondRvaDomain = endRva > rvaLimit;
    const beyondSizeOfImage = endRva > BigInt(sizeOfImage);
    const virtualRangeInvalid = beyondRvaDomain || beyondSizeOfImage;
    const rawMapping = windowsImageSectionRawMapping(ptrRaw, { sectionAlignment });
    const rawSize = windowsImageSectionRawSize(sizeRaw, fileAlignment, sectionAlignment);
    const availableFileBytes = rawMapping.fileBacked ? Math.max(0, bytes.length - rawMapping.effectiveFileOffset) : 0;
    const rawAvailableNumber = rawMapping.fileBacked ? Math.min(rawSize.effectiveRawSize, availableFileBytes) : 0;
    const rawAvailable = BigInt(rawAvailableNumber);
    const mappedFileSize = rawAvailable < virtualExtent ? rawAvailable : virtualExtent;
    const perms = { read: !!(flags & 0x40000000), write: !!(flags & 0x80000000), execute: !!(flags & 0x20000000) };
    image.metadata.peSectionRawMappings.push({
      sectionIndex: i + 1,
      name,
      declaredFileOffset: ptrRaw,
      effectiveFileOffset: rawMapping.effectiveFileOffset,
      sizeOfRawData: sizeRaw,
      fileBacked: rawMapping.fileBacked,
      roundedDown: rawMapping.roundedDown,
      policy: rawMapping.policy || 'windows-image-loader-0x200-round-down',
    });
    image.metadata.peSectionRawSizes.push({
      sectionIndex: i + 1,
      name,
      declaredRawSize: sizeRaw,
      effectiveRawSize: rawSize.effectiveRawSize,
      fileAlignment,
      alignmentValid: rawSize.alignmentValid,
      roundedUp: rawSize.roundedUp,
      clippedToFile: rawMapping.fileBacked && rawAvailableNumber < rawSize.effectiveRawSize,
      clippedToVirtual: BigInt(rawSize.effectiveRawSize) > virtualExtent,
      policy: rawSize.alignmentValid ? 'windows-image-loader-file-alignment-round-up' : 'declared-size-fallback-invalid-file-alignment',
    });
    if (rawMapping.roundedDown) {
      image.warnings.push(`PE section ${name || `#${i + 1}`} PointerToRawData 0x${ptrRaw.toString(16)} is nonconforming; Windows image-loader mapping uses 0x${rawMapping.effectiveFileOffset.toString(16)}`);
    }
    if (!rawSize.alignmentValid && sizeRaw > 0) {
      image.warnings.push(`PE section ${name || `#${i + 1}`} has invalid FileAlignment 0x${fileAlignment.toString(16)}; raw-size mapping falls back to declared SizeOfRawData`);
    } else if (rawSize.roundedUp) {
      image.warnings.push(`PE section ${name || `#${i + 1}`} SizeOfRawData 0x${sizeRaw.toString(16)} is nonconforming; Windows image-loader mapping uses 0x${rawSize.effectiveRawSize.toString(16)} bytes`);
    }
    if (rawMapping.fileBacked && rawAvailableNumber < rawSize.effectiveRawSize) {
      image.warnings.push(`PE section ${name || `#${i + 1}`} raw mapping is truncated: 0x${rawAvailableNumber.toString(16)} of 0x${rawSize.effectiveRawSize.toString(16)} bytes are available`);
    }
    const effectiveFileOffset = BigInt(rawMapping.effectiveFileOffset);
    if (virtualRangeInvalid) {
      const reason = beyondRvaDomain ? 'pe:section-virtual-range-rva-overflow' : 'pe:section-virtual-range-exceeds-size-of-image';
      image.metadata.peMetadata ||= { complete: true, reasons: [] };
      image.metadata.peMetadata.complete = false;
      if (!image.metadata.peMetadata.reasons.includes(reason)) image.metadata.peMetadata.reasons.push(reason);
      image.metadata.peSectionsWithInvalidVirtualRange ||= [];
      image.metadata.peSectionsWithInvalidVirtualRange.push({
        sectionIndex: i + 1, name, virtualAddress, virtualSize, sizeOfImage,
        endRva: endRva.toString(), beyondRvaDomain, beyondSizeOfImage,
      });
      image.warnings.push(`PE section ${name || `#${i + 1}`} virtual range RVA 0x${virtualAddress.toString(16)}+0x${virtualExtent.toString(16)} exceeds ${beyondRvaDomain ? 'the 32-bit RVA domain' : `SizeOfImage 0x${sizeOfImage.toString(16)}`}; excluded from canonical mapping`);
      continue;
    }
    image.addSegment({ name, address, size: virtualExtent, fileOffset: effectiveFileOffset, fileSize: mappedFileSize, perms, flags, source: 'PE-section' });
    image.addSection({ name, address, size: virtualExtent, fileOffset: effectiveFileOffset, fileSize: mappedFileSize, perms, flags, type: null, index: i + 1, source: 'PE-section' });
  }

  if (entryRva) seedValidatedEntrypoint(image, entryRva, sizeOfImage, machine);
  const metadataBudget = createPEMetadataBudget(image, { signal: options.signal, limits: options.metadataLimits });
  if (directoryShortfall > 0) metadataBudget.partial('optional-header:data-directories-truncated');
  parseCoffSymbols(r, ptrSymbols, numberOfSymbols, image, metadataBudget);
  parseImports(r, directory(directories, IMAGE_DIRECTORY_ENTRY_IMPORT), image, metadataBudget);
  parseExports(r, directory(directories, IMAGE_DIRECTORY_ENTRY_EXPORT), image, metadataBudget);
  parseExceptionFunctions(r, directory(directories, IMAGE_DIRECTORY_ENTRY_EXCEPTION), image, machine, metadataBudget);
  parseBaseRelocations(r, directory(directories, IMAGE_DIRECTORY_ENTRY_BASERELOC), image, machine, metadataBudget);
  parseDelayImports(r, directory(directories, IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT), image, metadataBudget);
  parseTlsDirectory(r, directory(directories, IMAGE_DIRECTORY_ENTRY_TLS), image, metadataBudget);
  parseLoadConfig(r, directory(directories, IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG), image, metadataBudget);
  reconcileExportFunctionEvidence(image);
  return image.finalize();
}
