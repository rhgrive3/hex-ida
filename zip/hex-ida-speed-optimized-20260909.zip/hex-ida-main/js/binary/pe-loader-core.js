import { functionSeed } from './model.js';

export const PE_METADATA_LIMITS = Object.freeze({
  inputBytes: 64 * 1024 * 1024,
  records: 250_000,
  objects: 500_000,
  stringBytes: 16 * 1024 * 1024,
  operations: 2_000_000,
  estimatedHeapBytes: 96 * 1024 * 1024,
  wallClockMs: 5_000,
});

function markPEPartial(image, reason, warning = null) {
  image.metadata ||= {};
  image.metadata.peMetadata ||= { complete: true, reasons: [] };
  image.metadata.peMetadata.complete = false;
  if (!image.metadata.peMetadata.reasons.includes(reason)) image.metadata.peMetadata.reasons.push(reason);
  if (warning && !image.warnings.includes(warning)) image.warnings.push(warning);
}

function metadataLimit(value, fallback) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0 ? n : fallback;
}

function resolveMetadataLimits(overrides = {}) {
  const out = {};
  for (const [key, fallback] of Object.entries(PE_METADATA_LIMITS)) {
    out[key] = metadataLimit(overrides[key], fallback);
  }
  return out;
}

export function createPEMetadataBudget(image, options = {}) {
  image.metadata ||= {};
  const limits = resolveMetadataLimits(options.limits || options.metadataLimits || {});
  const signal = options.signal || null;
  const started = Date.now();
  const used = { inputBytes:0, records:0, objects:0, stringBytes:0, operations:0, estimatedHeapBytes:0 };
  const meta = image.metadata.peMetadata ||= { complete:true, reasons:[] };
  meta.limits = { ...limits };
  meta.used = used;
  let nextTimeCheck = 1024;
  // Budget exhaustion is irreversible for this instance, unlike partial metadata.
  let stopped = false;
  const fail = (reason) => { stopped = true; markPEPartial(image, `budget:${reason}`, `PE metadata budget exhausted: ${reason}`); return false; };
  const budget = {
    limits, used, signal,
    get stopped() { return stopped; },
    get remainingStringBytes() { return Math.max(0, limits.stringBytes - used.stringBytes); },
    take(cost = {}, reason = 'metadata') {
      if (stopped) return false;
      if (signal?.aborted) return fail('aborted');
      const nextOps = used.operations + (cost.operations || 0);
      if (nextOps >= nextTimeCheck) {
        nextTimeCheck = nextOps + 1024;
        if (Date.now() - started > limits.wallClockMs) return fail('wall-clock');
      }
      for (const key of ['inputBytes','records','objects','stringBytes','operations','estimatedHeapBytes']) {
        const next = used[key] + (cost[key] || 0);
        if (!Number.isFinite(next) || next < 0 || next > limits[key]) return fail(`${reason}:${key}`);
      }
      for (const key of Object.keys(used)) used[key] += cost[key] || 0;
      return true;
    },
    partial(reason, warning = null) { markPEPartial(image, reason, warning); return false; },
  };
  return budget;
}

function ensureBudget(image, budget) { return budget || createPEMetadataBudget(image); }

export function mappedFileRangeForRva(image, rva) {
  if (!Number.isInteger(rva) || rva <= 0) return null;
  const address = image.imageBase + BigInt(rva);
  const owners = [...(image.sections || []), ...(image.segments || [])];
  for (const owner of owners) {
    if (!owner || owner.address == null || owner.fileOffset == null || owner.fileSize == null) continue;
    const fileSize = BigInt(owner.fileSize);
    if (fileSize <= 0n || address < owner.address || address >= owner.address + fileSize) continue;
    const delta = address - owner.address;
    const start = BigInt(owner.fileOffset) + delta;
    const end = BigInt(owner.fileOffset) + fileSize;
    if (start > BigInt(Number.MAX_SAFE_INTEGER) || end > BigInt(Number.MAX_SAFE_INTEGER)) return null;
    return { start: Number(start), end: Number(end), owner, address };
  }
  return null;
}

export function mappedFileSpanForRva(image, rva, size) {
  if (!Number.isSafeInteger(size) || size < 0) return null;
  if (size === 0) return mappedFileRangeForRva(image, rva);
  const range = mappedFileRangeForRva(image, rva);
  if (!range || size > range.end - range.start) return null;
  return { ...range, spanEnd: range.start + size };
}

function mappedFileRangeForAddress(image, address) {
  const a = BigInt(address);
  if (a < image.imageBase || a - image.imageBase > 0xffffffffn) return null;
  return mappedFileRangeForRva(image, Number(a - image.imageBase));
}

function mappedCStringAtRva(r, image, rva, budget, label) {
  const range = mappedFileRangeForRva(image, rva);
  if (!range) { budget.partial(`${label}:unmapped-string`, `Ignored ${label} string outside a file-backed mapping`); return ''; }
  const maxByStringBudget = Math.max(1, Math.floor(budget.remainingStringBytes / 2) + 1);
  const max = Math.min(1 << 16, range.end - range.start, maxByStringBudget);
  if (max <= 0) return '';
  // ByteView.cstring() tolerates a missing NUL and returns the whole span, so
  // it would accept unterminated bytes as canonical metadata (#2187).
  const nulAt = r.slice(range.start, max).indexOf(0);
  if (nulAt < 0) {
    budget.partial(`${label}:unterminated-string`, `Ignored ${label} string without a NUL terminator inside its mapped span`);
    return '';
  }
  const value = r.cstring(range.start, max);
  const inputBytes = Math.min(max, value.length + 1);
  if (!budget.take({ inputBytes, stringBytes:value.length*2, operations:1, estimatedHeapBytes:value.length*2+32 }, `${label}-string`)) return '';
  return value;
}

function mappedCStringAtOffset(r, start, end, budget, label) {
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= end || end > r.length) return '';
  const max = Math.min(1 << 16, end-start, Math.max(1, Math.floor(budget.remainingStringBytes/2)+1));
  // Same contract as mappedCStringAtRva: no NUL inside the span -> not a string.
  const nulAt = r.slice(start, max).indexOf(0);
  if (nulAt < 0) {
    budget.partial(`${label}:unterminated-string`, `Ignored ${label} string without a NUL terminator inside its span`);
    return '';
  }
  const value = r.cstring(start,max);
  if (!budget.take({ inputBytes:Math.min(max,value.length+1), stringBytes:value.length*2, operations:1, estimatedHeapBytes:value.length*2+32 }, `${label}-string`)) return '';
  return value;
}

function markImportPartial(image, message) {
  image.metadata.peImports ||= { complete: true, truncatedTables: 0 };
  image.metadata.peImports.complete = false;
  image.metadata.peImports.truncatedTables++;
  markPEPartial(image, 'imports-partial', message);
}

export function parseImports(r, dir, image, sharedBudget = null) {
  if (!dir || !dir.rva || !dir.size) return;
  const budget = ensureBudget(image, sharedBudget);
  image.metadata.peImports ||= { complete: true, truncatedTables: 0 };
  const dirRange = mappedFileSpanForRva(image, dir.rva, dir.size);
  if (!dirRange) { markImportPartial(image, 'PE import directory crosses a mapped RVA/file boundary'); return; }
  let off = dirRange.start;
  const end = dirRange.spanEnd;
  const ptrSize = image.bits === 64 ? 8 : 4;
  let terminatedDescriptors = false;
  for (let guard = 0; guard < 65536 && off + 20 <= end; guard++, off += 20) {
    if (!budget.take({inputBytes:20,records:1,operations:1,estimatedHeapBytes:32},'import-descriptor')) break;
    const originalFirstThunk = r.u32(off), timeDateStamp = r.u32(off+4), forwarderChain = r.u32(off+8);
    const nameRva = r.u32(off+12), firstThunk = r.u32(off+16);
    if (!(originalFirstThunk || timeDateStamp || forwarderChain || nameRva || firstThunk)) { terminatedDescriptors=true; break; }
    const library = mappedCStringAtRva(r,image,nameRva,budget,'PE import library');
    if (library) image.libraries.push(library);
    const thunkRva = originalFirstThunk || firstThunk;
    const thunkRange = mappedFileRangeForRva(image, thunkRva), iatRange = mappedFileRangeForRva(image, firstThunk);
    if (!thunkRange || !iatRange) { markImportPartial(image, `PE import thunk table for ${library||'<unknown>'} is not fully file-backed`); continue; }
    let terminated=false;
    for (let index=0; index<100000; index++) {
      const thunkOff=thunkRange.start+index*ptrSize, iatOff=iatRange.start+index*ptrSize;
      if (thunkOff+ptrSize>thunkRange.end || iatOff+ptrSize>iatRange.end || thunkOff+ptrSize>r.length || iatOff+ptrSize>r.length) break;
      if (!budget.take({inputBytes:ptrSize*2,records:1,objects:1,operations:2,estimatedHeapBytes:192},'import-thunk')) break;
      const raw=image.bits===64?r.u64(thunkOff):BigInt(r.u32(thunkOff));
      if(raw===0n){terminated=true;break;}
      const ordinalMask=image.bits===64?0x8000000000000000n:0x80000000n;
      let name=null,ordinal=null,hint=null;
      if(raw&ordinalMask) ordinal=Number(raw&0xffffn);
      else {
        const ibnRaw=raw&(image.bits===64?0x7fffffffffffffffn:0x7fffffffn);
        if(ibnRaw>0xffffffffn){markImportPartial(image,`Ignored PE import thunk with out-of-range name RVA for ${library||'<unknown>'}`);continue;}
        const ibnRva=Number(ibnRaw), ibnRange=mappedFileRangeForRva(image,ibnRva);
        if(ibnRange && ibnRange.start+2<ibnRange.end){hint=r.u16(ibnRange.start);name=mappedCStringAtOffset(r,ibnRange.start+2,ibnRange.end,budget,'PE import name');}
        if(!name){markImportPartial(image,`Ignored malformed PE import thunk for ${library||'<unknown>'}`);continue;}
      }
      const iatAddress=image.imageBase+BigInt(firstThunk+index*ptrSize);
      image.imports.push({name:name||`#${ordinal}`,library,ordinal,hint,source:'PE-import',sites:[{address:iatAddress,offset:BigInt(iatOff),kind:'iat'}]});
    }
    if(!terminated)markImportPartial(image,`PE import thunk table for ${library||'<unknown>'} reached its mapped file boundary without a NUL terminator`);
  }
  if (!terminatedDescriptors && off + 20 > end) markImportPartial(image,'PE import descriptor table reached its mapped boundary without a zero descriptor');
}

function executableRvaRange(image, beginRva, size = 1) {
  if (!Number.isInteger(beginRva) || beginRva <= 0 || !Number.isInteger(size) || size <= 0) return false;
  const begin = image.imageBase + BigInt(beginRva), end = begin + BigInt(size), sec = image.sectionAt(begin);
  return !!(sec?.perms?.execute && end <= sec.address + sec.size);
}

function exceptionDirectoryMetadata(image, kind) {
  const current = image.metadata.exceptionDirectory;
  if (!current || current.kind !== kind) image.metadata.exceptionDirectory = { count:0, kind, fragments:[], invalidRecords:0 };
  else {
    current.fragments ||= [];
    current.invalidRecords ||= 0;
  }
  return image.metadata.exceptionDirectory;
}

function recordExceptionFragment(image, kind, beginRva, sizeBytes, details = {}) {
  const meta = exceptionDirectoryMetadata(image, kind);
  meta.fragments.push({
    kind:'unwind-fragment',
    address:image.imageBase + BigInt(beginRva),
    size:BigInt(sizeBytes),
    ...details,
  });
}

function invalidExceptionRecord(image, kind, budget, reason, warning) {
  const meta = exceptionDirectoryMetadata(image, kind);
  meta.invalidRecords++;
  budget.partial(`exception:${reason}`, warning);
  return null;
}

function parseX64UnwindDescriptor(r, image, runtimeFunction, budget, seen = new Set(), depth = 0) {
  const kind = 'x64-pdata';
  const { begin, finish, unwind } = runtimeFunction;
  if (!unwind || depth > 32 || seen.has(unwind)) {
    return invalidExceptionRecord(image, kind, budget, depth > 32 ? 'x64-chain-depth' : 'x64-chain-cycle', `Ignored cyclic/excessive x64 chained unwind info at RVA 0x${unwind.toString(16)}`);
  }
  const range = mappedFileRangeForRva(image, unwind);
  if (!range || range.start + 4 > range.end || range.start + 4 > r.length) {
    return invalidExceptionRecord(image, kind, budget, 'x64-unwind-span', `Ignored x64 exception range with unmapped/truncated UNWIND_INFO RVA 0x${unwind.toString(16)}`);
  }
  if (!budget.take({ inputBytes:4, operations:1, estimatedHeapBytes:32 }, 'x64-unwind-header')) return null;
  const first = r.u8(range.start), version = first & 7, flags = first >>> 3, count = r.u8(range.start + 2);
  if (version !== 1 || (flags & ~7) !== 0 || ((flags & 4) && (flags & 3))) {
    return invalidExceptionRecord(image, kind, budget, 'x64-unwind-header', `Ignored unsupported/invalid x64 UNWIND_INFO version/flags at RVA 0x${unwind.toString(16)}`);
  }
  const tail = range.start + 4 + (((count + 1) & ~1) * 2);
  if (tail > range.end || tail > r.length) {
    return invalidExceptionRecord(image, kind, budget, 'x64-unwind-codes', `Ignored truncated x64 unwind-code array at RVA 0x${unwind.toString(16)}`);
  }
  if (flags & 4) {
    if (tail + 12 > range.end || tail + 12 > r.length) {
      return invalidExceptionRecord(image, kind, budget, 'x64-chain-tail', `Ignored truncated x64 chained RUNTIME_FUNCTION at RVA 0x${unwind.toString(16)}`);
    }
    if (!budget.take({ inputBytes:12, records:1, operations:2, estimatedHeapBytes:96 }, 'x64-chain-record')) return null;
    const chained = { begin:r.u32(tail), finish:r.u32(tail + 4), unwind:r.u32(tail + 8) };
    if (!chained.begin || chained.finish <= chained.begin || !executableRvaRange(image, chained.begin, chained.finish - chained.begin)) {
      return invalidExceptionRecord(image, kind, budget, 'x64-chain-range', `Ignored invalid x64 chained primary range RVA 0x${chained.begin.toString(16)}..0x${chained.finish.toString(16)}`);
    }
    const nextSeen = new Set(seen); nextSeen.add(unwind);
    const nested = parseX64UnwindDescriptor(r, image, chained, budget, nextSeen, depth + 1);
    if (!nested) return null;
    return { primary:nested.primary, fragments:[runtimeFunction, ...nested.fragments] };
  }
  if (flags & 3) {
    if (tail + 4 > range.end || tail + 4 > r.length) {
      return invalidExceptionRecord(image, kind, budget, 'x64-handler-tail', `Ignored truncated x64 handler RVA at unwind RVA 0x${unwind.toString(16)}`);
    }
    const handlerRva = r.u32(tail);
    // The handler field is the address of the language-specific exception
    // handler *routine*: it must live in an executable, file-backed mapping,
    // not merely any mapped data section. Accepting data-section RVAs let
    // malformed UNWIND_INFO mint 0.999-confidence function seeds (#5466).
    if (!handlerRva || !mappedFileRangeForRva(image, handlerRva) || !executableRvaRange(image, handlerRva, 1)) {
      return invalidExceptionRecord(image, kind, budget, 'x64-handler-not-executable', `Ignored x64 UNWIND_INFO whose handler RVA 0x${handlerRva.toString(16)} is not an executable file-backed routine`);
    }
  }
  return { primary:{ begin, finish, unwind }, fragments:[] };
}

function parseArm64XdataDescriptor(r, image, begin, xdataRva, budget) {
  const kind = 'arm64-pdata';
  const first = mappedFileSpanForRva(image, xdataRva, 4);
  if (!first || first.start + 4 > r.length) return invalidExceptionRecord(image, kind, budget, 'arm64-xdata-header', `Ignored ARM64 exception entry with unmapped/truncated .xdata RVA 0x${xdataRva.toString(16)}`);
  if (!budget.take({ inputBytes:4, operations:1, estimatedHeapBytes:32 }, 'arm64-xdata-header')) return null;
  const header = r.u32(first.start), functionLength = header & 0x3ffff, version = (header >>> 18) & 3;
  const hasHandler = !!(header & (1 << 20)), packedEpilog = !!(header & (1 << 21));
  let epilogCount = (header >>> 22) & 0x1f, codeWords = (header >>> 27) & 0x1f, headerBytes = 4;
  if (version !== 0 || functionLength === 0) return invalidExceptionRecord(image, kind, budget, 'arm64-xdata-fields', `Ignored invalid ARM64 .xdata header at RVA 0x${xdataRva.toString(16)}`);
  if (epilogCount === 0 && codeWords === 0) {
    const ext = mappedFileSpanForRva(image, xdataRva, 8);
    if (!ext || ext.start + 8 > r.length) return invalidExceptionRecord(image, kind, budget, 'arm64-xdata-extension', `Ignored truncated ARM64 .xdata extension at RVA 0x${xdataRva.toString(16)}`);
    const word = r.u32(ext.start + 4); epilogCount = word & 0xffff; codeWords = (word >>> 16) & 0xff; headerBytes = 8;
    if (!budget.take({ inputBytes:4, operations:1 }, 'arm64-xdata-extension')) return null;
  }
  const recordBytes = headerBytes + (packedEpilog ? 0 : epilogCount * 4) + codeWords * 4 + (hasHandler ? 4 : 0);
  if (!Number.isSafeInteger(recordBytes) || !mappedFileSpanForRva(image, xdataRva, recordBytes)) return invalidExceptionRecord(image, kind, budget, 'arm64-xdata-span', `Ignored ARM64 .xdata record that crosses its file-backed mapping at RVA 0x${xdataRva.toString(16)}`);
  const bytes = functionLength * 4;
  if (!executableRvaRange(image, begin, bytes)) return invalidExceptionRecord(image, kind, budget, 'arm64-xdata-range', `Ignored ARM64 .xdata range outside executable mapping at RVA 0x${begin.toString(16)}`);
  return { size:bytes, xdataRva, version, hasHandler, packedEpilog, epilogCount, codeWords };
}

export function parseExceptionFunctions(r, dir, image, machine, sharedBudget = null) {
  if(!dir||!dir.rva||!dir.size)return; const budget=ensureBudget(image,sharedBudget);
  const span=mappedFileSpanForRva(image,dir.rva,dir.size); if(!span){budget.partial('exception:directory-span','PE exception directory crosses a mapped boundary');return;}
  const off=span.start,end=span.spanEnd;
  if(machine===0x8664){
    const meta=exceptionDirectoryMetadata(image,'x64-pdata'); let previousBegin=null,previousEnd=null,pendingZeroRecords=0;
    for(let p=off;p+12<=end;p+=12){
      if(!budget.take({inputBytes:12,records:1,objects:1,operations:2,estimatedHeapBytes:128},'exception-record'))break;
      const begin=r.u32(p),finish=r.u32(p+4),unwind=r.u32(p+8);
      // The directory size bounds this fixed-record array. Zero-filled slots
      // are tolerated as padding, but never terminate the scan: a later
      // nonzero record must remain visible. If one follows, account for the
      // zero slot as an internal malformed record below.
      if (!begin && !finish && !unwind) { pendingZeroRecords++; continue; }
      if (pendingZeroRecords) {
        meta.invalidRecords += pendingZeroRecords;
        budget.partial('exception:internal-zero-record', `Ignored ${pendingZeroRecords} internal zero-filled x64 exception record(s) before a later record`);
        pendingZeroRecords = 0;
      }
      const ordered=previousBegin==null||(begin>previousBegin&&begin>=previousEnd);
      if(!begin||finish<=begin||!ordered||!executableRvaRange(image,begin,finish-begin)){if(begin||finish)image.warnings.push(`Ignored ${!ordered?'overlapping/out-of-order':'invalid/unmapped'} x64 exception range RVA 0x${begin.toString(16)}..0x${finish.toString(16)}`);meta.invalidRecords++;continue;}
      const decoded=parseX64UnwindDescriptor(r,image,{begin,finish,unwind},budget);
      previousBegin=begin;previousEnd=finish;
      if(!decoded)continue;
      if(decoded.fragments.length){
        for(const fragment of decoded.fragments)recordExceptionFragment(image,'x64-pdata',fragment.begin,fragment.finish-fragment.begin,{encoding:'chaininfo',unwindRva:fragment.unwind,primaryAddress:image.imageBase+BigInt(decoded.primary.begin)});
      }
      const primary=decoded.primary;
      if(primary&&executableRvaRange(image,primary.begin,primary.finish-primary.begin))image.functions.push(functionSeed(image.imageBase+BigInt(primary.begin),{size:BigInt(primary.finish-primary.begin),source:'exception',confidence:0.999}));
      meta.count++;
    }
  }else if(machine===0xaa64||machine===0xa641){
    const meta=exceptionDirectoryMetadata(image,'arm64-pdata'); let previousBegin=null,previousEnd=null,pendingZeroRecords=0;
    for(let p=off;p+8<=end;p+=8){
      if(!budget.take({inputBytes:8,records:1,objects:1,operations:2,estimatedHeapBytes:128},'exception-record'))break;
      const begin=r.u32(p),unwindData=r.u32(p+4);
      // Keep scanning the size-bounded array after zero-filled padding slots;
      // a later nonzero ARM64 record must not be hidden by an early zero.
      if (!begin && !unwindData) { pendingZeroRecords++; continue; }
      if (pendingZeroRecords) {
        meta.invalidRecords += pendingZeroRecords;
        budget.partial('exception:internal-zero-record', `Ignored ${pendingZeroRecords} internal zero-filled ARM64 exception record(s) before a later record`);
        pendingZeroRecords = 0;
      }
      if(!begin||(previousBegin!=null&&begin<=previousBegin)||!executableRvaRange(image,begin,1)){if(begin)image.warnings.push(`Ignored ARM64 exception entry outside executable order/range at RVA 0x${begin.toString(16)}`);meta.invalidRecords++;continue;}
      // AArch64 instructions are fixed 4-byte units: an exception range that
      // does not start on an instruction boundary cannot describe a real
      // function start, so it must not mint a high-confidence seed (#5667).
      if(begin%4!==0){invalidExceptionRecord(image,'arm64-pdata',budget,'arm64-pdata-alignment',`Ignored ARM64 exception entry at unaligned RVA 0x${begin.toString(16)} (AArch64 instructions are 4-byte aligned)`);previousBegin=begin;continue;}
      const flag=unwindData&3; let descriptor=null;
      if(flag===1||flag===2){const functionLength=(unwindData>>>2)&0x7ff;if(!functionLength){invalidExceptionRecord(image,'arm64-pdata',budget,'arm64-packed-length',`Ignored zero-length ARM64 packed unwind entry at RVA 0x${begin.toString(16)}`);previousBegin=begin;continue;}
        // Packed unwind encodes RegI as the count of saved nonvolatile integer
        // registers x19-x28; only 10 such registers exist, so values 11-15
        // cannot describe a valid function prologue (#5673).
        const packedRegI=(unwindData>>>16)&0xf;if(packedRegI>10){invalidExceptionRecord(image,'arm64-pdata',budget,'arm64-packed-registers',`Ignored ARM64 packed unwind entry with invalid RegI ${packedRegI} (x19-x28 hold at most 10 registers) at RVA 0x${begin.toString(16)}`);previousBegin=begin;continue;}
        const bytes=functionLength*4;if((previousEnd!=null&&begin<previousEnd)||!executableRvaRange(image,begin,bytes)){image.warnings.push(`Ignored overlapping/unmapped ARM64 exception range at RVA 0x${begin.toString(16)}`);meta.invalidRecords++;previousBegin=begin;continue;}descriptor={size:bytes,fragment:flag===2,encoding:flag===2?'packed-fragment':'packed'};}
      else if(flag===0){descriptor=parseArm64XdataDescriptor(r,image,begin,unwindData>>>0,budget);}
      else{invalidExceptionRecord(image,'arm64-pdata',budget,'arm64-reserved-flag',`Ignored reserved ARM64 packed unwind flag at RVA 0x${begin.toString(16)}`);previousBegin=begin;continue;}
      if(!descriptor){previousBegin=begin;continue;}
      if(previousEnd!=null&&begin<previousEnd){image.warnings.push(`Ignored overlapping ARM64 exception range at RVA 0x${begin.toString(16)}`);meta.invalidRecords++;previousBegin=begin;continue;}
      if(descriptor.fragment)recordExceptionFragment(image,'arm64-pdata',begin,descriptor.size,{encoding:descriptor.encoding||'xdata-fragment',xdataRva:descriptor.xdataRva??null});
      else image.functions.push(functionSeed(image.imageBase+BigInt(begin),{size:BigInt(descriptor.size),source:'exception',confidence:0.995}));
      meta.count++;previousBegin=begin;previousEnd=begin+descriptor.size;
    }
  }
}

function allowedBaseRelocationTypes(machine) {
  if (machine === 0x014c) return new Set([1, 2, 3, 4]);
  if (machine === 0x8664) return new Set([1, 2, 3, 4, 10]);
  if (machine === 0x01c0 || machine === 0x01c4) return new Set([3, 5, 7]);
  if (machine === 0xaa64 || machine === 0xa641) return new Set([4, 10]);
  return new Set([1, 2, 3, 4, 5, 6, 7, 8, 10]);
}
function mappedBaseRelocationTarget(image, rva) {
  if (!Number.isSafeInteger(rva) || rva < 0 || rva > 0xffffffff) return null;
  const sizeOfImage = image.metadata?.sizeOfImage;
  if (Number.isSafeInteger(sizeOfImage) && sizeOfImage >= 0 && rva >= sizeOfImage) return null;
  const address = image.imageBase + BigInt(rva);
  const owners = [...(image.sections || []), ...(image.segments || [])];
  for (const owner of owners) {
    if (!owner || typeof owner.address !== 'bigint' || typeof owner.size !== 'bigint' || owner.size <= 0n) continue;
    if (address >= owner.address && address < owner.address + owner.size) return address;
  }
  return null;
}
export function parseBaseRelocations(r, dir, image, machine = null, sharedBudget = null) {
  if(!dir||!dir.rva||dir.size===0)return; const budget=ensureBudget(image,sharedBudget);
  if(dir.size<8){budget.partial('relocations:malformed-block','Malformed PE base-relocation block: directory is shorter than a block header');return;}
  if((dir.size&3)!==0){budget.partial('relocations:malformed-block','Malformed PE base-relocation block: directory size is not 4-byte aligned');return;}
  if((dir.rva&3)!==0){budget.partial('relocations:malformed-block',`Malformed PE base-relocation block at unaligned RVA 0x${dir.rva.toString(16)}`);return;}
  const span=mappedFileSpanForRva(image,dir.rva,dir.size);if(!span){budget.partial('relocations:directory-span','PE base-relocation directory crosses a mapped boundary');return;}
  let off=span.start;const end=span.spanEnd,allowed=allowedBaseRelocationTypes(machine);
  if((off&3)!==0){budget.partial('relocations:malformed-block',`Malformed PE base-relocation block at file offset 0x${off.toString(16)}`);return;}
  while(off+8<=end){
    if((off&3)!==0){budget.partial('relocations:malformed-block',`Malformed PE base-relocation block at file offset 0x${off.toString(16)}`);break;}
    if(!budget.take({inputBytes:8,records:1,operations:1,estimatedHeapBytes:32},'relocation-block'))break;
    const pageRva=r.u32(off),blockSize=r.u32(off+4);if(blockSize<8||(blockSize&1)!==0||(blockSize&3)!==0||off+blockSize>end){budget.partial('relocations:malformed-block',`Malformed PE base-relocation block at file offset 0x${off.toString(16)}`);break;}
    const count=(blockSize-8)/2;
    for(let i=0;i<count;i++){
      if(!budget.take({inputBytes:2,records:1,objects:1,operations:1,estimatedHeapBytes:112},'relocation-entry'))break;
      const raw=r.u16(off+8+i*2),type=raw>>>12,within=raw&0xfff;if(!type)continue;if(!allowed.has(type)){image.warnings.push(`Ignored reserved/unsupported PE base relocation type ${type} at RVA 0x${(pageRva+within).toString(16)}`);continue;}
      let addend=null;
      if(type===4){
        if(i+1>=count){budget.partial('relocations:highadj-payload',`Malformed PE HIGHADJ base relocation without its second adjustment slot at RVA 0x${(pageRva+within).toString(16)}`);break;}
        // HIGHADJ occupies two 16-bit slots. Preserve the previous conservative
        // budget charge for the payload slot even though it is not a record.
        if(!budget.take({inputBytes:2,records:1,objects:1,operations:1,estimatedHeapBytes:112},'relocation-entry'))break;
        addend=BigInt(r.i16(off+8+(i+1)*2));
        i++;
      }
      const targetRva=pageRva+within,address=mappedBaseRelocationTarget(image,targetRva);
      if(address===null){budget.partial('relocations:unmapped-target',`Ignored PE base relocation target outside loaded image at RVA 0x${targetRva.toString(16)}`);continue;}
      image.relocations.push({address,fileOffset:image.addressToOffset(address),type,symbol:null,addend,section:null,source:'PE-base-reloc'});
    }
    off+=blockSize;
  }
  if(off<end&&off+8>end)budget.partial('relocations:malformed-block',`Malformed PE base-relocation block at file offset 0x${off.toString(16)}: ${end-off} trailing byte(s)`);
}

export function parseCoffSymbols(r, ptr, count, image, sharedBudget = null) {
  if(!ptr||!count)return;const budget=ensureBudget(image,sharedBudget);const tableBytes=count*18;
  if(!Number.isSafeInteger(tableBytes)||ptr+tableBytes>r.length){budget.partial('coff:symbol-table-span','PE COFF symbol table exceeds the input');return;}
  const strBase=ptr+tableBytes;if(strBase+4>r.length){budget.partial('coff:string-table-header','PE COFF string table header is missing');return;}
  const strSize=r.u32(strBase),strEnd=Math.min(r.length,strBase+Math.max(4,strSize));if(strBase+strSize>r.length)budget.partial('coff:string-table-span','PE COFF string table is truncated');
  let i=0;
  while(i<count){
    if(!budget.take({inputBytes:18,records:1,objects:2,operations:2,estimatedHeapBytes:256},'coff-symbol-record'))break;
    const p=ptr+i*18;let name;
    if(r.u32(p)===0){const noff=r.u32(p+4);name=noff>=4&&noff<strSize&&strBase+noff<strEnd?mappedCStringAtOffset(r,strBase+noff,strEnd,budget,'COFF symbol'):'';}else{name=r.ascii(p,8);if(name&&!budget.take({stringBytes:name.length*2,estimatedHeapBytes:name.length*2+32},'coff-inline-name'))name='';}
    const value=r.u32(p+8),secNo=r.i16(p+12),type=r.u16(p+14),storage=r.u8(p+16),aux=r.u8(p+17);const sec=image.sections.find((s)=>s.index===secNo);const address=sec?sec.address+BigInt(value):0n;
    if(name){const derivedFunction=!!(type&0x20),valueInSection=!!(sec&&sec.size!=null&&BigInt(value)<BigInt(sec.size)),executable=!!(valueInSection&&sec.perms?.execute),executableExternal=!!(executable&&storage===2);image.symbols.push({name,address,size:null,kind:derivedFunction?'function':'symbol',binding:storage===2?'global':'local',defined:secNo>0,sectionIndex:secNo,source:'COFF'});if(derivedFunction&&executable&&address)image.functions.push(functionSeed(address,{name,source:'symbol',confidence:0.98,exactFunctionStart:true,functionStartEvidence:'COFF derived function type'}));else if(executableExternal&&address)image.functions.push(functionSeed(address,{name,source:'symbol-heuristic',confidence:0.55}));}
    if(aux>count-i-1){budget.partial('coff:aux-overrun','PE COFF auxiliary symbol records exceed declared symbol count');break;}i+=1+aux;
  }
}

export function directory(dirs, index) { return dirs[index] || { rva: 0, size: 0 }; }
function rvaToOffset(image, rva) {
  const o = image.addressToOffset(image.imageBase + BigInt(rva));
  return o == null || o > BigInt(Number.MAX_SAFE_INTEGER) ? null : Number(o);
}
export function peMachineName(m) {
  return ({ 0x014c: 'x86', 0x8664: 'x86_64', 0x01c0: 'arm', 0x01c4: 'armv7', 0xaa64: 'arm64', 0xa641: 'arm64ec', 0x5032: 'riscv32', 0x5064: 'riscv64' })[m] || `machine-${m.toString(16)}`;
}

export function resolveCoffSectionName(r, inlineName, ptrSymbols, count) {
  const raw = String(inlineName || '');
  const m = /^\/(\d+)$/.exec(raw);
  if (!m) return raw;
  if (!ptrSymbols || !Number.isInteger(count) || count < 0) return raw;
  const stringBase = ptrSymbols + count * 18;
  if (!Number.isSafeInteger(stringBase) || stringBase < 0 || stringBase + 4 > r.length) return raw;
  const stringSize = r.u32(stringBase);
  const offset = Number(m[1]);
  if (!Number.isSafeInteger(offset) || offset < 4 || offset >= stringSize || stringBase + offset >= r.length) return raw;
  const start = stringBase + offset;
  const max = Math.min(stringSize - offset, r.length - start);
  if (max <= 0 || r.slice(start, max).indexOf(0) < 0) return raw;
  return r.cstring(start, max) || raw;
}

function rvaFromDelayField(value, attrs, image) {
  if (!value) return 0;
  if (attrs & 1) return value >>> 0;
  const va = BigInt(value >>> 0), base = image.imageBase;
  if (va < base || va - base > 0xffffffffn) return 0;
  return Number(va - base);
}

export function parseDelayImports(r, dir, image, sharedBudget = null) {
  if(!dir||!dir.rva||dir.size<32)return;const budget=ensureBudget(image,sharedBudget);const dirRange=mappedFileSpanForRva(image,dir.rva,dir.size);if(!dirRange){budget.partial('delay-imports:directory-span','PE delay-import directory crosses a mapped boundary');return;}
  let off=dirRange.start;const end=dirRange.spanEnd,ptrSize=image.bits===64?8:4;
  for(let guard=0;guard<65536&&off+32<=end;guard++,off+=32){
    if(!budget.take({inputBytes:32,records:1,operations:1,estimatedHeapBytes:32},'delay-import-descriptor'))break;
    const attrs=r.u32(off),nameField=r.u32(off+4),iatField=r.u32(off+12),intField=r.u32(off+16),bound=r.u32(off+20),unload=r.u32(off+24),stamp=r.u32(off+28);if(!(attrs||nameField||iatField||intField||bound||unload||stamp))break;
    const nameRva=rvaFromDelayField(nameField,attrs,image),iatRva=rvaFromDelayField(iatField,attrs,image),intRva=rvaFromDelayField(intField,attrs,image);const library=mappedCStringAtRva(r,image,nameRva,budget,'PE delay import library');
    const iatRange=mappedFileRangeForRva(image,iatRva),thunkRange=mappedFileRangeForRva(image,intRva||iatRva);if(!library||!iatRva||!iatRange||!thunkRange){budget.partial('delay-imports:malformed-descriptor','Ignored malformed PE delay-import descriptor');continue;}image.libraries.push(library);
    let terminated=false;
    for(let index=0;index<100000;index++){
      const thunkOff=thunkRange.start+index*ptrSize,iatOff=iatRange.start+index*ptrSize;if(thunkOff+ptrSize>thunkRange.end||iatOff+ptrSize>iatRange.end||thunkOff+ptrSize>r.length||iatOff+ptrSize>r.length)break;
      if(!budget.take({inputBytes:ptrSize*2,records:1,objects:1,operations:2,estimatedHeapBytes:192},'delay-import-thunk'))break;
      const raw=image.bits===64?r.u64(thunkOff):BigInt(r.u32(thunkOff));if(raw===0n){terminated=true;break;}const ordinalMask=image.bits===64?0x8000000000000000n:0x80000000n;let name=null,ordinal=null,hint=null;
      if(raw&ordinalMask)ordinal=Number(raw&0xffffn);else{let ibnRva;if(attrs&1){const masked=raw&(image.bits===64?0x7fffffffffffffffn:0x7fffffffn);if(masked>0xffffffffn)continue;ibnRva=Number(masked);}else{const va=raw&(image.bits===64?0x7fffffffffffffffn:0x7fffffffn);ibnRva=va>=image.imageBase&&va-image.imageBase<=0xffffffffn?Number(va-image.imageBase):0;}const ibnRange=mappedFileRangeForRva(image,ibnRva);if(ibnRange&&ibnRange.start+2<ibnRange.end){hint=r.u16(ibnRange.start);name=mappedCStringAtOffset(r,ibnRange.start+2,ibnRange.end,budget,'PE delay import name');}if(!name){image.warnings.push(`Ignored malformed PE delay-import thunk for ${library||'<unknown>'}`);continue;}}
      const iatAddress=image.imageBase+BigInt(iatRva+index*ptrSize);image.imports.push({name:name||`#${ordinal}`,library,ordinal,hint,source:'PE-delay-import',sites:[{address:iatAddress,offset:BigInt(iatOff),kind:'delay-iat'}]});
    }
    if(!terminated)budget.partial('delay-imports:unterminated-thunk',`PE delay-import thunk table for ${library} reached its mapped boundary`);
  }
}

function readPointer(r, off, bits) { return bits===64?r.u64(off):BigInt(r.u32(off)); }

export function parseTlsDirectory(r, dir, image, sharedBudget = null) {
  const need=image.bits===64?40:24;if(!dir||!dir.rva||dir.size<need)return;const budget=ensureBudget(image,sharedBudget);const hdr=mappedFileSpanForRva(image,dir.rva,need);if(!hdr){budget.partial('tls:directory-span','PE TLS directory header is not fully file-backed');return;}const off=hdr.start,callbacksVa=readPointer(r,off+(image.bits===64?24:12),image.bits),callbacks=[];
  if(callbacksVa){const ptrSize=image.bits===64?8:4,range=mappedFileRangeForAddress(image,callbacksVa);if(!range){budget.partial('tls:callback-table-span','PE TLS callback table is not file-backed');}else{let terminated=false;for(let i=0,p=range.start;i<65536&&p+ptrSize<=range.end;i++,p+=ptrSize){if(!budget.take({inputBytes:ptrSize,records:1,objects:1,operations:1,estimatedHeapBytes:128},'tls-callback'))break;const target=readPointer(r,p,image.bits);if(!target){terminated=true;break;}const sec=image.sectionAt(target);if(!sec?.perms?.execute)continue;if(!mappedFileRangeForAddress(image,target))continue;
    // A callback address that is not on the architecture's instruction
    // boundary cannot be a function entry: mirror seedValidatedEntrypoint()'s
    // alignment contract so crafted tables cannot mint misplaced seeds (#5667).
    const alignment=image.metadata?.machine===0xaa64||image.metadata?.machine===0xa641?4n:image.metadata?.machine===0x01c4?2n:1n;
    if(target%alignment!==0n){budget.partial('tls:callback-target-alignment',`Ignored PE TLS callback target 0x${target.toString(16)} not ${alignment}-byte aligned`);continue;}
    callbacks.push(target);image.functions.push(functionSeed(target,{source:'tls-callback',confidence:0.999}));}if(!terminated)budget.partial('tls:unterminated-callback-table','PE TLS callback table reached its mapped boundary without a zero terminator');}}
  image.metadata.tls={callbacks,callbacksAddress:callbacksVa||null};
}

export function parseLoadConfig(r, dir, image, sharedBudget = null) {
  if(!dir||!dir.rva||dir.size<4)return;const budget=ensureBudget(image,sharedBudget),head=mappedFileSpanForRva(image,dir.rva,4);if(!head){budget.partial('load-config:header-span','PE load-config header is not file-backed');return;}const off=head.start,declared=Math.min(r.u32(off),dir.size);const full=mappedFileSpanForRva(image,dir.rva,declared);if(!full){budget.partial('load-config:directory-span','PE load-config directory crosses a mapped boundary');return;}const is64=image.bits===64,tableOffset=is64?128:80,countOffset=is64?136:84,flagsOffset=is64?144:88,ptrSize=is64?8:4;if(declared<countOffset+ptrSize)return;
  const tableVa=readPointer(r,off+tableOffset,image.bits),count64=readPointer(r,off+countOffset,image.bits),guardFlags=declared>=flagsOffset+4?r.u32(off+flagsOffset):0,extra=(guardFlags>>>28)&0xf,entrySize=4+extra,functions=[];const tableRange=tableVa?mappedFileRangeForAddress(image,tableVa):null;
  if(tableVa&&!tableRange)budget.partial('load-config:guardcf-table-span','PE GuardCF table is not file-backed');
  if(tableRange){const capacity=Math.floor((tableRange.end-tableRange.start)/entrySize);if(count64>BigInt(capacity))budget.partial('load-config:guardcf-count-span','PE GuardCF count exceeds its mapped file-backed table');const count=Number(count64<BigInt(capacity)?count64:BigInt(capacity));for(let i=0;i<count;i++){if(!budget.take({inputBytes:entrySize,records:1,objects:1,operations:1,estimatedHeapBytes:128},'guardcf-function'))break;const p=tableRange.start+i*entrySize,rva=r.u32(p);if(!rva)continue;const address=image.imageBase+BigInt(rva),sec=image.sectionAt(address);if(!sec?.perms?.execute)continue;if(!mappedFileRangeForAddress(image,address))continue;
    // GuardCF targets are function entries: reject addresses that are not on
    // the architecture's instruction boundary (seedValidatedEntrypoint's
    // alignment contract), so crafted tables cannot mint misplaced seeds (#5667).
    const alignment=image.metadata?.machine===0xaa64||image.metadata?.machine===0xa641?4n:image.metadata?.machine===0x01c4?2n:1n;
    if(address%alignment!==0n){budget.partial('load-config:guardcf-target-alignment',`Ignored PE GuardCF target 0x${address.toString(16)} not ${alignment}-byte aligned`);continue;}
    functions.push(address);image.functions.push(functionSeed(address,{source:'guard-cf',confidence:0.995}));}}
  image.metadata.loadConfig={guardFlags,guardCFFunctionTable:tableVa||null,guardCFFunctionCount:count64,guardCFFunctions:functions};
}