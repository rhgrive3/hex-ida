import { DEBUG_PROTOCOL_VERSION, DebugAdapterError, boundedInteger } from './adapter.js';

const MAX_PACKET_BYTES = 1024 * 1024;
const MAX_ARRAY = 65536;
const ALLOWED_TYPES = new Set(['hello','request','response','event','cancel']);
const BLOCKED_METHODS = /^(exec|shell|spawn|system|hostCommand|runCommand)$/i;
export const WIRE_TAG = '__hex_wire_type__';
export const BIGINT_TAG = 'bigint';
export const BYTES_TAG = 'bytes-base64';

function utf8ByteLength(json) {
  if (typeof Buffer !== 'undefined' && typeof Buffer.byteLength === 'function') return Buffer.byteLength(json, 'utf8');
  // Exact UTF-8 length without TextEncoder: surrogate pairs are 4 bytes,
  // unpaired surrogates count as their 3-byte replacement character, so the
  // byte budget means the same thing on every runtime (#5939).
  let bytes = 0;
  for (let i = 0; i < json.length; i += 1) {
    const code = json.charCodeAt(i);
    if (code < 0x80) bytes += 1;
    else if (code < 0x800) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff && json.charCodeAt(i + 1) >= 0xdc00 && json.charCodeAt(i + 1) <= 0xdfff) { bytes += 4; i += 1; }
    else bytes += 3;
  }
  return bytes;
}

function jsonByteSize(value) {
  let json;
  try { json = JSON.stringify(value); }
  catch { throw new DebugAdapterError('malformed-packet', 'remote packet is not serializable'); }
  if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(json).byteLength;
  return utf8ByteLength(json);
}

function bytesToBase64(bytes) {
  if (typeof Buffer !== 'undefined') return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString('base64');
  if (typeof btoa !== 'function') throw new DebugAdapterError('encoding-unavailable', 'base64 encoder is unavailable');
  let binary = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  return btoa(binary);
}

function base64ToBytes(text) {
  try {
    if (typeof Buffer !== 'undefined') {
      const buf = Buffer.from(text, 'base64');
      if (buf.toString('base64') !== String(text)) throw new Error('non-canonical');
      return new Uint8Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
    }
    if (typeof atob !== 'function') throw new Error('decoder unavailable');
    const binary = atob(text);
    if (btoa(binary) !== String(text)) throw new Error('non-canonical');
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  } catch {
    throw new DebugAdapterError('malformed-packet', 'invalid base64 byte payload');
  }
}

function rejectUnknownWireTag(value) {
  if (
    Object.prototype.hasOwnProperty.call(value, WIRE_TAG) &&
    value[WIRE_TAG] !== BIGINT_TAG &&
    value[WIRE_TAG] !== BYTES_TAG
  ) {
    throw new DebugAdapterError('malformed-packet', 'unknown remote wire value type');
  }
}

export function encodeWireValue(value, depth = 0) {
  if (depth > 20) throw new DebugAdapterError('malformed-packet', 'remote packet nesting is too deep');
  if (value == null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new DebugAdapterError('malformed-packet', 'remote packet numbers must be finite');
    return value;
  }
  if (typeof value === 'bigint') return { [WIRE_TAG]: BIGINT_TAG, value: value.toString(10) };
  if (value instanceof Uint8Array) return { [WIRE_TAG]: BYTES_TAG, value: bytesToBase64(value), length: value.byteLength };
  if (ArrayBuffer.isView(value)) {
    return { [WIRE_TAG]: BYTES_TAG, value: bytesToBase64(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)), length: value.byteLength };
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_ARRAY) throw new DebugAdapterError('malformed-packet', 'remote array exceeds limit');
    return value.map((v) => encodeWireValue(v, depth + 1));
  }
  if (typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) throw new DebugAdapterError('malformed-packet', 'remote packet objects must be plain data');
    const keys = Object.keys(value);
    if (keys.length > 1024) throw new DebugAdapterError('malformed-packet', 'remote object has too many fields');
    const out = {};
    for (const key of keys) {
      if (key === WIRE_TAG) throw new DebugAdapterError('malformed-packet', `remote packet contains reserved field: ${WIRE_TAG}`);
      if (key.length > 256) throw new DebugAdapterError('malformed-packet', 'remote field name is too long');
      const field = value[key];
      if (field === undefined || typeof field === 'function' || typeof field === 'symbol') throw new DebugAdapterError('malformed-packet', `remote field is not serializable: ${key}`);
      Object.defineProperty(out, key, { value: encodeWireValue(field, depth + 1), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  throw new DebugAdapterError('malformed-packet', 'remote packet contains an unsupported value');
}

export function decodeWireValue(value, depth = 0) {
  if (depth > 20) throw new DebugAdapterError('malformed-packet', 'remote packet nesting is too deep');
  if (Array.isArray(value)) return value.map((v) => decodeWireValue(v, depth + 1));
  if (!value || typeof value !== 'object') return value;
  rejectUnknownWireTag(value);
  if (value[WIRE_TAG] === BIGINT_TAG) {
    if (
      Object.keys(value).some((k) => ![WIRE_TAG, 'value'].includes(k)) ||
      typeof value.value !== 'string' ||
      // Canonical spelling only: encodeWireValue() emits BigInt.toString(10),
      // so the wire can carry `0`, `1`, `-1` … but never leading zeros (`01`),
      // negative zero (`-0`, which BigInt() would alias onto 0), or padded
      // negatives (`-01`). Accepting those spellings aliased non-canonical
      // packets onto canonical values (#5709).
      !/^(0|-?[1-9]\d*)$/.test(value.value)
    ) {
      throw new DebugAdapterError('malformed-packet', 'invalid bigint wire value');
    }
    const decoded = BigInt(value.value);
    if (decoded.toString(10) !== value.value) {
      throw new DebugAdapterError('malformed-packet', 'invalid bigint wire value');
    }
    return decoded;
  }
  if (value[WIRE_TAG] === BYTES_TAG) {
    if (Object.keys(value).some((k) => ![WIRE_TAG, 'value', 'length'].includes(k)) || typeof value.value !== 'string') {
      throw new DebugAdapterError('malformed-packet', 'invalid byte wire value');
    }
    const out = base64ToBytes(value.value);
    if (!Number.isSafeInteger(value.length) || value.length < 0 || value.length !== out.byteLength || out.byteLength > MAX_PACKET_BYTES) {
      throw new DebugAdapterError('malformed-packet', 'byte payload length mismatch');
    }
    return out;
  }
  const out = {};
  for (const [key, field] of Object.entries(value)) {
    Object.defineProperty(out, key, { value: decodeWireValue(field, depth + 1), enumerable: true, writable: true, configurable: true });
  }
  return out;
}

function validateValue(value, depth = 0) {
  if (depth > 20) throw new DebugAdapterError('malformed-packet', 'remote packet nesting is too deep');
  if (Array.isArray(value)) {
    if (value.length > MAX_ARRAY) throw new DebugAdapterError('malformed-packet', 'remote array exceeds limit');
    for (const v of value) validateValue(v, depth + 1);
    return;
  }
  if (value && typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) throw new DebugAdapterError('malformed-packet', 'remote packet objects must be plain data');
    rejectUnknownWireTag(value);
    const keys = Object.keys(value);
    if (keys.length > 1024) throw new DebugAdapterError('malformed-packet', 'remote object has too many fields');
    for (const key of keys) {
      if (key.length > 256) throw new DebugAdapterError('malformed-packet', 'remote field name is too long');
      validateValue(value[key], depth + 1);
    }
    return;
  }
  if (typeof value === 'string') {
    if (value.length > MAX_PACKET_BYTES) throw new DebugAdapterError('malformed-packet', 'remote string exceeds limit');
    return;
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new DebugAdapterError('malformed-packet', 'remote packet numbers must be finite');
    return;
  }
  if (value == null || typeof value === 'boolean') return;
  throw new DebugAdapterError('malformed-packet', 'remote packet contains a non-wire value');
}
function validateEpoch(packet) {
  if (packet.type === 'hello') return;
  if (!Number.isSafeInteger(packet.epoch) || packet.epoch < 0) throw new DebugAdapterError('malformed-packet', 'packet epoch must be a non-negative safe integer');
}

function validateResponse(packet) {
  if (packet.type !== 'response') return;
  const hasResult = Object.prototype.hasOwnProperty.call(packet, 'result');
  const hasError = Object.prototype.hasOwnProperty.call(packet, 'error');
  if (hasResult === hasError) {
    throw new DebugAdapterError('malformed-packet', 'response must contain exactly one of result or error');
  }
  if (!hasError) return;
  const error = packet.error;
  if (!error || typeof error !== 'object' || Array.isArray(error) || Object.prototype.hasOwnProperty.call(error, WIRE_TAG)) {
    throw new DebugAdapterError('malformed-packet', 'response error must be a plain error object');
  }
}

export function validateRemotePacket(packet) {
  if (!packet || typeof packet !== 'object' || Array.isArray(packet)) throw new DebugAdapterError('malformed-packet', 'remote packet must be an object');
  if (!ALLOWED_TYPES.has(packet.type)) throw new DebugAdapterError('malformed-packet', 'invalid remote packet type');
  if (packet.version !== DEBUG_PROTOCOL_VERSION) throw new DebugAdapterError('protocol-version', `unsupported remote protocol version: ${packet.version}`);
  validateValue(packet);
  if (jsonByteSize(packet) > MAX_PACKET_BYTES) throw new DebugAdapterError('packet-too-large', 'remote packet exceeds 1 MiB');
  validateEpoch(packet);
  if ((packet.type === 'request' || packet.type === 'response' || packet.type === 'cancel') && (!Number.isSafeInteger(packet.id) || packet.id < 1)) throw new DebugAdapterError('malformed-packet', 'request id must be a positive safe integer');
  if (packet.type === 'request') {
    if (typeof packet.method !== 'string' || !packet.method || packet.method.length > 128) throw new DebugAdapterError('malformed-packet', 'request method must be a 1..128 character string');
    if (BLOCKED_METHODS.test(packet.method)) throw new DebugAdapterError('blocked-method', 'host command execution is prohibited');
  }
  /* #5471: an event packet without a valid event identifier would still be
     dispatched to listeners; the event name carries the same string grammar
     as a request method. */
  if (packet.type === 'event') {
    if (typeof packet.event !== 'string' || !packet.event || packet.event.length > 128) {
      throw new DebugAdapterError('malformed-packet', 'event name must be a 1..128 character string');
    }
  }
  validateResponse(packet);
  return packet;
}

// Listener isolation must cover async failures too: a listener returning a
// promise that later rejects would otherwise leak an unhandledRejection
// through the sync-only try/catch (#5931).
function invokeListener(fn, packet) {
  try {
    const result = fn(packet);
    if (result && typeof result.then === 'function') Promise.resolve(result).catch(() => { /* listener isolation */ });
  } catch { /* listener isolation */ }
}

function defaultMonotonicNow() {
  try {
    const perf = globalThis.performance;
    if (typeof perf?.now === 'function') {
      const now = perf.now();
      if (Number.isFinite(now)) return now;
    }
  } catch { /* try the next monotonic source */ }
  try {
    const hrtime = globalThis.process?.hrtime;
    if (typeof hrtime?.bigint === 'function') {
      const now = Number(hrtime.bigint()) / 1e6;
      if (Number.isFinite(now)) return now;
    }
  } catch { /* fail closed below */ }
  throw new DebugAdapterError('monotonic-clock-unavailable', 'a monotonic clock is required for remote event rate limiting');
}

export class RemoteProtocolClient {
  constructor(transport, options = {}) {
    if (!transport || typeof transport.send !== 'function') throw new DebugAdapterError('transport', 'transport.send is required');
    this.transport = transport;
    this.timeoutMs = boundedInteger(options.timeoutMs, 5000, 10, 60000, 'timeoutMs');
    this.maxPending = boundedInteger(options.maxPending, 128, 1, 1024, 'maxPending');
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Set();
    this.maxEventsPerSecond = boundedInteger(options.maxEventsPerSecond, 256, 1, 10000, 'maxEventsPerSecond');
    this.maxEventBytesPerSecond = boundedInteger(options.maxEventBytesPerSecond, 4 * 1024 * 1024, 1024, 64 * 1024 * 1024, 'maxEventBytesPerSecond');
    // Rate windows measure elapsed time, so they must use a monotonic clock.
    // Date.now() can jump backwards (NTP/manual correction) and would pin a
    // saturated window shut until the wall clock catches up.
    this._monotonicNow = typeof options.monotonicNow === 'function' ? options.monotonicNow : defaultMonotonicNow;
    this.eventWindowStart = this._monotonicNow(); this.eventWindowCount = 0; this.eventWindowBytes = 0; this.droppedEvents = 0;
    this.epoch = 0;
    this.closed = false;
    this.unsubscribe = typeof transport.onMessage === 'function' ? transport.onMessage((packet) => this.receive(packet)) : null;
  }
  _cleanupPending(id, pending) {
    clearTimeout(pending.timer);
    if (pending.signal && pending.abortHandler) pending.signal.removeEventListener('abort', pending.abortHandler);
    this.pending.delete(id);
  }
  _allocateId() {
    if (this.nextId > Number.MAX_SAFE_INTEGER) this.nextId = 1;
    while (this.pending.has(this.nextId)) {
      this.nextId++;
      if (this.nextId > Number.MAX_SAFE_INTEGER) this.nextId = 1;
    }
    return this.nextId++;
  }
  setEpoch(epoch) {
    if (!Number.isSafeInteger(epoch) || epoch < 0) throw new DebugAdapterError('invalid-epoch', 'epoch must be a non-negative safe integer');
    const next = epoch;
    if (next === this.epoch) return this.epoch;
    const previous = this.epoch;
    this.epoch = next;
    for (const [id, pending] of [...this.pending]) {
      if (pending.epoch === next) continue;
      this._cleanupPending(id, pending);
      pending.reject(new DebugAdapterError('stale-request', 'request invalidated by session epoch change'));
      // Lifecycle packets must use the current epoch so the peer accepts them.
      // requestEpoch preserves which generation the cancelled request belonged to.
      this.sendPacket({ version:DEBUG_PROTOCOL_VERSION, type:'cancel', id, epoch:next, requestEpoch:pending.epoch, reason:'session-epoch-changed' }).catch(() => {});
    }
    return previous === next ? previous : this.epoch;
  }
  onEvent(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  async sendPacket(packet) {
    const encoded = encodeWireValue(packet);
    validateRemotePacket(encoded);
    await this.transport.send(encoded);
  }
  request(method, params = {}, options = {}) {
    if (this.closed) return Promise.reject(new DebugAdapterError('disconnected', 'remote protocol is closed'));
    if (typeof method !== 'string' || !method || method.length > 128) return Promise.reject(new DebugAdapterError('malformed-packet', 'request method must be a 1..128 character string'));
    if (BLOCKED_METHODS.test(method)) return Promise.reject(new DebugAdapterError('blocked-method', 'host command execution is prohibited'));
    if (this.pending.size >= this.maxPending) return Promise.reject(new DebugAdapterError('backpressure', 'too many pending remote requests'));
    const signal = options.signal ?? null;
    if (signal != null && (typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) {
      return Promise.reject(new DebugAdapterError('invalid-argument', 'signal must be AbortSignal-compatible'));
    }
    if (signal?.aborted) return Promise.reject(new DebugAdapterError('cancelled', String(signal.reason ?? 'cancelled')));
    const id = this._allocateId();
    const epoch = options.epoch == null ? this.epoch : options.epoch;
    if (!Number.isSafeInteger(epoch) || epoch < 0) return Promise.reject(new DebugAdapterError('invalid-epoch', 'epoch must be a non-negative safe integer'));
    let timeoutMs;
    try { timeoutMs = boundedInteger(options.timeoutMs, this.timeoutMs, 10, 60000, 'timeoutMs'); }
    catch (error) { return Promise.reject(error); }
    const packet = { version:DEBUG_PROTOCOL_VERSION, type:'request', id, epoch, method, params };
    return new Promise((resolve,reject) => {
      const pending = { resolve, reject, timer:null, epoch, method, signal, abortHandler:null };
      pending.timer = setTimeout(() => {
        if (!this.pending.has(id)) return;
        this._cleanupPending(id, pending);
        reject(new DebugAdapterError('timeout', `remote request timed out: ${method}`));
        this.sendPacket({ version:DEBUG_PROTOCOL_VERSION, type:'cancel', id, epoch:this.epoch, requestEpoch:epoch, reason:'timeout' }).catch(() => {});
      }, timeoutMs);
      this.pending.set(id, pending);
      if (pending.signal) {
        pending.abortHandler = () => this.cancel(id, String(pending.signal.reason ?? 'cancelled'));
        pending.signal.addEventListener('abort', pending.abortHandler, { once:true });
        if (pending.signal.aborted) pending.abortHandler();
      }
      if (!this.pending.has(id)) return;
      this.sendPacket(packet).catch((err) => {
        if (!this.pending.has(id)) return;
        this._cleanupPending(id, pending);
        reject(err);
      });
    });
  }
  async cancel(id, reason = 'cancelled') {
    const pending = this.pending.get(id);
    if (!pending) return false;
    this._cleanupPending(id, pending);
    pending.reject(new DebugAdapterError('cancelled', reason));
    try { await this.sendPacket({ version:DEBUG_PROTOCOL_VERSION, type:'cancel', id, epoch:this.epoch, requestEpoch:pending.epoch, reason:String(reason).slice(0,256) }); } catch { /* best effort */ }
    return true;
  }
  receive(raw) {
    let wire;
    try { wire = validateRemotePacket(raw); } catch { return false; }
    if (wire.type !== 'hello' && wire.epoch !== this.epoch) {
      // A request opened with an explicit epoch legally receives its response
      // carrying that request's own epoch (#5726). Keep such a response only
      // when it settles a pending request opened at that same epoch; every
      // other foreign-epoch packet stays rejected.
      const pendingForWire = wire.type === 'response' && Number.isSafeInteger(wire.id)
        ? this.pending.get(wire.id) : null;
      if (!pendingForWire || pendingForWire.epoch !== wire.epoch) return false;
    }
    let packet;
    try { packet = decodeWireValue(wire); } catch { return false; }
    if (packet.type === 'response') {
      const pending = this.pending.get(packet.id);
      // The request's own epoch is the settle authority: a pending opened at
      // an explicit epoch must be settled by its matching response even when
      // that epoch is not the client's current one (#5726).
      if (!pending || pending.epoch !== packet.epoch) return false;
      this._cleanupPending(packet.id, pending);
      if (packet.error) pending.reject(new DebugAdapterError(String(packet.error.code || 'remote-error'), String(packet.error.message || 'remote error').slice(0,2048), packet.error.details || null));
      else pending.resolve(packet.result);
      return true;
    }
    if (packet.type === 'event') {
      const now=this._monotonicNow();
      if (now-this.eventWindowStart >= 1000) { this.eventWindowStart=now; this.eventWindowCount=0; this.eventWindowBytes=0; this.droppedEvents=0; }
      const bytes=jsonByteSize(wire);
      if (this.eventWindowCount + 1 > this.maxEventsPerSecond || this.eventWindowBytes + bytes > this.maxEventBytesPerSecond) {
        this.droppedEvents++;
        if (this.droppedEvents === 1) {
          const notice={version:DEBUG_PROTOCOL_VERSION,type:'event',epoch:this.epoch,event:'stream-truncated',data:{reason:'event-backpressure'}};
          for (const fn of this.listeners) { invokeListener(fn, notice); }
        }
        return false;
      }
      this.eventWindowCount++; this.eventWindowBytes+=bytes;
      for (const fn of this.listeners) { invokeListener(fn, packet); }
      return true;
    }
    return false;
  }
  close(reason = 'disconnected') {
    if (this.closed) return;
    this.closed = true;
    if (typeof this.unsubscribe === 'function') this.unsubscribe();
    for (const [id,pending] of [...this.pending]) {
      this._cleanupPending(id, pending);
      pending.reject(new DebugAdapterError('disconnected', reason));
    }
    this.listeners.clear();
    if (typeof this.transport.close === 'function') { try { this.transport.close(); } catch { /* ignore */ } }
  }
}
