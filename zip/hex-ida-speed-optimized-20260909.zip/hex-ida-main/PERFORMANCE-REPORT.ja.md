# hex-ida：Drive mainスナップショットの横断的な速度改善

作成日：2026年9月9日（日本時間）。これは**ローカルのソース変更・計測・検証の納品**であり、GitHubへの統合、生成済みuserscriptへの反映、ブラウザ実機検証、公開・リリース完了を示すものではない。

## 1. 結論

同じDrive入力・同じ既存コーパス・同じ計測手順で、cold解析の135入力当たり平均時間の3反復中央値は **255.311 → 168.430 ms（34.03%短縮、1.516倍）**となった。JSON正規化、ID生成、originのマージ、Semantic IR正規化、ファイルハッシュ、バイナリ指紋、worker検索へ横断的に変更を施した。

この135入力には、元版から存在するRISC-Vの45件の失敗が各反復に含まれる。成功135関数のベンチマークではない。分母を減らしたり失敗を成功扱いしたりせず、**成功90件・失敗45件という同一条件のまま比較**した。今回の目的は速度改善であり、このABI問題や他の既存issueの修正は行っていない。

正確性の確認では、時間を除いた正式計測の405観測レコード、別実行した最適化ON/OFFの270全出力ケースが一致した。成功180ケースの1,020個の存在する出力フィールドは全文とSHA-256が一致し、存在しない60フィールドも一致した。追加の32自動テストはすべて通過した。

**全体の`npm run check`、広域回帰、userscriptビルドは未合格である。** 依存不足と元版でも再現する機能・テスト不整合を区別して後述する。また最大RSSは約15.60 MiB増加し、全ワイルドカード検索は約0.038 ms遅くなった。全処理の高速化や全入力の無回帰を保証するものではない。

## 2. 入力と境界

| 項目 | 固定した入力 |
|---|---|
| 取得元 | `/Google Drive/hex-ida-mirror/hex-ida-main.zip` |
| Drive更新日時 | 2026-09-09 16:07:24.441 JST（07:07:24.441 UTC） |
| Drive file ID | `11_2O5K8f7HG4LMnd2gN-EH9TS5aVdkGs` |
| ZIPサイズ | 9,793,921 bytes |
| ZIPコメントのコミット識別子 | `45311ca2f26a9e41c6e87a11e5c791d8ea4ae417` |
| ZIP SHA-256 | `b7de73a89fcdabebbe659a83c1ab4824cae5327e24a151edf5017b70cf8ab19b` |

作業開始時に指定Driveミラーから確認できた最新アーカイブを使用した。GitHubの現在のHEADと照合していないため、作業完了時のGitHub最新mainと同一だという主張はしない。元ZIPには`.git`がない。ZIPコメントは由来の識別に使用し、架空のGit履歴やexact-head証跡は作らなかった。

原本は3,578ファイル。原本に含まれる変更は9ファイルだけで、残る3,569ファイルは元ZIPとバイト単位で一致する。追加20ファイルには製品コード2ファイル、テスト・旧実装オラクル・計測ツールを含む。**製品コードは計9ファイル（変更7＋新規2）**。`package.json`と既存coreテスト入口にも追加テストの配線を行った。依存の版・lockfileは変更していない。

既存のコーパス、性能プロファイル、判定閾値、CI設定、reference/リンク/メモリ等の予算、ガードレール、公開条件は変更していない。生成済みuserscriptも元ZIPのままであり、ソースの高速化を配布済みbundleへ反映したとは扱わない。GitHub/Driveへの書き込みは行っていない。

## 3. 実装内容

### 3.1 ハッシュ計算の整数演算化

`js/core/identity/fnv64.js`を追加し、従来のFNV-1a-64を32ビットの上下桁で計算する。毎文字・毎バイトのBigInt生成や除算を避け、16ビット単位の正確なcarryと`Math.imul`を使用する。アルゴリズム、seed、桁の並び、文字列のUTF-16コード単位という従来の定義は維持した。暗号学的ハッシュへの変更ではなく、SHA-256経路は変更していない。

`js/core/identity/index.js`の安定ID、`js/platform/hash.js`の配列/ストリーム、`js/binary/fingerprint.js`の指紋計算に適用した。iterable経路は従来のbyte検証とエラーを保持し、ByteSource/指紋のindexed-read経路は従来どおりcustom iteratorを使わない。チャンク境界・中断・progress通知・不正seedの扱いもテストした。

### 3.2 JSON正規化の割当削減

`js/core/identity/index.js`では、通常のownプロパティ作成を単純代入にし、プロトタイプ上に同名プロパティが存在する場合のみ従来の`defineProperty`を使用する。`__proto__`、継承setter、継承non-writable属性などで挙動を変えない。getterを読む順番、JSON変換、キーの並びを旧実装と比較した。

### 3.3 origin再利用とSemantic IRのコピー削減

`js/core/identity/origin.js`で、自モジュールが生成して深く凍結した、再正規化に対して値が変わらないJSONデータだけを再利用する。リストの安定キーはWeakMap、生成物の識別はWeakSetで管理し、マージ時の再シリアライズ・再正規化・配列生成を減らす。

凍結されているだけの外部入力、浅い凍結、getter/custom mapper/species、JSON hook、配列の穴などは同じものとして盲目的に再利用しない。入力の検証、並び順、`localeCompare`で同順位になるキーの扱い、同じキーの最後の値を残す動作を維持する。

`js/semantics/ir/function.js`では、この限定されたoriginだけを入力捕捉時のProxy再作成から外す。可変データや未検証データは既存の捕捉経路を通す。raw/normalized reference budgetのカウンタを削除・緩和していない。

### 3.4 不変な解析メタデータのID文字列を再利用

`js/decompiler/phase8/analysis-identity.js`で、既存の深い不変性検査がtrueと確認したオブジェクトについてのみ、従来と同じ型付き文字列を弱参照で再利用する。個々のキャッシュ文字列は16 KiB以下に制限する。可変の子、Map/Set/Date、accessor、cycle等はこの再利用の対象にせず、従来の再計算・エラーを維持する。

### 3.5 workerのバイト検索

`js/platform/byte-search.js`を追加し、長さ3～4,096の通常パターンにマスク対応のBoyer–Moore–Horspool方式を適用した。256要素の保守的なスキップ表で、該当しない開始位置の比較を省く。ASCIIの大小文字処理、HEX/nibble mask、重複ヒット、チャンク継ぎ目、開始位置、1,000ヒット上限、進捗・中断のプロトコルを維持する。

`js/platform/worker.js`から既存検索経路に組み込み、小さすぎる/大きすぎる/特殊な入力は従来経路を使用する。パターンの捕捉はawaitによるチャンク読込後に行い、チャンクをまたいで可変入力を無条件にキャッシュしない。完全なワイルドカードも対応したが、今回の極小ケースでは総処理時間がわずかに悪化した。

## 4. 測定方法と結果

### 実行環境

Node v22.16.0、V8 12.4.254.21-node.26、Linux x64、AMD EPYC 9V74 80-Core Processorという実行環境で測定した。ユーザーの8core/32GB端末やiPadでの測定ではない。管理下のテスト・別ベンチを同時に走らせず、前後を別プロセスで順番に実行した。ホスト全体の他ユーザー負荷・CPU周波数・熱条件までは固定していない。

初回に同時実行の影響を受けた測定は破棄し、最終結果には混ぜていない。納品の計測データは直列再実行分のみ。`measurement-status.json`に実行順と各終了コードを記録した。

### 4.1 既存の正式手順によるcold解析

変更していない`tools/validation/phase8/metrics.mjs:performanceMetrics`と`profile.json`を使用。135入力を3反復し、各反復の全入力平均の中央値を取った。

| 指標 | 元Drive版 | 改善版 |
|---|---:|---:|
| cold平均の3反復中央値 | 255.311 ms | **168.430 ms** |
| 各反復の平均 | 249.467 / 259.911 / 255.311 ms | 170.607 / 168.430 / 164.296 ms |
| 各反復の入力 | 135 | 135 |
| 各反復の成功/失敗 | 90 / 45 | 90 / 45 |
| semantic/published ledger件数 | 80 / 80 | 80 / 80 |
| 最大RSS | 371.324 MiB | 386.922 MiB |

**時間は34.03%短縮。最大RSSは15.598 MiB（4.20%）増加。** このRSSは計測プロセス全体のhigh-water markであり、リークがないことや実機でのメモリ増加量まで保証する値ではない。

失敗45件はすべて元版にもある`phase8-measurement-abi-unavailable:riscv64`。除外して良い成績だけを計測することはしていない。残る成功90件のうち80件がsemantic経路で、10件はlegacy fallback。品質や対応アーキテクチャが増えたという成果ではない。

改善版のcold値は既存250 ms上限を下回ったが、これだけでPhase 8全体のrelease/exact-headゲートが通ったとは扱わない。このスナップショットの正式手順には独立のinteractive/optimizer時間が返らないため、前回の別ZIPでのそれらの数値は流用していない。

### 4.2 個別処理の合成ワークロード

各ケースをwarmup後に7サンプル、別プロセスで2ラウンド測定。順番は元版→改善版、改善版→元版。各側14サンプルの中央値を比較した。表は1回の操作当たりmsで、倍率は元版時間÷改善版時間。

| 処理 | 元版 ms | 改善版 ms | 倍率 | 時間変化 |
|---|---:|---:|---:|---|
| JSON正規化（160レコード） | 0.437749 | 0.210034 | 2.084倍 | 52.02%短縮 |
| 安定ID生成（160レコード） | 0.687630 | 0.380800 | 1.806倍 | 44.62%短縮 |
| originの32集合マージ | 0.180371 | 0.064780 | 2.784倍 | 64.08%短縮 |
| Semantic IR正規化（65ノード） | 4.774284 | 1.671322 | 2.857倍 | 64.99%短縮 |
| 解析ID生成（97値） | 5.257496 | 4.529301 | 1.161倍 | 13.85%短縮 |
| hashBytes（4 MiB） | 282.110992 | 47.132655 | 5.985倍 | 83.29%短縮 |
| ストリームハッシュ（8 MiB） | 366.585237 | 18.966959 | 19.328倍 | 94.83%短縮 |
| バイナリ指紋（4 MiB） | 31.848926 | 9.486581 | 3.357倍 | 70.21%短縮 |
| 16バイトHEX検索（8 MiB） | 35.134421 | 6.726227 | 5.223倍 | 80.86%短縮 |
| 16バイトマスク付き検索（8 MiB） | 38.231093 | 6.696270 | 5.709倍 | 82.48%短縮 |
| 16バイトASCII大小混在テキスト検索（8 MiB） | 86.719512 | 8.235471 | 10.530倍 | 90.50%短縮 |
| 3バイトHEX検索（8 MiB） | 58.724130 | 22.683064 | 2.589倍 | 61.37%短縮 |
| 全ワイルドカード検索（1,000ヒット打ち切り） | 0.425126 | 0.463004 | 0.918倍 | 8.91%増加 |
| 繰り返し接頭辞の32バイト検索（1 MiB） | 128.171408 | 7.524712 | 17.033倍 | 94.13%短縮 |

全ワイルドカードの1,000件打ち切り検索は **0.425126 → 0.463004 ms（8.91%増加、差約0.0379 ms）**。改善したとは数えていない。その他も実アプリ全体が表の倍率で速くなるという意味ではなく、fixture形状・パターン長・ヒット密度・キャッシュの再利用率で変わる。検索は実際のworkerメッセージ経路をNodeのin-process worker harnessで呼び出しており、ブラウザWorker起動費用、UI描画、iPad操作応答は測定していない。

## 5. 正確性の検証

### 出力差分

正式測定の**405/405観測レコードが完全一致**。別の出力採取は135入力×最適化OFF/ONで270ケース。これも全ケースで一致し、内訳は成功180・元からの失敗90。

成功ケースでは`semanticAst`、`types`、`evidence`、`phase8`、`pseudocode`、`sourceMap`を同じ正規化方法で全文保存し、本文、存在/不在、byte数、SHA-256を比較した。存在するフィールド1,020個はすべて一致。legacy経路等で存在しない60フィールドも一致した。未定義のフィールドを存在する成果物として水増ししていない。

圧縮全文は`baseline-capture.jsonl.gz`と`candidate-capture.jsonl.gz`、索引は`*-capture-hashes.json`。`compare-results.py`は入力集合、重複/欠落、プロファイル、source manifest、環境、本文と索引の整合まで検査し、欠けた比較を成功扱いしない。

### 追加テスト32件

旧実装の独立オラクルとの比較を中心に、全65,536 UTF-16コード単位、文字列・seed、バイト境界、各種不正入力、600組の指紋入力とseed形式、1,200ランダム検索ケース、重複・大文字小文字・Unicode・scan境界・ヒット上限、abort/progress、originの凍結/再利用/特殊入力、不変/可変解析データを確認した。

`npm run performance:test`で32/32成功。最終納品用に組み立てたソースでも再実行し、32/32成功した。最終納品ソースの製品source manifestは、正式測定の改善版とバイト単位で同一。

### 既存の検証

| 検証 | 改善版 | 元版との切り分け |
|---|---|---|
| `lint` / `module-boundaries:test` | 成功 | 納品ツリーでも再実行して成功 |
| `core:test` / `semantic:test` | 成功 | 納品ツリーでも再実行して成功 |
| `platform:test` / `binary:test` | 成功 | 最終コードでも再実行 |
| `runtime:test` / `metadata:test` / `ui:test` | 成功 | 最終コードでも再実行 |
| `phase10:test` | 成功 | 既存の手順をそのまま実行 |
| `decompiler:test` | 失敗 | 元版も同じ2/14ファイル失敗：`objc-metadata.mjs`、`issue-529-objc-integration.mjs` |
| `semantic-v2:test` | 失敗 | 元版でもintegration、SSAリンク予算、ObjC/evidence-chain、依存不足等が再現 |
| `phase4:test` | 失敗 | 元版でも同じ非同期活動由来の`false !== true`例外 |
| `phase8:test` | 失敗 | 改善版は約296.5秒で終了。元版の全体実行は300秒の外側制限で停止したため、完走比較とは扱わない |
| `phase9:test` | 失敗 | 元版でもpreflight、sort/width同値性、DAG予算、Playwright不足の各失敗が再現 |
| `npm run check` | 失敗 | 両方とも`esbuild`不足でarchitecture-boundary検査が停止 |
| `userscript:build` | 失敗 | 両方とも`esbuild`不足 |

Phase 8の補足切り分けとして、ABI profile matrix / GVN / SCCP / verticalの4ファイルを元版・改善版で個別実行した。RISC-V ABI不足と古いテスト側の`state.__write`呼び出し等の失敗が両方で再現した。ただし全体の元版実行は完了していないので、「全失敗が完全に同一」「全回帰が解消」とは主張しない。改善版にもcorpus/品質/正規成果物/exact-head関連の失敗が残る。

これらには**環境不足だけでなく既存の機能・テスト不整合も含まれる**。依頼外のissue修正は行わず、失敗の削除、テストのskip、ゲート緩和、ABI対応を装う変更は行っていない。

`npm ci --ignore-scripts --no-audit --no-fund`による依存取得は完了せず、npmは`Exit handler never called!`で終了した。インストール中にDNS解決エラーも観測したが、元の詳細npmログは後続実行でローテーションされたため、納品では残っている終了ログだけを証拠として保存している。必要な`esbuild`/`playwright`を使用可能にできなかった。空のインストール途中`node_modules`は納品から除外している。

## 6. 再実行方法

以下は納品ZIPを展開した`hex-ida-main`ディレクトリから実行する。Node 22.16.0、Python 3、Gitを使用する。まず原本と同じ内容のbaselineを別ディレクトリへ展開する。原本が手元にない場合は、**納品ソースを新しい空ディレクトリにコピーし、コピー側だけで同梱patchをreverse適用する**と元版の製品ソースを復元できる。既存の作業ツリーへ無条件にreverse適用しない。

```bash
# 元版・改善版に必要な既存依存を取得できる環境で実行する。
npm ci --ignore-scripts --no-audit --no-fund
npm run performance:test
node scripts/run-quiet-command.mjs --label check -- npm run check
node scripts/run-quiet-command.mjs --label test -- npm test
node scripts/run-quiet-command.mjs --label userscript-build -- npm run userscript:build
```

上の全体check/test/buildが今回すでに成功したという意味ではない。既存エラーと必要なブラウザ/ツールチェーンを解消してから、リポジトリの元の手順で再確認するためのコマンドである。リリースには実際のGit履歴・対象HEADでのゲートと生成物/実機確認も必要。

計測は次のように1プロセスずつ順番に実行する。`BASELINE`は元Drive版の展開先に設定する。測定中に別のテストやベンチを並行実行しない。

```bash
CANDIDATE="$(pwd)"
BASELINE="/absolute/path/to/pristine-hex-ida-main"
OUT="$(mktemp -d)"
TOOLS="$CANDIDATE/tools/validation/performance-local"

node "$TOOLS/corpus-measure.mjs" "$BASELINE" "$OUT/baseline-canonical.json"
node "$TOOLS/corpus-measure.mjs" "$CANDIDATE" "$OUT/candidate-canonical.json"
node "$TOOLS/benchmark.mjs" "$BASELINE" "$OUT/baseline-micro-round1.json"
node "$TOOLS/benchmark.mjs" "$CANDIDATE" "$OUT/candidate-micro-round1.json"
node "$TOOLS/benchmark.mjs" "$CANDIDATE" "$OUT/candidate-micro-round2.json"
node "$TOOLS/benchmark.mjs" "$BASELINE" "$OUT/baseline-micro-round2.json"
node "$TOOLS/corpus-capture.mjs" "$BASELINE" "$OUT/baseline-capture"
node "$TOOLS/corpus-capture.mjs" "$CANDIDATE" "$OUT/candidate-capture"
python3 "$TOOLS/compare-results.py" "$OUT"
```

同梱済みの結果だけを再検証する場合は次を実行する。再測定はせず、圧縮された全文と索引を含めて比較する。

```bash
python3 tools/validation/performance-local/compare-results.py   reports/performance-local-20260909   /tmp/hex-ida-comparison-rechecked.json
```

## 7. 納品と適用検証

ZIPには全ソース、追加テスト、計測/比較ツール、このレポート、`reports/performance-local-20260909/`の正式測定データ・全文出力・検証ログを含む。`.git`、`node_modules`、実験途中の実装、破棄した重複負荷の測定値は含まない。既存の`tmp`等の原本ファイルを勝手に削除してはいない。

差分patchは元ZIPを基準とする29ファイル（既存変更9＋追加20）のみ。ローカルの一時Git indexで生成し、`git diff --check`、原本への`git apply --check`、実適用後の全対象ファイルのバイト一致を確認した。一時Git操作はGitHubとの通信やupstream commit作成ではない。

`source-integrity.json`には対象ファイルごとの変更前後SHA-256と原本保全結果を記録した。配布ZIP/patch/レポートのサイズとSHA-256は外側のdelivery manifestに記録する。将来のmainに適用する場合は差分を再確認し、このZIPでmain全体を上書きしない。

### 変更・追加ファイル一覧

| パス | 区分 |
|---|---|
| `js/binary/fingerprint.js` | 変更 |
| `js/core/identity/fnv64.js` | 追加 |
| `js/core/identity/index.js` | 変更 |
| `js/core/identity/origin.js` | 変更 |
| `js/decompiler/phase8/analysis-identity.js` | 変更 |
| `js/platform/byte-search.js` | 追加 |
| `js/platform/hash.js` | 変更 |
| `js/platform/worker.js` | 変更 |
| `js/semantics/ir/function.js` | 変更 |
| `package.json` | 変更 |
| `tests/core-identity-contracts.mjs` | 変更 |
| `tests/core-identity-performance.test.mjs` | 追加 |
| `tests/core-origin-canonical-reuse.test.mjs` | 追加 |
| `tests/helpers/analysis-identity-baseline-oracle.mjs` | 追加 |
| `tests/helpers/core-identity-baseline-oracle.mjs` | 追加 |
| `tests/helpers/fingerprint-baseline-oracle.mjs` | 追加 |
| `tests/helpers/origin-normalization-oracle.mjs` | 追加 |
| `tests/helpers/performance-worker.mjs` | 追加 |
| `tests/helpers/platform-hash-baseline-oracle.mjs` | 追加 |
| `tests/performance/analysis-identity.test.mjs` | 追加 |
| `tests/performance/byte-search.test.mjs` | 追加 |
| `tests/performance/fingerprint.test.mjs` | 追加 |
| `tests/performance/platform-hash.test.mjs` | 追加 |
| `tests/performance/worker-search.test.mjs` | 追加 |
| `tools/validation/performance-local/benchmark.mjs` | 追加 |
| `tools/validation/performance-local/compare-results.py` | 追加 |
| `tools/validation/performance-local/corpus-capture.mjs` | 追加 |
| `tools/validation/performance-local/corpus-measure.mjs` | 追加 |
| `tools/validation/performance-local/source-manifest.mjs` | 追加 |

## 8. 明示的な未検証事項

ブラウザでの実Worker並列動作、iPad/対象端末の応答・熱・メモリ、UI描画/FPS、実際の大規模ユーザーファイル、生成済みuserscriptへの反映、リリースゲートの全面成功、GitHub最新HEADへの適用・統合は未検証/未実施。32テスト・405観測・270全出力一致は今回実行した有限のケースに対する確認であり、あらゆる入力の形式的な無回帰証明ではない。
